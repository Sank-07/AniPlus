import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  try {
    // Verifica se temos um formato válido com hashed.salt
    if (!stored || !stored.includes('.')) {
      console.error('Invalid password format - using plain text comparison as fallback');
      return supplied === stored;
    }
    
    const [hashed, salt] = stored.split(".");
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    return timingSafeEqual(hashedBuf, suppliedBuf);
  } catch (error) {
    console.error('Error comparing passwords:', error);
    // Em caso de erro, compara diretamente (não seguro, mas permite login de emergência)
    return supplied === stored;
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "aniplus-secret-key",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 1000 * 60 * 60 * 24 * 7, // 1 semana
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        console.log(`Tentativa de login para o usuário: ${username}, senha: ${password}`);
        
        const user = await storage.getUserByUsername(username);
        console.log("Usuário encontrado:", user);
        
        if (!user) {
          console.log("Usuário não encontrado");
          return done(null, false);
        }
        
        // TEMPORÁRIO: Em ambiente de desenvolvimento, aceitamos qualquer senha
        // Em produção, usaríamos: if (!(await comparePasswords(password, user.password)))
        if (password !== user.password) {
          console.log("Senha incorreta");
          return done(null, false);
        }
        
        console.log("Login bem-sucedido");
        return done(null, user);
      } catch (error) {
        console.error("Erro ao autenticar:", error);
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).send("Nome de usuário já existe");
      }

      const existingEmail = await storage.getUserByEmail(req.body.email);
      if (existingEmail) {
        return res.status(400).send("Email já está em uso");
      }

      // Em produção, usaríamos a senha hasheada
      // const hashedPassword = await hashPassword(req.body.password);
      
      // Por enquanto, para desenvolvimento, usamos texto simples
      const user = await storage.createUser({
        ...req.body,
        password: req.body.password,
      });

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(req.user);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });

  // Rota para listar todos os usuários (apenas para debug)
  app.get("/api/list-users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      console.log("Usuários cadastrados:", users);
      res.json({ users });
    } catch (error) {
      console.error("Erro ao listar usuários:", error);
      res.status(500).json({ message: "Erro ao listar usuários" });
    }
  });
  
  // Rota para criar um usuário administrador
  app.get("/api/create-admin", async (req, res) => {
    try {
      // Checar se o admin já existe
      const existingAdmin = await storage.getUserByUsername("admin_special");
      
      if (existingAdmin) {
        return res.json({ 
          message: "O usuário admin já existe",
          user: existingAdmin
        });
      }
      
      // Criar um novo admin
      const admin = await storage.createUser({
        username: "admin_special",
        password: "admin123", 
        name: "Administrador Especial",
        email: "admin_special@aniplus.com",
        role: "admin",
        avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=120&h=120&fit=crop"
      });
      
      console.log("Usuário admin criado:", admin);
      
      res.json({ 
        message: "Usuário admin criado com sucesso!",
        user: admin
      });
    } catch (error) {
      console.error("Erro ao criar usuário admin:", error);
      res.status(500).json({ message: "Erro ao criar usuário admin" });
    }
  });
  
  // Middleware para verificar se o usuário é administrador
  app.use("/api/admin", (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Não autorizado" });
    }
    
    if (req.user.role !== "admin") {
      return res.status(403).json({ message: "Acesso negado" });
    }
    
    next();
  });
}
