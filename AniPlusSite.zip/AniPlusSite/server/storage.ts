import { 
  User, InsertUser, 
  Anime, InsertAnime, 
  Season, InsertSeason, 
  Episode, InsertEpisode, 
  WatchHistory, InsertWatchHistory, 
  Favorite, InsertFavorite,
  Calendar, InsertCalendar
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Interface para o armazenamento
export interface IStorage {
  // Session store
  sessionStore: any; // Using 'any' type for SessionStore
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  // Anime methods
  getAnime(id: number): Promise<Anime | undefined>;
  getAllAnimes(): Promise<Anime[]>;
  getPopularAnimes(limit?: number): Promise<Anime[]>;
  getRelatedAnimes(animeId: number, limit?: number): Promise<Anime[]>;
  createAnime(anime: InsertAnime): Promise<Anime>;
  updateAnime(id: number, anime: InsertAnime): Promise<Anime>;
  deleteAnime(id: number): Promise<void>;
  
  // Season methods
  getSeason(id: number): Promise<Season | undefined>;
  getSeasonsByAnime(animeId: number): Promise<Season[]>;
  createSeason(season: InsertSeason): Promise<Season>;
  updateSeason(id: number, season: InsertSeason): Promise<Season>;
  deleteSeason(id: number): Promise<void>;
  
  // Episode methods
  getEpisode(id: number): Promise<Episode | undefined>;
  getEpisodesByAnime(animeId: number): Promise<Episode[]>;
  getEpisodesBySeason(seasonId: number): Promise<Episode[]>;
  getRecentEpisodes(limit?: number): Promise<Episode[]>;
  createEpisode(episode: InsertEpisode): Promise<Episode>;
  updateEpisode(id: number, episode: InsertEpisode): Promise<Episode>;
  deleteEpisode(id: number): Promise<void>;
  
  // Watch history methods
  getUserWatchHistory(userId: number): Promise<WatchHistory[]>;
  upsertWatchHistory(history: InsertWatchHistory): Promise<WatchHistory>;
  getContinueWatching(userId: number): Promise<WatchHistory[]>;
  
  // Favorites methods
  getUserFavorites(userId: number): Promise<Anime[]>;
  addFavorite(favorite: InsertFavorite): Promise<void>;
  removeFavorite(userId: number, animeId: number): Promise<void>;
  
  // Calendar methods
  getCalendar(): Promise<Calendar[]>;
  addCalendarEntry(entry: InsertCalendar): Promise<Calendar>;
  updateCalendarEntry(id: number, entry: InsertCalendar): Promise<Calendar>;
  deleteCalendarEntry(id: number): Promise<void>;
  
  // Rankings
  getUserRankings(limit?: number): Promise<User[]>;
}

export class MemStorage implements IStorage {
  users: Map<number, User>; // Alterado para público para permitir acesso direto
  animes: Map<number, Anime>; // Alterado para público para estatísticas
  seasons: Map<number, Season>; // Alterado para público para estatísticas
  episodes: Map<number, Episode>; // Alterado para público para estatísticas
  watchHistories: Map<number, WatchHistory>; // Alterado para público para estatísticas
  favorites: Set<string>; // userId-animeId - Alterado para público para estatísticas
  calendarEntries: Map<number, Calendar>; // Alterado para público para estatísticas
  sessionStore: any; // Using 'any' type for SessionStore
  
  private userIdCounter: number;
  private animeIdCounter: number;
  private seasonIdCounter: number;
  private episodeIdCounter: number;
  private watchHistoryIdCounter: number;
  private calendarIdCounter: number;

  constructor() {
    this.users = new Map();
    this.animes = new Map();
    this.seasons = new Map();
    this.episodes = new Map();
    this.watchHistories = new Map();
    this.favorites = new Set();
    this.calendarEntries = new Map();
    
    this.userIdCounter = 1;
    this.animeIdCounter = 1;
    this.seasonIdCounter = 1;
    this.episodeIdCounter = 1;
    this.watchHistoryIdCounter = 1;
    this.calendarIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Limpa sessões expiradas a cada 24h
    });
    
    // Criar usuário admin por padrão
    this.createUser({
      username: "admin",
      password: "admin123", // Em produção, isso seria hasheado
      name: "Administrador",
      email: "admin@aniplus.com",
      role: "admin",
      avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=120&h=120&fit=crop"
    });
    
    // Adicionar alguns animes de exemplo
    this.seedAnimes();
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    const user: User = { 
      id, 
      createdAt,
      animeWatched: 0,
      username: insertUser.username,
      password: insertUser.password,
      name: insertUser.name,
      email: insertUser.email,
      avatar: insertUser.avatar || null,
      role: insertUser.role || "user"
    };
    
    console.log("Criando usuário:", JSON.stringify(user));
    this.users.set(id, user);
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Animes
  async getAnime(id: number): Promise<Anime | undefined> {
    return this.animes.get(id);
  }

  async getAllAnimes(): Promise<Anime[]> {
    return Array.from(this.animes.values());
  }

  async getPopularAnimes(limit: number = 10): Promise<Anime[]> {
    return Array.from(this.animes.values())
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }
  
  async getRelatedAnimes(animeId: number, limit: number = 6): Promise<Anime[]> {
    const targetAnime = await this.getAnime(animeId);
    if (!targetAnime) {
      return [];
    }
    
    // Algoritmo para encontrar animes relacionados com base em gêneros e audioLanguage
    const allAnimes = await this.getAllAnimes();
    
    // Remover o próprio anime da lista
    const otherAnimes = allAnimes.filter(anime => anime.id !== animeId);
    
    // Calcular pontuação de similaridade para cada anime
    const similarityScores = otherAnimes.map(anime => {
      let score = 0;
      
      // +3 pontos para cada gênero correspondente
      targetAnime.genres.forEach(genre => {
        if (anime.genres.includes(genre)) {
          score += 3;
        }
      });
      
      // +2 pontos se o idioma de áudio for o mesmo
      if (anime.audioLanguage === targetAnime.audioLanguage) {
        score += 2;
      }
      
      // +1 ponto se o status for o mesmo
      if (anime.status === targetAnime.status) {
        score += 1;
      }
      
      return { anime, score };
    });
    
    // Ordenar por pontuação (maior para menor) e retornar apenas os animes
    return similarityScores
      .sort((a, b) => b.score - a.score)
      .map(item => item.anime)
      .slice(0, limit);
  }

  async createAnime(insertAnime: InsertAnime): Promise<Anime> {
    const id = this.animeIdCounter++;
    const createdAt = new Date();
    const anime: Anime = { 
      ...insertAnime, 
      id, 
      createdAt,
      rating: 0
    };
    this.animes.set(id, anime);
    return anime;
  }

  async updateAnime(id: number, insertAnime: InsertAnime): Promise<Anime> {
    const existingAnime = await this.getAnime(id);
    if (!existingAnime) {
      throw new Error("Anime não encontrado");
    }
    
    const updatedAnime: Anime = {
      ...existingAnime,
      ...insertAnime,
      id
    };
    
    this.animes.set(id, updatedAnime);
    return updatedAnime;
  }

  async deleteAnime(id: number): Promise<void> {
    // Remover anime
    this.animes.delete(id);
    
    // Remover temporadas relacionadas
    const seasons = await this.getSeasonsByAnime(id);
    for (const season of seasons) {
      this.seasons.delete(season.id);
    }
    
    // Remover episódios relacionados
    const episodes = await this.getEpisodesByAnime(id);
    for (const episode of episodes) {
      this.episodes.delete(episode.id);
    }
    
    // Remover histórico de visualização relacionado
    const allWatchHistories = Array.from(this.watchHistories.values());
    for (const history of allWatchHistories) {
      if (history.animeId === id) {
        this.watchHistories.delete(history.id);
      }
    }
    
    // Remover dos favoritos
    for (const key of this.favorites) {
      const [userId, animeId] = key.split('-').map(Number);
      if (animeId === id) {
        this.favorites.delete(key);
      }
    }
    
    // Remover entradas do calendário
    const allCalendarEntries = Array.from(this.calendarEntries.values());
    for (const entry of allCalendarEntries) {
      if (entry.animeId === id) {
        this.calendarEntries.delete(entry.id);
      }
    }
  }

  // Seasons
  async getSeason(id: number): Promise<Season | undefined> {
    return this.seasons.get(id);
  }

  async getSeasonsByAnime(animeId: number): Promise<Season[]> {
    return Array.from(this.seasons.values())
      .filter(season => season.animeId === animeId)
      .sort((a, b) => a.number - b.number);
  }

  async createSeason(insertSeason: InsertSeason): Promise<Season> {
    const id = this.seasonIdCounter++;
    const createdAt = new Date();
    const season: Season = { 
      ...insertSeason, 
      id, 
      createdAt
    };
    this.seasons.set(id, season);
    return season;
  }

  async updateSeason(id: number, insertSeason: InsertSeason): Promise<Season> {
    const existingSeason = await this.getSeason(id);
    if (!existingSeason) {
      throw new Error("Temporada não encontrada");
    }
    
    const updatedSeason: Season = {
      ...existingSeason,
      ...insertSeason,
      id
    };
    
    this.seasons.set(id, updatedSeason);
    return updatedSeason;
  }

  async deleteSeason(id: number): Promise<void> {
    // Remover temporada
    this.seasons.delete(id);
    
    // Remover ou atualizar os episódios relacionados (opcional: poderiam ser apenas desvinculados da temporada)
    const episodes = await this.getEpisodesBySeason(id);
    for (const episode of episodes) {
      const updatedEpisode = { 
        ...episode, 
        seasonId: null as unknown as number
      };
      this.episodes.set(episode.id, updatedEpisode);
    }
  }

  // Episodes
  async getEpisode(id: number): Promise<Episode | undefined> {
    return this.episodes.get(id);
  }

  async getEpisodesByAnime(animeId: number): Promise<Episode[]> {
    return Array.from(this.episodes.values())
      .filter(episode => episode.animeId === animeId)
      .sort((a, b) => a.number - b.number);
  }

  async getEpisodesBySeason(seasonId: number): Promise<Episode[]> {
    return Array.from(this.episodes.values())
      .filter(episode => episode.seasonId === seasonId)
      .sort((a, b) => a.number - b.number);
  }

  async getRecentEpisodes(limit: number = 10): Promise<Episode[]> {
    return Array.from(this.episodes.values())
      .sort((a, b) => b.releaseDate.getTime() - a.releaseDate.getTime())
      .slice(0, limit);
  }

  async createEpisode(insertEpisode: InsertEpisode): Promise<Episode> {
    const id = this.episodeIdCounter++;
    const createdAt = new Date();
    
    // Garantir que releaseDate seja um objeto Date válido
    let releaseDate: Date;
    if (typeof insertEpisode.releaseDate === 'string') {
      releaseDate = new Date(insertEpisode.releaseDate);
    } else {
      releaseDate = insertEpisode.releaseDate as Date;
    }
    
    const episode: Episode = { 
      ...insertEpisode, 
      releaseDate,
      id, 
      createdAt
    };
    
    console.log("Criando episódio:", episode);
    this.episodes.set(id, episode);
    return episode;
  }

  async updateEpisode(id: number, insertEpisode: InsertEpisode): Promise<Episode> {
    const existingEpisode = await this.getEpisode(id);
    if (!existingEpisode) {
      throw new Error("Episódio não encontrado");
    }
    
    // Garantir que releaseDate seja um objeto Date válido
    let releaseDate: Date;
    if (typeof insertEpisode.releaseDate === 'string') {
      releaseDate = new Date(insertEpisode.releaseDate);
    } else if (insertEpisode.releaseDate) {
      releaseDate = insertEpisode.releaseDate as Date;
    } else {
      // Manter a data original se não for fornecida
      releaseDate = existingEpisode.releaseDate;
    }
    
    const updatedEpisode: Episode = {
      ...existingEpisode,
      ...insertEpisode,
      releaseDate,
      id
    };
    
    console.log(`Atualizando episódio ${id}:`, updatedEpisode);
    this.episodes.set(id, updatedEpisode);
    return updatedEpisode;
  }

  async deleteEpisode(id: number): Promise<void> {
    // Remover episódio
    this.episodes.delete(id);
    
    // Remover histórico de visualização relacionado
    const allWatchHistories = Array.from(this.watchHistories.values());
    for (const history of allWatchHistories) {
      if (history.episodeId === id) {
        this.watchHistories.delete(history.id);
      }
    }
    
    // Remover entradas do calendário que referenciam esse episódio
    const allCalendarEntries = Array.from(this.calendarEntries.values());
    for (const entry of allCalendarEntries) {
      if (entry.episodeId === id) {
        // Atualizar para referenciar apenas o anime, não o episódio específico
        const updatedEntry = {
          ...entry,
          episodeId: null as unknown as number
        };
        this.calendarEntries.set(entry.id, updatedEntry);
      }
    }
  }

  // Watch history
  async getUserWatchHistory(userId: number): Promise<WatchHistory[]> {
    return Array.from(this.watchHistories.values())
      .filter(history => history.userId === userId)
      .sort((a, b) => b.watchedAt.getTime() - a.watchedAt.getTime());
  }

  async upsertWatchHistory(insertHistory: InsertWatchHistory): Promise<WatchHistory> {
    // Verificar se já existe um registro para este usuário e episódio
    const existing = Array.from(this.watchHistories.values()).find(
      h => h.userId === insertHistory.userId && h.episodeId === insertHistory.episodeId
    );
    
    if (existing) {
      // Atualizar o registro existente
      const updatedHistory: WatchHistory = {
        ...existing,
        progress: insertHistory.progress,
        completed: insertHistory.completed,
        watchedAt: new Date()
      };
      
      this.watchHistories.set(existing.id, updatedHistory);
      return updatedHistory;
    } else {
      // Criar um novo registro
      const id = this.watchHistoryIdCounter++;
      const watchedAt = new Date();
      const history: WatchHistory = {
        ...insertHistory,
        id,
        watchedAt
      };
      
      this.watchHistories.set(id, history);
      
      // Se o usuário completou o episódio, atualizar o contador de animes assistidos
      if (history.completed) {
        this.updateUserAnimeWatchedCount(history.userId);
      }
      
      return history;
    }
  }

  async getContinueWatching(userId: number): Promise<WatchHistory[]> {
    // Buscar histórico incompleto do usuário, ordenado pelos assistidos mais recentemente
    return Array.from(this.watchHistories.values())
      .filter(history => history.userId === userId && !history.completed)
      .sort((a, b) => b.watchedAt.getTime() - a.watchedAt.getTime());
  }

  // Favorites
  async getUserFavorites(userId: number): Promise<Anime[]> {
    const favoriteAnimeIds = Array.from(this.favorites)
      .filter(key => key.startsWith(`${userId}-`))
      .map(key => parseInt(key.split('-')[1]));
    
    return favoriteAnimeIds.map(id => this.animes.get(id)!).filter(Boolean);
  }

  async addFavorite(favorite: InsertFavorite): Promise<void> {
    const key = `${favorite.userId}-${favorite.animeId}`;
    this.favorites.add(key);
  }

  async removeFavorite(userId: number, animeId: number): Promise<void> {
    const key = `${userId}-${animeId}`;
    this.favorites.delete(key);
  }

  // Calendar
  async getCalendar(): Promise<Calendar[]> {
    return Array.from(this.calendarEntries.values());
  }

  async addCalendarEntry(insertEntry: InsertCalendar): Promise<Calendar> {
    const id = this.calendarIdCounter++;
    const entry: Calendar = {
      ...insertEntry,
      id
    };
    this.calendarEntries.set(id, entry);
    return entry;
  }

  async updateCalendarEntry(id: number, insertEntry: InsertCalendar): Promise<Calendar> {
    const existingEntry = this.calendarEntries.get(id);
    if (!existingEntry) {
      throw new Error("Entrada do calendário não encontrada");
    }
    
    const updatedEntry: Calendar = {
      ...existingEntry,
      ...insertEntry,
      id
    };
    
    this.calendarEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async deleteCalendarEntry(id: number): Promise<void> {
    this.calendarEntries.delete(id);
  }

  // Rankings
  async getUserRankings(limit: number = 10): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => b.animeWatched - a.animeWatched)
      .slice(0, limit);
  }
  
  // Helper methods
  private async updateUserAnimeWatchedCount(userId: number): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) return;
    
    // Calcular quantos animes únicos o usuário assistiu ao menos um episódio completo
    const watchedAnimeIds = new Set<number>();
    
    Array.from(this.watchHistories.values())
      .filter(history => history.userId === userId && history.completed)
      .forEach(history => watchedAnimeIds.add(history.animeId));
    
    // Atualizar o contador de animes assistidos
    const updatedUser = {
      ...user,
      animeWatched: watchedAnimeIds.size
    };
    
    this.users.set(userId, updatedUser);
  }
  
  // Seed data
  private async seedAnimes(): Promise<void> {
    // Criar alguns animes de exemplo
    const attackOnTitan = await this.createAnime({
      title: "Attack on Titan",
      synopsis: "A humanidade luta pela sobrevivência contra os gigantes Titãs que ameaçam sua existência.",
      coverImage: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&h=450&fit=crop",
      bannerImage: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1500&h=500&fit=crop",
      type: "TV",
      releaseYear: 2013,
      status: "Concluído",
      genres: ["Ação", "Drama", "Fantasia"]
    });
    
    const demonSlayer = await this.createAnime({
      title: "Demon Slayer",
      synopsis: "Tanjiro Kamado embarca em uma jornada para se tornar um matador de demônios depois que sua família é massacrada e sua irmã é transformada em demônio.",
      coverImage: "https://images.unsplash.com/photo-1559981421-3e0c0d156372?w=300&h=450&fit=crop",
      bannerImage: "https://images.unsplash.com/photo-1559981421-3e0c0d156372?w=1500&h=500&fit=crop",
      type: "TV",
      releaseYear: 2019,
      status: "Em andamento",
      genres: ["Ação", "Aventura", "Fantasia", "Sobrenatural"]
    });
    
    const jujutsuKaisen = await this.createAnime({
      title: "Jujutsu Kaisen",
      synopsis: "Yuji Itadori, um estudante do ensino médio com incrível força física, se junta a um clube de ocultismo secreto em sua escola para evitar uma morte amaldiçoada.",
      coverImage: "https://images.unsplash.com/photo-1541562232579-512a21360020?w=300&h=450&fit=crop",
      bannerImage: "https://images.unsplash.com/photo-1541562232579-512a21360020?w=1500&h=500&fit=crop",
      type: "TV",
      releaseYear: 2020,
      status: "Em andamento",
      genres: ["Ação", "Sobrenatural"]
    });
    
    const spyFamily = await this.createAnime({
      title: "Spy x Family",
      synopsis: "Um espião, um assassino e uma telepata formam uma família enquanto cada um esconde sua verdadeira identidade dos outros, para cumprir suas próprias missões.",
      coverImage: "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&h=450&fit=crop",
      bannerImage: "https://images.unsplash.com/photo-1563089145-599997674d42?w=1500&h=500&fit=crop",
      type: "TV",
      releaseYear: 2022,
      status: "Em andamento",
      genres: ["Ação", "Comédia", "Espionagem"]
    });
    
    const onePiece = await this.createAnime({
      title: "One Piece",
      synopsis: "Monkey D. Luffy e sua tripulação de piratas exploram o Grand Line em busca do tesouro One Piece e enfrentam inimigos poderosos.",
      coverImage: "https://images.unsplash.com/photo-1560972550-aba3456b5564?w=300&h=450&fit=crop",
      bannerImage: "https://images.unsplash.com/photo-1560972550-aba3456b5564?w=1500&h=500&fit=crop",
      type: "TV",
      releaseYear: 1999,
      status: "Em andamento",
      genres: ["Ação", "Aventura", "Comédia", "Drama", "Fantasia"]
    });
    
    const myHeroAcademia = await this.createAnime({
      title: "My Hero Academia",
      synopsis: "Em um mundo onde pessoas com superpoderes são comuns, um garoto sem poderes luta para se tornar um herói.",
      coverImage: "https://images.unsplash.com/photo-1599685315640-4eebfc640523?w=300&h=450&fit=crop",
      bannerImage: "https://images.unsplash.com/photo-1599685315640-4eebfc640523?w=1500&h=500&fit=crop",
      type: "TV",
      releaseYear: 2016,
      status: "Em andamento",
      genres: ["Ação", "Comédia", "Super-heróis"]
    });
    
    // Atualizar ratings para criar um ranking
    const animeRatings = {
      [attackOnTitan.id]: 9.8,
      [demonSlayer.id]: 9.7,
      [jujutsuKaisen.id]: 9.5,
      [spyFamily.id]: 9.4,
      [onePiece.id]: 9.2,
      [myHeroAcademia.id]: 9.0
    };
    
    for (const [id, rating] of Object.entries(animeRatings)) {
      const anime = await this.getAnime(parseInt(id));
      if (anime) {
        this.animes.set(anime.id, { ...anime, rating: rating as number });
      }
    }
    
    // Criar temporadas para alguns animes
    const attackOnTitanS1 = await this.createSeason({
      animeId: attackOnTitan.id,
      title: "Temporada 1",
      number: 1,
      coverImage: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&h=450&fit=crop",
      releaseYear: 2013
    });
    
    const demonSlayerS1 = await this.createSeason({
      animeId: demonSlayer.id,
      title: "Temporada 1",
      number: 1,
      coverImage: "https://images.unsplash.com/photo-1559981421-3e0c0d156372?w=300&h=450&fit=crop",
      releaseYear: 2019
    });
    
    const demonSlayerS2 = await this.createSeason({
      animeId: demonSlayer.id,
      title: "Temporada 2",
      number: 2,
      coverImage: "https://images.unsplash.com/photo-1559981421-3e0c0d156372?w=300&h=450&fit=crop",
      releaseYear: 2021
    });
    
    // Criar episódios
    const attackOnTitanEpisodes = [
      {
        animeId: attackOnTitan.id,
        seasonId: attackOnTitanS1.id,
        title: "Para Você, em 2000 Anos",
        number: 1,
        thumbnail: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&h=300&fit=crop",
        videoUrl: "https://example.com/videos/attack-on-titan-s1e1.mp4",
        duration: 1440, // 24 minutos
        releaseDate: new Date("2013-04-07")
      },
      {
        animeId: attackOnTitan.id,
        seasonId: attackOnTitanS1.id,
        title: "Naquele Dia",
        number: 2,
        thumbnail: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&h=300&fit=crop",
        videoUrl: "https://example.com/videos/attack-on-titan-s1e2.mp4",
        duration: 1440,
        releaseDate: new Date("2013-04-14")
      },
      {
        animeId: attackOnTitan.id,
        seasonId: attackOnTitanS1.id,
        title: "Episódio Final",
        number: 3,
        thumbnail: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&h=300&fit=crop",
        videoUrl: "https://example.com/videos/attack-on-titan-final.mp4",
        duration: 1440,
        releaseDate: new Date(Date.now()) // Hoje
      }
    ];
    
    const demonSlayerEpisodes = [
      {
        animeId: demonSlayer.id,
        seasonId: demonSlayerS2.id,
        title: "Chamas da Destruição",
        number: 12,
        thumbnail: "https://images.unsplash.com/photo-1559981421-3e0c0d156372?w=500&h=300&fit=crop",
        videoUrl: "https://example.com/videos/demon-slayer-s2e12.mp4",
        duration: 1500, // 25 minutos
        releaseDate: new Date(Date.now() - 86400000) // Ontem
      },
      {
        animeId: demonSlayer.id,
        seasonId: demonSlayerS2.id,
        title: "O Pilar das Chamas",
        number: 13,
        thumbnail: "https://images.unsplash.com/photo-1559981421-3e0c0d156372?w=500&h=300&fit=crop",
        videoUrl: "https://example.com/videos/demon-slayer-s2e13.mp4",
        duration: 1500,
        releaseDate: new Date(Date.now() + 86400000) // Amanhã
      }
    ];
    
    const jujutsuKaisenEpisodes = [
      {
        animeId: jujutsuKaisen.id,
        seasonId: null as unknown as number,
        title: "Itadori Yuji e o Mundo Amaldiçoado",
        number: 8,
        thumbnail: "https://images.unsplash.com/photo-1541562232579-512a21360020?w=500&h=300&fit=crop",
        videoUrl: "https://example.com/videos/jujutsu-kaisen-e8.mp4",
        duration: 1440,
        releaseDate: new Date(Date.now() - 86400000 * 2) // 2 dias atrás
      }
    ];
    
    const spyFamilyEpisodes = [
      {
        animeId: spyFamily.id,
        seasonId: null as unknown as number,
        title: "Missão Familiar",
        number: 6,
        thumbnail: "https://images.unsplash.com/photo-1563089145-599997674d42?w=500&h=300&fit=crop",
        videoUrl: "https://example.com/videos/spy-family-e6.mp4",
        duration: 1500,
        releaseDate: new Date(Date.now() - 86400000 * 3) // 3 dias atrás
      }
    ];
    
    const onePieceEpisodes = [
      {
        animeId: onePiece.id,
        seasonId: null as unknown as number,
        title: "A Lenda de Kozuki Oden",
        number: 1024,
        thumbnail: "https://images.unsplash.com/photo-1560972550-aba3456b5564?w=500&h=300&fit=crop",
        videoUrl: "https://example.com/videos/one-piece-e1024.mp4",
        duration: 1440,
        releaseDate: new Date(Date.now() - 86400000 * 5) // 5 dias atrás
      }
    ];
    
    const myHeroAcademiaEpisodes = [
      {
        animeId: myHeroAcademia.id,
        seasonId: null as unknown as number,
        title: "Liga dos Vilões vs. Herói No. 1",
        number: 3,
        thumbnail: "https://images.unsplash.com/photo-1599685315640-4eebfc640523?w=500&h=300&fit=crop",
        videoUrl: "https://example.com/videos/my-hero-academia-e3.mp4",
        duration: 1440,
        releaseDate: new Date(Date.now() - 86400000 * 4) // 4 dias atrás
      }
    ];
    
    // Criar todos os episódios
    const allEpisodes = [
      ...attackOnTitanEpisodes, 
      ...demonSlayerEpisodes, 
      ...jujutsuKaisenEpisodes, 
      ...spyFamilyEpisodes, 
      ...onePieceEpisodes, 
      ...myHeroAcademiaEpisodes
    ];
    
    for (const episodeData of allEpisodes) {
      await this.createEpisode(episodeData);
    }
    
    // Adicionar entradas de calendário
    const weekdays = ["seg", "ter", "qua", "qui", "sex", "sab", "dom"];
    const calendarEntries = [
      {
        animeId: onePiece.id,
        episodeId: this.episodeIdCounter - 6,
        releaseDay: "seg",
        releaseTime: "20:00",
        title: "One Piece",
        description: "Episódio 1025"
      },
      {
        animeId: attackOnTitan.id,
        episodeId: this.episodeIdCounter - 7,
        releaseDay: "seg",
        releaseTime: "22:30",
        title: "Attack on Titan",
        description: "Episódio Final"
      },
      {
        animeId: spyFamily.id,
        episodeId: this.episodeIdCounter - 3,
        releaseDay: "seg",
        releaseTime: "23:15",
        title: "Spy x Family",
        description: "Episódio 7"
      },
      {
        animeId: demonSlayer.id,
        episodeId: this.episodeIdCounter - 5,
        releaseDay: "ter",
        releaseTime: "19:00",
        title: "Demon Slayer",
        description: "Episódio 13"
      },
      {
        animeId: myHeroAcademia.id,
        episodeId: this.episodeIdCounter - 1,
        releaseDay: "qui",
        releaseTime: "21:00",
        title: "My Hero Academia",
        description: "Episódio 4"
      },
      {
        animeId: jujutsuKaisen.id,
        episodeId: this.episodeIdCounter - 4,
        releaseDay: "sex",
        releaseTime: "18:30",
        title: "Jujutsu Kaisen",
        description: "Episódio 9"
      },
      {
        animeId: onePiece.id,
        episodeId: this.episodeIdCounter - 6,
        releaseDay: "dom",
        releaseTime: "20:00",
        title: "One Piece (Reprise)",
        description: "Episódio 1024"
      }
    ];
    
    for (const entry of calendarEntries) {
      await this.addCalendarEntry(entry);
    }
    
    // Criar alguns usuários para o ranking
    const users = [
      {
        username: "carlos_eduardo",
        password: "password123",
        name: "Carlos Eduardo",
        email: "carlos@example.com",
        avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=120&h=120&fit=crop",
        role: "user",
        animeWatched: 950
      },
      {
        username: "marina_silva",
        password: "password123",
        name: "Marina Silva",
        email: "marina@example.com",
        avatar: "https://images.unsplash.com/photo-1557862921-37829c790f19?w=80&h=80&fit=crop",
        role: "user",
        animeWatched: 720
      },
      {
        username: "ricardo_alves",
        password: "password123",
        name: "Ricardo Alves",
        email: "ricardo@example.com",
        avatar: "https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?w=80&h=80&fit=crop",
        role: "user",
        animeWatched: 685
      },
      {
        username: "juliana_costa",
        password: "password123",
        name: "Juliana Costa",
        email: "juliana@example.com",
        avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=80&h=80&fit=crop",
        role: "user",
        animeWatched: 612
      }
    ];
    
    for (const userData of users) {
      const id = this.userIdCounter++;
      const user: User = {
        ...userData,
        id,
        createdAt: new Date()
      };
      this.users.set(id, user);
    }
  }
}

export const storage = new MemStorage();
