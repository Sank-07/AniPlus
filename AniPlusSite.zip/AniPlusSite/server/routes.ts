import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertAnimeSchema, 
  insertSeasonSchema, 
  insertEpisodeSchema, 
  insertWatchHistorySchema,
  insertFavoriteSchema,
  insertCalendarSchema
} from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // API routes
  
  // Animes routes
  app.get("/api/animes", async (req, res) => {
    try {
      const animes = await storage.getAllAnimes();
      res.json(animes);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar animes" });
    }
  });

  app.get("/api/animes/:id", async (req, res) => {
    try {
      const animeId = parseInt(req.params.id);
      const anime = await storage.getAnime(animeId);
      
      if (!anime) {
        return res.status(404).json({ message: "Anime não encontrado" });
      }
      
      res.json(anime);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar anime" });
    }
  });
  
  // Endpoint para obter animes relacionados
  app.get("/api/animes/:id/related", async (req, res) => {
    try {
      const animeId = parseInt(req.params.id);
      const related = await storage.getRelatedAnimes(animeId);
      res.json(related);
    } catch (error) {
      console.error("Erro ao buscar animes relacionados:", error);
      res.status(500).json({ message: "Erro ao buscar animes relacionados" });
    }
  });

  // Seasons routes
  app.get("/api/seasons", async (req, res) => {
    try {
      // Buscar todos os animes para depois conseguir todas as temporadas
      const animes = await storage.getAllAnimes();
      const allSeasons = [];
      
      // Para cada anime, obter suas temporadas
      for (const anime of animes) {
        const seasons = await storage.getSeasonsByAnime(anime.id);
        const seasonsWithAnimeTitle = seasons.map(season => ({
          ...season,
          animeTitle: anime.title,
          // Como removemos title da temporada, vamos gerar um automaticamente
          title: `Temporada ${season.number}`
        }));
        allSeasons.push(...seasonsWithAnimeTitle);
      }
      
      // Ordenar pelo ID do anime e número da temporada
      allSeasons.sort((a, b) => {
        if (a.animeId === b.animeId) {
          return a.number - b.number;
        }
        return a.animeId - b.animeId;
      });
      
      res.json(allSeasons);
    } catch (error) {
      console.error("Erro ao buscar todas as temporadas:", error);
      res.status(500).json({ message: "Erro ao buscar todas as temporadas" });
    }
  });
  
  app.get("/api/animes/:id/seasons", async (req, res) => {
    try {
      const animeId = parseInt(req.params.id);
      const seasons = await storage.getSeasonsByAnime(animeId);
      
      // Adicionar o título gerado automaticamente a cada temporada
      const seasonsWithTitle = seasons.map(season => ({
        ...season,
        title: `Temporada ${season.number}`
      }));
      
      res.json(seasonsWithTitle);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar temporadas" });
    }
  });
  
  // Obter uma temporada específica pelo ID
  app.get("/api/seasons/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID da temporada inválido" });
      }
      
      const season = await storage.getSeason(id);
      if (!season) {
        return res.status(404).json({ message: "Temporada não encontrada" });
      }
      
      // Adicionar título automaticamente
      const seasonWithTitle = {
        ...season,
        title: `Temporada ${season.number}`
      };
      
      res.json(seasonWithTitle);
    } catch (error) {
      console.error("Erro ao buscar temporada:", error);
      res.status(500).json({ message: "Erro ao buscar temporada" });
    }
  });

  // Episodes routes
  app.get("/api/animes/:id/episodes", async (req, res) => {
    try {
      const animeId = parseInt(req.params.id);
      const episodes = await storage.getEpisodesByAnime(animeId);
      res.json(episodes);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar episódios" });
    }
  });

  app.get("/api/episodes/all", async (req, res) => {
    try {
      // Buscar todos os episódios de todos os animes
      const animes = await storage.getAllAnimes();
      const allEpisodes = [];
      
      for (const anime of animes) {
        const episodes = await storage.getEpisodesByAnime(anime.id);
        const episodesWithAnimeTitle = episodes.map(episode => ({
          ...episode,
          animeTitle: anime.title
        }));
        allEpisodes.push(...episodesWithAnimeTitle);
      }
      
      // Ordenar do mais recente para o mais antigo
      allEpisodes.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      
      res.json(allEpisodes);
    } catch (error) {
      console.error("Erro ao buscar todos os episódios:", error);
      res.status(500).json({ message: "Erro ao buscar todos os episódios" });
    }
  });
  
  app.get("/api/episodes/recent", async (req, res) => {
    try {
      const episodes = await storage.getRecentEpisodes();
      res.json(episodes);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar episódios recentes" });
    }
  });

  app.get("/api/episodes/:id", async (req, res) => {
    try {
      const episodeId = parseInt(req.params.id);
      const episode = await storage.getEpisode(episodeId);
      
      if (!episode) {
        return res.status(404).json({ message: "Episódio não encontrado" });
      }
      
      res.json(episode);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar episódio" });
    }
  });

  // Calendar routes
  app.get("/api/calendar", async (req, res) => {
    try {
      const calendar = await storage.getCalendar();
      res.json(calendar);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar calendário" });
    }
  });

  // User specific routes (require authentication)
  app.get("/api/user/history", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autorizado" });
    try {
      const history = await storage.getUserWatchHistory(req.user.id);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar histórico" });
    }
  });

  app.post("/api/user/history", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autorizado" });
    try {
      const parsedData = insertWatchHistorySchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const history = await storage.upsertWatchHistory(parsedData);
      res.status(201).json(history);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao salvar histórico" });
    }
  });

  app.get("/api/user/favorites", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autorizado" });
    try {
      const favorites = await storage.getUserFavorites(req.user.id);
      res.json(favorites);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar favoritos" });
    }
  });

  app.post("/api/user/favorites", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autorizado" });
    try {
      const parsedData = insertFavoriteSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      await storage.addFavorite(parsedData);
      res.status(201).json({ message: "Adicionado aos favoritos" });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao adicionar favorito" });
    }
  });

  app.delete("/api/user/favorites/:animeId", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autorizado" });
    try {
      const animeId = parseInt(req.params.animeId);
      await storage.removeFavorite(req.user.id, animeId);
      res.status(200).json({ message: "Removido dos favoritos" });
    } catch (error) {
      res.status(500).json({ message: "Erro ao remover favorito" });
    }
  });

  app.get("/api/user/continue-watching", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autorizado" });
    try {
      const continueWatching = await storage.getContinueWatching(req.user.id);
      res.json(continueWatching);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar 'continuar assistindo'" });
    }
  });
  
  // Rota para atualizar o perfil do usuário
  app.put("/api/user/profile", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autorizado" });
    try {
      const { name, email, avatar } = req.body;
      
      if (!name && !email && !avatar) {
        return res.status(400).json({ message: "Pelo menos um campo precisa ser fornecido para atualização" });
      }
      
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      
      // Atualizar campos do usuário
      if (name) user.name = name;
      if (email) user.email = email;
      if (avatar) user.avatar = avatar;
      
      // Salvar alterações
      storage.users.set(user.id, user);
      
      // Remover senha antes de enviar resposta
      const { password, ...userResponse } = user;
      
      res.json(userResponse);
    } catch (error) {
      console.error("Erro ao atualizar perfil:", error);
      res.status(500).json({ message: "Erro ao atualizar perfil do usuário" });
    }
  });
  
  // Rota para alterar a senha do usuário
  app.put("/api/user/change-password", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autorizado" });
    try {
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Senha atual e nova são obrigatórias" });
      }
      
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      
      // Verificar se a senha atual corresponde
      if (user.password !== currentPassword) {
        return res.status(400).json({ message: "Senha atual incorreta" });
      }
      
      // Atualizar senha
      user.password = newPassword;
      storage.users.set(user.id, user);
      
      res.json({ message: "Senha alterada com sucesso" });
    } catch (error) {
      console.error("Erro ao alterar senha:", error);
      res.status(500).json({ message: "Erro ao alterar senha do usuário" });
    }
  });

  // Rankings route
  app.get("/api/rankings", async (req, res) => {
    try {
      const rankings = await storage.getUserRankings();
      res.json(rankings);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar rankings" });
    }
  });

  // Admin routes
  app.post("/api/admin/animes", async (req, res) => {
    try {
      const parsedData = insertAnimeSchema.parse(req.body);
      const anime = await storage.createAnime(parsedData);
      res.status(201).json(anime);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao criar anime" });
    }
  });

  app.put("/api/admin/animes/:id", async (req, res) => {
    try {
      const animeId = parseInt(req.params.id);
      const parsedData = insertAnimeSchema.parse(req.body);
      const anime = await storage.updateAnime(animeId, parsedData);
      res.json(anime);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao atualizar anime" });
    }
  });

  app.delete("/api/admin/animes/:id", async (req, res) => {
    try {
      const animeId = parseInt(req.params.id);
      await storage.deleteAnime(animeId);
      res.status(200).json({ message: "Anime deletado com sucesso" });
    } catch (error) {
      res.status(500).json({ message: "Erro ao deletar anime" });
    }
  });

  app.post("/api/admin/seasons", async (req, res) => {
    try {
      const parsedData = insertSeasonSchema.parse(req.body);
      const season = await storage.createSeason(parsedData);
      
      // Adicionar título gerado automaticamente na resposta
      const seasonWithTitle = {
        ...season,
        title: `Temporada ${season.number}`
      };
      
      res.status(201).json(seasonWithTitle);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao criar temporada" });
    }
  });

  app.put("/api/admin/seasons/:id", async (req, res) => {
    try {
      const seasonId = parseInt(req.params.id);
      const parsedData = insertSeasonSchema.parse(req.body);
      const season = await storage.updateSeason(seasonId, parsedData);
      
      // Adicionar título gerado automaticamente na resposta
      const seasonWithTitle = {
        ...season,
        title: `Temporada ${season.number}`
      };
      
      res.json(seasonWithTitle);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao atualizar temporada" });
    }
  });

  app.delete("/api/admin/seasons/:id", async (req, res) => {
    try {
      const seasonId = parseInt(req.params.id);
      await storage.deleteSeason(seasonId);
      res.status(200).json({ message: "Temporada deletada com sucesso" });
    } catch (error) {
      res.status(500).json({ message: "Erro ao deletar temporada" });
    }
  });

  app.post("/api/admin/episodes", async (req, res) => {
    try {
      console.log("Dados recebidos para criar episódio:", req.body);
      
      const data = { ...req.body };
      
      // Validar dados manualmente
      if (!data.title || data.title.trim() === "") {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["title"], message: "O título é obrigatório" }]
        });
      }
      
      if (!data.videoUrl || data.videoUrl.trim() === "") {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["videoUrl"], message: "URL do vídeo é obrigatória" }]
        });
      }
      
      if (!data.thumbnail || data.thumbnail.trim() === "") {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["thumbnail"], message: "URL da thumbnail é obrigatória" }]
        });
      }
      
      if (!data.animeId || typeof data.animeId !== 'number') {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["animeId"], message: "ID do anime é obrigatório" }]
        });
      }
      
      if (!data.number || typeof data.number !== 'number' || data.number < 1) {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["number"], message: "Número do episódio deve ser maior que 0" }]
        });
      }
      
      if (!data.duration || typeof data.duration !== 'number' || data.duration < 1) {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["duration"], message: "Duração deve ser maior que 0" }]
        });
      }
      
      if (data.releaseDate && typeof data.releaseDate === 'string') {
        try {
          if (isNaN(Date.parse(data.releaseDate))) {
            return res.status(400).json({
              message: "Dados inválidos",
              errors: [{ path: ["releaseDate"], message: "Data de lançamento inválida" }]
            });
          }
          // Convertemos para objeto Date aqui
          data.releaseDate = new Date(data.releaseDate);
        } catch (dateError) {
          return res.status(400).json({
            message: "Dados inválidos",
            errors: [{ path: ["releaseDate"], message: "Data de lançamento inválida" }]
          });
        }
      } else if (!data.releaseDate) {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["releaseDate"], message: "Data de lançamento é obrigatória" }]
        });
      }
      
      // Converter seasonId para null se for 0
      if (data.seasonId === 0) {
        data.seasonId = null;
      }
      
      console.log("Dados validados para criar episódio:", data);
      const episode = await storage.createEpisode(data);
      console.log("Episódio criado:", episode);
      res.status(201).json(episode);
    } catch (error) {
      console.error("Erro ao criar episódio:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao criar episódio" });
    }
  });

  app.put("/api/admin/episodes/:id", async (req, res) => {
    try {
      const episodeId = parseInt(req.params.id);
      console.log(`Dados recebidos para atualizar episódio ${episodeId}:`, req.body);
      
      const data = { ...req.body };
      
      // Validar dados manualmente
      if (!data.title || data.title.trim() === "") {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["title"], message: "O título é obrigatório" }]
        });
      }
      
      if (!data.videoUrl || data.videoUrl.trim() === "") {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["videoUrl"], message: "URL do vídeo é obrigatória" }]
        });
      }
      
      if (!data.thumbnail || data.thumbnail.trim() === "") {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["thumbnail"], message: "URL da thumbnail é obrigatória" }]
        });
      }
      
      if (!data.animeId || typeof data.animeId !== 'number') {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["animeId"], message: "ID do anime é obrigatório" }]
        });
      }
      
      if (!data.number || typeof data.number !== 'number' || data.number < 1) {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["number"], message: "Número do episódio deve ser maior que 0" }]
        });
      }
      
      if (!data.duration || typeof data.duration !== 'number' || data.duration < 1) {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["duration"], message: "Duração deve ser maior que 0" }]
        });
      }
      
      if (data.releaseDate && typeof data.releaseDate === 'string') {
        try {
          if (isNaN(Date.parse(data.releaseDate))) {
            return res.status(400).json({
              message: "Dados inválidos",
              errors: [{ path: ["releaseDate"], message: "Data de lançamento inválida" }]
            });
          }
          // Convertemos para objeto Date aqui
          data.releaseDate = new Date(data.releaseDate);
        } catch (dateError) {
          return res.status(400).json({
            message: "Dados inválidos",
            errors: [{ path: ["releaseDate"], message: "Data de lançamento inválida" }]
          });
        }
      } else if (!data.releaseDate) {
        return res.status(400).json({
          message: "Dados inválidos",
          errors: [{ path: ["releaseDate"], message: "Data de lançamento é obrigatória" }]
        });
      }
      
      // Converter seasonId para null se for 0
      if (data.seasonId === 0) {
        data.seasonId = null;
      }
      
      console.log(`Dados validados para atualizar episódio ${episodeId}:`, data);
      const episode = await storage.updateEpisode(episodeId, data);
      console.log(`Episódio ${episodeId} atualizado:`, episode);
      res.json(episode);
    } catch (error) {
      console.error(`Erro ao atualizar episódio:`, error);
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao atualizar episódio" });
    }
  });

  app.delete("/api/admin/episodes/:id", async (req, res) => {
    try {
      const episodeId = parseInt(req.params.id);
      await storage.deleteEpisode(episodeId);
      res.status(200).json({ message: "Episódio deletado com sucesso" });
    } catch (error) {
      res.status(500).json({ message: "Erro ao deletar episódio" });
    }
  });

  app.post("/api/admin/calendar", async (req, res) => {
    try {
      const parsedData = insertCalendarSchema.parse(req.body);
      const calendarEntry = await storage.addCalendarEntry(parsedData);
      res.status(201).json(calendarEntry);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao adicionar entrada no calendário" });
    }
  });

  app.put("/api/admin/calendar/:id", async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const parsedData = insertCalendarSchema.parse(req.body);
      const calendarEntry = await storage.updateCalendarEntry(entryId, parsedData);
      res.json(calendarEntry);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro ao atualizar entrada no calendário" });
    }
  });

  app.delete("/api/admin/calendar/:id", async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      await storage.deleteCalendarEntry(entryId);
      res.status(200).json({ message: "Entrada do calendário deletada com sucesso" });
    } catch (error) {
      res.status(500).json({ message: "Erro ao deletar entrada do calendário" });
    }
  });

  app.get("/api/admin/stats", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const totalUsers = users.length;
      const totalAdmins = users.filter(user => user.role === "admin").length;
      
      const animes = await storage.getAllAnimes();
      const totalAnimes = animes.length;
      
      // Contar todos os episódios
      let totalEpisodes = 0;
      for (const anime of animes) {
        const episodes = await storage.getEpisodesByAnime(anime.id);
        totalEpisodes += episodes.length;
      }
      
      // Obter histórico de visualização total
      const watchCount = Array.from(storage.watchHistories.values()).length;
      
      // Contar favoritos totais
      const favoriteCount = storage.favorites.size;
      
      // Calcular estatísticas do calendário
      const calendar = await storage.getCalendar();
      
      // Enviar estatísticas
      res.json({
        totalUsers,
        totalAdmins,
        totalAnimes,
        totalEpisodes,
        watchCount,
        favoriteCount,
        calendarEntries: calendar.length,
        // Adicionar estatísticas por dia
        dailyReleases: {
          seg: calendar.filter(entry => entry.releaseDay === "seg").length,
          ter: calendar.filter(entry => entry.releaseDay === "ter").length,
          qua: calendar.filter(entry => entry.releaseDay === "qua").length,
          qui: calendar.filter(entry => entry.releaseDay === "qui").length,
          sex: calendar.filter(entry => entry.releaseDay === "sex").length,
          sab: calendar.filter(entry => entry.releaseDay === "sab").length,
          dom: calendar.filter(entry => entry.releaseDay === "dom").length,
        }
      });
    } catch (error) {
      console.error("Erro ao gerar estatísticas:", error);
      res.status(500).json({ message: "Erro ao gerar estatísticas" });
    }
  });

  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar usuários" });
    }
  });

  // Rota especial para atualizar a função de um usuário
  app.patch("/api/admin/users/:id/role", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { role } = req.body;
      
      if (!role || (role !== "admin" && role !== "user")) {
        return res.status(400).json({ message: "Função inválida" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      
      // Atualizar o usuário
      user.role = role;
      
      // Como não temos um método específico para atualizar atributos do usuário,
      // vamos repassar para o map diretamente
      await storage.users.set(userId, user);
      
      res.json({ message: `Usuário atualizado para ${role}` });
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar função do usuário" });
    }
  });
  
  // A rota para promover SankSS a administrador foi movida para auth.ts

  const httpServer = createServer(app);
  return httpServer;
}
