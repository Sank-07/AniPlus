import { pgTable, text, serial, integer, boolean, timestamp, primaryKey, json, type PgTableWithColumns } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Usuários
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  avatar: text("avatar"),
  role: text("role").default("user").notNull(),
  animeWatched: integer("anime_watched").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Animes
export const animes = pgTable("animes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  synopsis: text("synopsis").notNull(),
  coverImage: text("cover_image").notNull(),
  bannerImage: text("banner_image"),
  rating: integer("rating").default(0).notNull(),
  audioLanguage: text("audio_language").default("legendado").notNull(), // dublado ou legendado
  releaseYear: integer("release_year").notNull(),
  status: text("status").notNull(), // Em andamento, Concluído, etc.
  genres: json("genres").$type<string[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Temporadas
export const seasons = pgTable("seasons", {
  id: serial("id").primaryKey(),
  animeId: integer("anime_id").notNull().references(() => animes.id),
  number: integer("number").notNull(),
  releaseYear: integer("release_year").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Episódios
export const episodes = pgTable("episodes", {
  id: serial("id").primaryKey(),
  animeId: integer("anime_id").notNull().references(() => animes.id),
  seasonId: integer("season_id").references(() => seasons.id),
  title: text("title").notNull(),
  number: integer("number").notNull(),
  thumbnail: text("thumbnail").notNull(),
  videoUrl: text("video_url").notNull(), // URL padrão (qualidade 720p)
  videoUrl1080p: text("video_url_1080p"), // URL para qualidade 1080p
  videoUrl480p: text("video_url_480p"),   // URL para qualidade 480p  
  videoUrl360p: text("video_url_360p"),   // URL para qualidade 360p
  duration: integer("duration").notNull(), // Em segundos
  releaseDate: timestamp("release_date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Histórico de visualização
export const watchHistory = pgTable("watch_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  animeId: integer("anime_id").notNull().references(() => animes.id),
  episodeId: integer("episode_id").notNull().references(() => episodes.id),
  watchedAt: timestamp("watched_at").defaultNow().notNull(),
  progress: integer("progress").default(0).notNull(), // Em segundos
  completed: boolean("completed").default(false).notNull(),
});

// Favoritos
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  animeId: integer("anime_id").notNull().references(() => animes.id),
});

// Calendário
export const calendar = pgTable("calendar", {
  id: serial("id").primaryKey(),
  animeId: integer("anime_id").notNull().references(() => animes.id),
  episodeId: integer("episode_id").references(() => episodes.id),
  releaseDay: text("release_day").notNull(), // seg, ter, qua, qui, sex, sab, dom
  releaseTime: text("release_time").notNull(), // Format: HH:MM
  title: text("title").notNull(),
  description: text("description"),
});

// Esquemas de inserção
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  animeWatched: true,
});

export const insertAnimeSchema = createInsertSchema(animes).omit({
  id: true,
  createdAt: true,
  rating: true,
});

export const insertSeasonSchema = createInsertSchema(seasons).omit({
  id: true,
  createdAt: true,
});

// Criar o schema manualmente para ter controle total sobre os tipos
export const insertEpisodeSchema = z.object({
  animeId: z.number(),
  seasonId: z.number().nullable(),
  title: z.string(),
  number: z.number(),
  thumbnail: z.string(),
  videoUrl: z.string(),
  videoUrl1080p: z.string().optional(),
  videoUrl480p: z.string().optional(),
  videoUrl360p: z.string().optional(),
  duration: z.number(),
  releaseDate: z.union([z.string(), z.date()]), // Aceitar tanto string quanto Date
});

export const insertWatchHistorySchema = createInsertSchema(watchHistory).omit({
  id: true,
  watchedAt: true,
});

export const insertFavoriteSchema = createInsertSchema(favorites).omit({
  id: true,
});

export const insertCalendarSchema = createInsertSchema(calendar).omit({
  id: true,
});

// Tipos
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Anime = typeof animes.$inferSelect;
export type InsertAnime = z.infer<typeof insertAnimeSchema>;

export type Season = typeof seasons.$inferSelect;
export type InsertSeason = z.infer<typeof insertSeasonSchema>;

export type Episode = typeof episodes.$inferSelect;
export type InsertEpisode = z.infer<typeof insertEpisodeSchema>;

export type WatchHistory = typeof watchHistory.$inferSelect;
export type InsertWatchHistory = z.infer<typeof insertWatchHistorySchema>;

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;

export type Calendar = typeof calendar.$inferSelect;
export type InsertCalendar = z.infer<typeof insertCalendarSchema>;
