import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertUserSchema, InsertUser } from "@shared/schema";
import { Loader2 } from "lucide-react";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";

// Login schema
const loginSchema = z.object({
  username: z.string().min(1, "Nome de usuário é obrigatório"),
  password: z.string().min(1, "Senha é obrigatória"),
});

type LoginValues = z.infer<typeof loginSchema>;

// Registration schema
const registerSchema = insertUserSchema.extend({
  password: z.string()
    .min(6, "A senha deve ter pelo menos 6 caracteres"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "As senhas não coincidem",
  path: ["confirmPassword"],
});

type RegisterValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  const { user, loginMutation, registerMutation, isLoading } = useAuth();
  
  // Login form
  const loginForm = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });
  
  const onLoginSubmit = (data: LoginValues) => {
    loginMutation.mutate(data);
  };
  
  // Register form
  const registerForm = useForm<RegisterValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: "",
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      avatar: "",
    },
  });
  
  const onRegisterSubmit = (data: RegisterValues) => {
    // Remove confirmPassword as it's not expected in the InsertUser type
    const { confirmPassword, ...registerData } = data;
    registerMutation.mutate(registerData as InsertUser);
  };
  
  // Redirect if user is already logged in - deve ficar APÓS declaração de todos os hooks
  if (user) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Hero Section (Right Side on Desktop) */}
      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-primary to-secondary p-8 text-white justify-center items-center">
        <div className="max-w-md">
          <h1 className="text-4xl font-bold mb-4 font-poppins">AniPlus</h1>
          <p className="text-lg mb-6">
            Sua plataforma completa de streaming de animes com milhares de títulos, 
            atualizações diárias, e uma experiência personalizada para cada fã de anime.
          </p>
          <ul className="space-y-4">
            <li className="flex items-center">
              <span className="bg-white text-primary rounded-full w-6 h-6 flex items-center justify-center mr-2">✓</span>
              Assista a episódios recentes de seus animes favoritos
            </li>
            <li className="flex items-center">
              <span className="bg-white text-primary rounded-full w-6 h-6 flex items-center justify-center mr-2">✓</span>
              Mantenha seu histórico de visualização e continue de onde parou
            </li>
            <li className="flex items-center">
              <span className="bg-white text-primary rounded-full w-6 h-6 flex items-center justify-center mr-2">✓</span>
              Adicione animes à sua lista de favoritos
            </li>
            <li className="flex items-center">
              <span className="bg-white text-primary rounded-full w-6 h-6 flex items-center justify-center mr-2">✓</span>
              Participe do ranking de usuários da plataforma
            </li>
          </ul>
        </div>
      </div>
      
      {/* Auth Forms (Left Side on Desktop) */}
      <div className="flex-1 bg-dark-700 p-6 md:p-8 flex items-center justify-center">
        <div className="w-full max-w-md">
          <div className="text-center mb-6 md:hidden">
            <h1 className="text-3xl font-bold text-primary font-montserrat">Ani<span className="text-accent">Plus</span></h1>
            <p className="text-white opacity-80 mt-2">Sua plataforma de streaming de animes</p>
          </div>
          
          <div className="bg-dark-600 p-6 rounded-lg shadow-lg">
            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "login" | "register")}>
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">Entrar</TabsTrigger>
                <TabsTrigger value="register">Cadastrar</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome de Usuário</FormLabel>
                          <FormControl>
                            <Input placeholder="Seu nome de usuário" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Senha</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Sua senha" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={isLoading || loginMutation.isPending}
                    >
                      {(isLoading || loginMutation.isPending) && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      Entrar
                    </Button>
                  </form>
                </Form>
                
                <div className="mt-4 text-center text-sm text-muted-foreground">
                  Não tem uma conta?{" "}
                  <button
                    onClick={() => setActiveTab("register")}
                    className="text-primary hover:underline"
                  >
                    Cadastre-se
                  </button>
                </div>
              </TabsContent>
              
              <TabsContent value="register">
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome Completo</FormLabel>
                          <FormControl>
                            <Input placeholder="Seu nome completo" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome de Usuário</FormLabel>
                          <FormControl>
                            <Input placeholder="Escolha um nome de usuário" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="seu@email.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="avatar"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>URL do Avatar (Opcional)</FormLabel>
                          <FormControl>
                            <Input placeholder="https://example.com/avatar.jpg" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <FormField
                        control={registerForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Senha</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Sua senha" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Confirmar Senha</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Confirme sua senha" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={isLoading || registerMutation.isPending}
                    >
                      {(isLoading || registerMutation.isPending) && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      Cadastrar
                    </Button>
                  </form>
                </Form>
                
                <div className="mt-4 text-center text-sm text-muted-foreground">
                  Já tem uma conta?{" "}
                  <button
                    onClick={() => setActiveTab("login")}
                    className="text-primary hover:underline"
                  >
                    Faça login
                  </button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          <div className="mt-8 text-center">
            <Link href="/" className="text-muted-foreground hover:text-primary text-sm">
              Voltar para página inicial
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
