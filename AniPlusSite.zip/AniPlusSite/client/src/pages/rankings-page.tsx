import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Star, Crown, Award, Users } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";

export default function RankingsPage() {
  const { data: rankings, isLoading } = useQuery<User[]>({
    queryKey: ["/api/rankings"],
  });

  // Verificar carregamento
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 bg-dark-700">
          <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold mb-6">Ranking de Usuários</h1>
            <div className="bg-dark-600 rounded-lg p-6">
              <div className="space-y-6">
                {[...Array(10)].map((_, i) => (
                  <div key={i} className="flex items-center p-4 bg-dark-500 rounded-lg">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="ml-4 flex-1">
                      <Skeleton className="h-5 w-48 mb-2" />
                      <Skeleton className="h-4 w-32" />
                    </div>
                    <Skeleton className="h-8 w-24" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const rankingsList = rankings || [];

  // Função para determinar o ícone e a cor baseado na posição
  function getRankingBadge(position: number) {
    if (position === 0) {
      return {
        icon: <Crown className="mr-2" size={18} />,
        color: "bg-yellow-500 text-dark-800"
      };
    } else if (position === 1) {
      return {
        icon: <Medal className="mr-2" size={18} />,
        color: "bg-gray-300 text-dark-800"
      };
    } else if (position === 2) {
      return {
        icon: <Award className="mr-2" size={18} />,
        color: "bg-amber-600 text-dark-800"
      };
    } else if (position < 10) {
      return {
        icon: <Star className="mr-2" size={18} />,
        color: "bg-primary/80 text-white"
      };
    } else {
      return {
        icon: <Trophy className="mr-2" size={18} />,
        color: "bg-dark-400 text-white"
      };
    }
  }

  // Função para determinar o título baseado na posição
  function getUserRankTitle(position: number, animeCount: number) {
    if (position === 0) return "Otaku Lendário";
    if (position === 1) return "Otaku Mestre";
    if (position === 2) return "Otaku Elite";
    if (position < 10) return "Otaku Veterano";
    if (animeCount > 50) return "Otaku Dedicado";
    if (animeCount > 20) return "Otaku Intermediário";
    return "Otaku Iniciante";
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 bg-dark-700">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <h1 className="text-3xl font-bold">Ranking de Usuários</h1>
            <div className="flex items-center mt-4 md:mt-0">
              <Users className="text-primary mr-2" size={20} />
              <span className="text-dark-100">
                {rankingsList.length} usuários no ranking
              </span>
            </div>
          </div>

          <div className="bg-dark-600 rounded-lg shadow-lg overflow-hidden">
            <Tabs defaultValue="animes" className="w-full">
              <div className="px-6 pt-6">
                <TabsList className="grid w-full max-w-md grid-cols-2">
                  <TabsTrigger value="animes">Animes Assistidos</TabsTrigger>
                  <TabsTrigger value="episodios">Episódios Assistidos</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="animes" className="p-6">
                <div className="space-y-4">
                  {rankingsList.map((user, index) => (
                    <div key={user.id} className="flex items-center p-4 bg-dark-500 rounded-lg hover:bg-dark-400 transition">
                      <div className="flex items-center justify-center w-10 h-10 rounded-full bg-dark-400 mr-4 text-white font-bold">
                        {index + 1}
                      </div>
                      
                      <Avatar className="h-14 w-14 border-2 border-primary">
                        <AvatarImage src={user.avatar || undefined} alt={user.username} />
                        <AvatarFallback className="bg-gradient-to-br from-primary to-purple-600">
                          {user.username.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="ml-4 flex-1">
                        <div className="flex items-center">
                          <h3 className="font-bold text-lg">{user.username}</h3>
                          {user.role === "admin" && (
                            <Badge className="ml-2 bg-primary text-white">Admin</Badge>
                          )}
                        </div>
                        <p className="text-dark-100">
                          {getUserRankTitle(index, user.animeWatched || 0)}
                        </p>
                      </div>
                      
                      <Badge className={`flex items-center ${getRankingBadge(index).color} ml-2`}>
                        {getRankingBadge(index).icon}
                        <span>{user.animeWatched || 0} animes</span>
                      </Badge>
                    </div>
                  ))}
                  
                  {rankingsList.length === 0 && (
                    <div className="text-center py-8">
                      <Trophy className="text-dark-300 mx-auto mb-4" size={48} />
                      <h3 className="text-xl font-bold mb-2">Ranking vazio</h3>
                      <p className="text-dark-200">
                        Nenhum usuário assistiu animes ainda.
                        <br />Seja o primeiro a entrar no ranking!
                      </p>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="episodios" className="p-6">
                <div className="space-y-4">
                  {rankingsList
                    .sort((a, b) => (b.episodesWatched || 0) - (a.episodesWatched || 0))
                    .map((user, index) => (
                    <div key={user.id} className="flex items-center p-4 bg-dark-500 rounded-lg hover:bg-dark-400 transition">
                      <div className="flex items-center justify-center w-10 h-10 rounded-full bg-dark-400 mr-4 text-white font-bold">
                        {index + 1}
                      </div>
                      
                      <Avatar className="h-14 w-14 border-2 border-secondary">
                        <AvatarImage src={user.avatar || undefined} alt={user.username} />
                        <AvatarFallback className="bg-gradient-to-br from-secondary to-cyan-600">
                          {user.username.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="ml-4 flex-1">
                        <div className="flex items-center">
                          <h3 className="font-bold text-lg">{user.username}</h3>
                          {user.role === "admin" && (
                            <Badge className="ml-2 bg-primary text-white">Admin</Badge>
                          )}
                        </div>
                        <p className="text-dark-100">
                          {index === 0 ? "Maratonista Supremo" : 
                           index === 1 ? "Maratonista Elite" : 
                           index === 2 ? "Maratonista Dedicado" : "Maratonista"}
                        </p>
                      </div>
                      
                      <Badge className={`flex items-center ${getRankingBadge(index).color} ml-2`}>
                        {getRankingBadge(index).icon}
                        <span>{user.episodesWatched || 0} episódios</span>
                      </Badge>
                    </div>
                  ))}
                  
                  {rankingsList.length === 0 && (
                    <div className="text-center py-8">
                      <Trophy className="text-dark-300 mx-auto mb-4" size={48} />
                      <h3 className="text-xl font-bold mb-2">Ranking vazio</h3>
                      <p className="text-dark-200">
                        Nenhum usuário assistiu episódios ainda.
                        <br />Seja o primeiro a entrar no ranking!
                      </p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}