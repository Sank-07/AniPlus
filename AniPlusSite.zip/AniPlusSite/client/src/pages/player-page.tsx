import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Episode, Anime } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { VideoPlayer } from "@/components/player/video-player";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Calendar, Clock, Film } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { EpisodeCard } from "@/components/anime/episode-card";

export default function PlayerPage() {
  const { id } = useParams<{ id: string }>();
  const episodeId = parseInt(id);

  // Fetch the current episode
  const { data: episode, isLoading: isLoadingEpisode } = useQuery<Episode>({
    queryKey: [`/api/episodes/${episodeId}`],
    enabled: !isNaN(episodeId),
  });

  // Fetch the anime details if episode is loaded
  const { data: anime, isLoading: isLoadingAnime } = useQuery<Anime>({
    queryKey: [`/api/animes/${episode?.animeId}`],
    enabled: !!episode?.animeId,
  });

  // Fetch all episodes of this anime for the episode list
  const { data: allEpisodes = [], isLoading: isLoadingAllEpisodes } = useQuery<Episode[]>({
    queryKey: [`/api/animes/${episode?.animeId}/episodes`],
    enabled: !!episode?.animeId,
  });

  // Get previous and next episodes
  const currentEpisodeIndex = allEpisodes.findIndex(ep => ep.id === episodeId);
  const prevEpisode = currentEpisodeIndex > 0 ? allEpisodes[currentEpisodeIndex - 1] : null;
  const nextEpisode = currentEpisodeIndex < allEpisodes.length - 1 ? allEpisodes[currentEpisodeIndex + 1] : null;

  // Get watch history for this episode to resume from where the user left off
  const { data: watchHistory } = useQuery({
    queryKey: [`/api/user/history/${episodeId}`],
    enabled: !!episodeId,
  });

  const savedProgress = watchHistory?.progress || 0;

  if (isLoadingEpisode || isLoadingAnime) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!episode || !anime) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center p-8">
            <h1 className="text-3xl font-bold mb-4">Episódio não encontrado</h1>
            <p className="mb-6">O episódio que você está procurando não existe ou foi removido.</p>
            <Link href="/">
              <Button>Voltar para a página inicial</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 bg-dark-700">
        <div className="container mx-auto px-4 py-6">
          {/* Navigation links */}
          <div className="mb-6">
            <div className="flex flex-wrap items-center text-sm text-dark-100">
              <Link href="/" className="hover:text-primary">Início</Link>
              <ChevronRight className="mx-1" size={14} />
              <Link href="/animes" className="hover:text-primary">Animes</Link>
              <ChevronRight className="mx-1" size={14} />
              <Link href={`/anime/${anime.id}`} className="hover:text-primary">{anime.title}</Link>
              <ChevronRight className="mx-1" size={14} />
              <span className="text-muted-foreground">Episódio {episode.number}</span>
            </div>
          </div>
          
          {/* Video Player */}
          <div className="bg-dark-600 rounded-lg overflow-hidden shadow-lg">
            <div className="aspect-video relative">
              <VideoPlayer
                episodeId={episode.id}
                animeId={anime.id}
                videoUrl={episode.videoUrl}
                title={`${anime.title} - Episódio ${episode.number}`}
                savedProgress={savedProgress}
                duration={episode.duration}
                qualityOptions={{
                  ...(episode.videoUrl1080p ? { "1080p": episode.videoUrl1080p } : {}),
                  "720p": episode.videoUrl,
                  ...(episode.videoUrl480p ? { "480p": episode.videoUrl480p } : {}),
                  ...(episode.videoUrl360p ? { "360p": episode.videoUrl360p } : {})
                }}
              />
            </div>
            
            <div className="p-6">
              <div className="flex flex-wrap justify-between items-center gap-4">
                <div>
                  <h1 className="text-xl md:text-2xl font-bold">{anime.title}</h1>
                  <h2 className="text-lg text-dark-100">Episódio {episode.number}{episode.title ? `: ${episode.title}` : ''}</h2>
                </div>
                
                <div className="flex items-center space-x-2">
                  {prevEpisode && (
                    <Link href={`/player/${prevEpisode.id}`}>
                      <Button variant="outline" className="flex items-center">
                        <ChevronLeft size={16} className="mr-1" /> Anterior
                      </Button>
                    </Link>
                  )}
                  
                  {nextEpisode && (
                    <Link href={`/player/${nextEpisode.id}`}>
                      <Button className="flex items-center">
                        Próximo <ChevronRight size={16} className="ml-1" />
                      </Button>
                    </Link>
                  )}
                </div>
              </div>
              
              <div className="flex flex-wrap gap-4 mt-4 text-sm text-dark-100">
                <div className="flex items-center">
                  <Calendar size={16} className="mr-1" />
                  <span>{format(new Date(episode.releaseDate), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}</span>
                </div>
                <div className="flex items-center">
                  <Clock size={16} className="mr-1" />
                  <span>{Math.floor(episode.duration / 60)} minutos</span>
                </div>
                <div className="flex items-center">
                  <Film size={16} className="mr-1" />
                  <span>{anime.type}</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* More Episodes */}
          <div className="mt-8">
            <h3 className="text-xl font-bold mb-4">Mais Episódios</h3>
            
            {isLoadingAllEpisodes ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="bg-dark-600 rounded-lg overflow-hidden shadow-lg">
                    <Skeleton className="w-full h-40" />
                    <div className="p-3">
                      <Skeleton className="h-5 w-3/4 mb-1" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {allEpisodes.map((ep) => (
                  <EpisodeCard 
                    key={ep.id} 
                    episode={ep} 
                    animeTitle={anime.title}
                    className={ep.id === episodeId ? "ring-2 ring-primary" : ""}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
