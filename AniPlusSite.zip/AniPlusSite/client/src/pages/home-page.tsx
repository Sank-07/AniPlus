import { useQuery } from "@tanstack/react-query";
import { Anime, Episode, User, Calendar } from "@shared/schema";
import { WatchHistory } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { HeroSection } from "@/components/home/hero-section";
import { ContinueWatchingSection } from "@/components/home/continue-watching-section";
import { CalendarSection } from "@/components/home/calendar-section";
import { RecentEpisodesSection } from "@/components/home/recent-episodes-section";
import { PopularAnimeSection } from "@/components/home/popular-anime-section";
import { UserRankingsSection } from "@/components/home/user-rankings-section";
import { useAuth } from "@/hooks/use-auth";
import { getQueryFn } from "@/lib/queryClient";

export default function HomePage() {
  const { user } = useAuth();
  
  // Featured anime for the hero section
  const { data: featuredAnime, isLoading: isLoadingFeatured } = useQuery<Anime>({
    queryKey: ["/api/animes/1"], // Assuming ID 1 is a good anime for featured content
  });
  
  // Continue watching - só busca se o usuário estiver logado
  const { data: continueWatching = [], isLoading: isLoadingContinueWatching } = useQuery<WatchHistory[]>({
    queryKey: ["/api/user/continue-watching"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!user
  });
  
  // Fetch anime and episode details for the continue watching section
  const continueWatchingWithDetails = continueWatching.map(history => {
    // In a real app, these would be fetched properly with additional queries
    // For simplicity, we'll assume the server sends back the required data
    return {
      ...history,
      animeTitle: "Anime Title", // This would be populated from proper fetching
      episodeTitle: "Episode Title",
      seasonTitle: "Season Title",
      thumbnail: "https://images.unsplash.com/photo-1559981421-3e0c0d156372?w=500&h=300&fit=crop",
      duration: 1440
    };
  });
  
  // Calendar entries
  const { data: calendar = [], isLoading: isLoadingCalendar } = useQuery<Calendar[]>({
    queryKey: ["/api/calendar"],
  });
  
  // Fetch anime cover images for calendar entries
  const calendarWithImages = calendar.map(entry => ({
    ...entry,
    animeCoverImage: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=60&h=60&fit=crop"
  }));
  
  // Recent episodes
  const { data: recentEpisodes = [], isLoading: isLoadingRecentEpisodes } = useQuery<Episode[]>({
    queryKey: ["/api/episodes/recent"],
  });
  
  // Add anime titles to recent episodes
  const recentEpisodesWithTitles = recentEpisodes.map(episode => ({
    ...episode,
    animeTitle: "Anime Title" // This would be populated from proper fetching
  }));
  
  // Popular animes
  const { data: popularAnimes = [], isLoading: isLoadingPopularAnimes } = useQuery<Anime[]>({
    queryKey: ["/api/animes"],
  });
  
  // User rankings
  const { data: userRankings = [], isLoading: isLoadingUserRankings } = useQuery<User[]>({
    queryKey: ["/api/rankings"],
  });
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <HeroSection 
          anime={featuredAnime || null} 
          isLoading={isLoadingFeatured} 
        />
        
        {user && continueWatchingWithDetails.length > 0 && (
          <ContinueWatchingSection 
            continueWatching={continueWatchingWithDetails}
            isLoading={isLoadingContinueWatching}
          />
        )}
        
        <CalendarSection 
          calendar={calendarWithImages}
          isLoading={isLoadingCalendar}
        />
        
        <RecentEpisodesSection 
          episodes={recentEpisodesWithTitles}
          isLoading={isLoadingRecentEpisodes}
        />
        
        <PopularAnimeSection 
          animes={popularAnimes}
          isLoading={isLoadingPopularAnimes}
        />
        
        <UserRankingsSection 
          users={userRankings}
          isLoading={isLoadingUserRankings}
        />
      </main>
      
      <Footer />
    </div>
  );
}
