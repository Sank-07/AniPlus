import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Anime, Episode, Season } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Play, Plus, CheckCircle, Calendar, Star, Info, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EpisodeCard } from "@/components/anime/episode-card";
import { apiRequest, queryClient, getQueryFn } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function AnimeDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const animeId = parseInt(id);
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("episodes");

  // Fetch anime details
  const { data: anime, isLoading: isLoadingAnime } = useQuery<Anime>({
    queryKey: [`/api/animes/${animeId}`],
    enabled: !isNaN(animeId),
  });

  // Fetch anime seasons
  const { data: seasons = [], isLoading: isLoadingSeasons } = useQuery<Season[]>({
    queryKey: [`/api/animes/${animeId}/seasons`],
    enabled: !isNaN(animeId),
  });

  // Fetch anime episodes
  const { data: episodes = [], isLoading: isLoadingEpisodes } = useQuery<Episode[]>({
    queryKey: [`/api/animes/${animeId}/episodes`],
    enabled: !isNaN(animeId),
  });
  
  // Fetch related animes
  const { data: relatedAnimes = [], isLoading: isLoadingRelated } = useQuery<Anime[]>({
    queryKey: [`/api/animes/${animeId}/related`],
    enabled: !isNaN(animeId) && activeTab === "related",
  });

  // Check if anime is in favorites (apenas se o usuário estiver logado)
  const { data: favorites = [], isLoading: isLoadingFavorites } = useQuery<Anime[]>({
    queryKey: ["/api/user/favorites"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!user
  });

  const isInFavorites = user ? favorites.some(fav => fav.id === animeId) : false;

  // Add to favorites
  const addToFavorites = async () => {
    try {
      await apiRequest("POST", "/api/user/favorites", { animeId });
      queryClient.invalidateQueries({ queryKey: ["/api/user/favorites"] });
      toast({
        title: "Adicionado aos favoritos",
        description: `${anime?.title} foi adicionado à sua lista de favoritos.`
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível adicionar aos favoritos.",
        variant: "destructive"
      });
    }
  };

  // Remove from favorites
  const removeFromFavorites = async () => {
    try {
      await apiRequest("DELETE", `/api/user/favorites/${animeId}`);
      queryClient.invalidateQueries({ queryKey: ["/api/user/favorites"] });
      toast({
        title: "Removido dos favoritos",
        description: `${anime?.title} foi removido da sua lista de favoritos.`
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível remover dos favoritos.",
        variant: "destructive"
      });
    }
  };

  const handleFavoriteToggle = () => {
    if (isInFavorites) {
      removeFromFavorites();
    } else {
      addToFavorites();
    }
  };

  if (isLoadingAnime) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!anime) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center p-8">
            <h1 className="text-3xl font-bold mb-4">Anime não encontrado</h1>
            <p className="mb-6">O anime que você está procurando não existe ou foi removido.</p>
            <Link href="/">
              <Button>Voltar para a página inicial</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Banner */}
        <div className="relative h-[400px] bg-dark-700">
          <div className="absolute inset-0 bg-gradient-to-t from-dark-700 via-dark-700/70 to-transparent z-10"></div>
          <img 
            src={anime.bannerImage || anime.coverImage} 
            alt={anime.title} 
            className="absolute inset-0 w-full h-full object-cover object-center"
          />
        </div>
        
        {/* Content */}
        <div className="container mx-auto px-4 relative z-20 -mt-32">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Poster and Info */}
            <div className="w-full md:w-1/4">
              <div className="bg-dark-600 rounded-lg overflow-hidden shadow-lg">
                <img 
                  src={anime.coverImage} 
                  alt={anime.title} 
                  className="w-full h-auto"
                />
                <div className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <Badge className="bg-primary capitalize">
                      {anime.audioLanguage === "dublado" ? "Dublado" : "Legendado"}
                    </Badge>
                    <Badge variant="outline" className="border-primary text-primary">
                      {anime.status}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center">
                    <Star className="text-yellow-500 mr-1" size={18} />
                    <span className="font-bold">{anime.rating.toFixed(1)}</span>
                    <span className="text-dark-100 text-sm ml-1">/10</span>
                  </div>
                  
                  <div className="flex items-center text-sm text-dark-100">
                    <Calendar className="mr-2" size={14} />
                    <span>{anime.releaseYear}</span>
                  </div>
                  
                  <div className="pt-3 border-t border-dark-500">
                    <h3 className="text-sm font-semibold mb-2">Gêneros</h3>
                    <div className="flex flex-wrap gap-1">
                      {anime.genres.map((genre, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {genre}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="pt-3">
                    {user ? (
                      <Button
                        onClick={handleFavoriteToggle}
                        variant={isInFavorites ? "outline" : "default"}
                        className="w-full"
                      >
                        {isInFavorites ? (
                          <>
                            <CheckCircle className="mr-2" size={16} /> Favoritado
                          </>
                        ) : (
                          <>
                            <Plus className="mr-2" size={16} /> Adicionar aos Favoritos
                          </>
                        )}
                      </Button>
                    ) : (
                      <Link href="/auth">
                        <Button className="w-full">
                          <Plus className="mr-2" size={16} /> Entrar para favoritar
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Details and Episodes */}
            <div className="flex-1">
              <h1 className="text-3xl md:text-4xl font-bold mb-4 font-poppins">{anime.title}</h1>
              
              <div className="bg-dark-600 rounded-lg p-6 mb-6">
                <div className="flex items-center mb-4">
                  <Info className="text-primary mr-2" size={20} />
                  <h2 className="text-xl font-semibold">Sinopse</h2>
                </div>
                <p className="text-dark-100 leading-relaxed">{anime.synopsis}</p>
              </div>
              
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="mb-6">
                  <TabsTrigger value="episodes">Episódios</TabsTrigger>
                  <TabsTrigger value="seasons">Temporadas</TabsTrigger>
                  <TabsTrigger value="related">Relacionados</TabsTrigger>
                </TabsList>
                
                <TabsContent value="episodes" className="space-y-6">
                  {isLoadingEpisodes ? (
                    <div className="text-center py-8">
                      <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                    </div>
                  ) : episodes.length > 0 ? (
                    <div className="bg-dark-500 rounded-lg overflow-hidden shadow-lg">
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-bold text-xl text-white">Todos os Episódios</h3>
                          <Badge variant="outline" className="text-sm">
                            {episodes.length} episódios
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                          {/* Agrupar episódios por temporada primeiro */}
                          {episodes
                            .sort((a, b) => {
                              // Primeiro ordenar por temporada (null por último)
                              if (a.seasonId !== b.seasonId) {
                                if (a.seasonId === null) return 1;
                                if (b.seasonId === null) return -1;
                                return a.seasonId - b.seasonId;
                              }
                              // Depois por número do episódio
                              return a.number - b.number;
                            })
                            .map((episode) => {
                              // Encontrar a temporada deste episódio (se existir)
                              const season = seasons.find(s => s.id === episode.seasonId);
                              
                              return (
                                <EpisodeCard
                                  key={episode.id}
                                  episode={episode}
                                  animeTitle={anime.title}
                                  seasonData={season}
                                  className="h-full"
                                />
                              );
                            })
                          }
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-dark-500 rounded-lg p-8 text-center">
                      <p className="text-dark-100 mb-4">Nenhum episódio disponível ainda.</p>
                      <p className="text-sm text-dark-200">Novos episódios serão adicionados em breve!</p>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="seasons" className="space-y-6">
                  {isLoadingSeasons ? (
                    <div className="text-center py-8">
                      <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                    </div>
                  ) : seasons.length > 0 ? (
                    <div className="space-y-8">
                      {seasons.map((season) => {
                        // Filtrar episódios desta temporada
                        const seasonEpisodes = episodes.filter(ep => ep.seasonId === season.id);
                        
                        return (
                          <div key={season.id} className="bg-dark-500 rounded-lg overflow-hidden shadow-lg">
                            <div className="p-6">
                              <div className="flex items-center justify-between mb-4">
                                <div>
                                  <h3 className="font-bold text-xl text-white">Temporada {season.number}</h3>
                                  <div className="flex items-center mt-1 text-sm text-dark-100">
                                    <Calendar size={14} className="mr-1" />
                                    <span>{season.releaseYear}</span>
                                    <span className="mx-2">•</span>
                                    <span>{seasonEpisodes.length} episódios</span>
                                  </div>
                                </div>
                                <img 
                                  src={anime.coverImage} 
                                  alt={`Temporada ${season.number}`} 
                                  className="w-20 h-20 object-cover rounded-md"
                                />
                              </div>
                              
                              {/* Episódios da temporada */}
                              {seasonEpisodes.length > 0 ? (
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                  {seasonEpisodes.map((episode) => (
                                    <EpisodeCard 
                                      key={episode.id} 
                                      episode={episode} 
                                      animeTitle={anime.title} 
                                      seasonData={season} 
                                      className="h-full"
                                    />
                                  ))}
                                </div>
                              ) : (
                                <div className="py-4 text-center text-dark-100">
                                  <p>Nenhum episódio disponível para esta temporada.</p>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="bg-dark-500 rounded-lg p-8 text-center">
                      <p className="text-dark-100">Nenhuma temporada disponível.</p>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="related" className="space-y-6">
                  {isLoadingRelated ? (
                    <div className="text-center py-8">
                      <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                    </div>
                  ) : relatedAnimes.length > 0 ? (
                    <div className="bg-dark-500 rounded-lg overflow-hidden shadow-lg">
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-bold text-xl text-white">Animes Relacionados</h3>
                          <Badge variant="outline" className="text-sm">
                            {relatedAnimes.length} animes
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                          {relatedAnimes.map((relatedAnime) => (
                            <Link key={relatedAnime.id} href={`/anime/${relatedAnime.id}`}>
                              <div className="bg-dark-600 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                                <div className="relative">
                                  <img 
                                    src={relatedAnime.coverImage} 
                                    alt={relatedAnime.title}
                                    className="w-full h-48 object-cover"
                                  />
                                  <div className="absolute inset-0 bg-gradient-to-t from-dark-800 via-dark-700/50 to-transparent"></div>
                                  
                                  <div className="absolute top-2 right-2">
                                    <Badge className="bg-primary text-white text-xs">
                                      {relatedAnime.rating.toFixed(1)}
                                    </Badge>
                                  </div>
                                  
                                  <div className="absolute bottom-0 left-0 right-0 p-2">
                                    <h4 className="font-bold text-white text-sm truncate">{relatedAnime.title}</h4>
                                    <div className="flex flex-wrap gap-1 mt-1">
                                      {relatedAnime.genres.slice(0, 2).map((genre, index) => (
                                        <span key={index} className="text-xs bg-dark-500 text-dark-100 px-1.5 py-0.5 rounded text-[10px]">
                                          {genre}
                                        </span>
                                      ))}
                                      {relatedAnime.genres.length > 2 && (
                                        <span className="text-xs text-dark-100 px-1.5 py-0.5 rounded text-[10px]">
                                          +{relatedAnime.genres.length - 2}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </Link>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-dark-500 rounded-lg p-8 text-center">
                      <p className="text-dark-100">Nenhum anime relacionado encontrado.</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
