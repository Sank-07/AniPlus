import { useQuery } from "@tanstack/react-query";
import { Anime } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { AnimeCard } from "@/components/anime/anime-card";
import { Button } from "@/components/ui/button";
import { BookmarkCheck, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

export default function FavoritesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [filterGenre, setFilterGenre] = useState("all");
  
  // Fetch user favorites
  const { data: favorites = [], isLoading } = useQuery<Anime[]>({
    queryKey: ["/api/user/favorites"],
  });
  
  // Extract all genres from favorites
  const allGenres = [...new Set(favorites.flatMap(anime => anime.genres))].sort();
  
  // Apply filters and sorting
  const filteredFavorites = favorites
    .filter(anime => {
      // Apply search term filter
      const matchesSearch = anime.title.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Apply genre filter
      const matchesGenre = filterGenre === "all" || anime.genres.includes(filterGenre);
      
      return matchesSearch && matchesGenre;
    })
    .sort((a, b) => {
      // Apply sorting
      switch (sortBy) {
        case "name":
          return a.title.localeCompare(b.title);
        case "rating":
          return b.rating - a.rating;
        case "year":
          return b.releaseYear - a.releaseYear;
        default:
          return 0;
      }
    });
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 bg-dark-700">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h1 className="text-2xl font-bold mb-4 md:mb-0">Meus Favoritos ({favorites.length})</h1>
            
            <div className="w-full md:w-auto flex flex-col md:flex-row gap-3">
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Pesquisar favoritos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full md:w-64 pl-10"
                />
                <Search className="absolute left-3 top-2.5 text-muted-foreground" size={16} />
              </div>
              
              <Select value={filterGenre} onValueChange={setFilterGenre}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Gênero" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os gêneros</SelectItem>
                  {allGenres.map(genre => (
                    <SelectItem key={genre} value={genre}>
                      {genre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Nome</SelectItem>
                  <SelectItem value="rating">Nota</SelectItem>
                  <SelectItem value="year">Ano</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : filteredFavorites.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
              {filteredFavorites.map((anime) => (
                <AnimeCard key={anime.id} anime={anime} />
              ))}
            </div>
          ) : searchTerm || filterGenre !== "all" ? (
            <div className="bg-dark-600 rounded-lg p-8 text-center">
              <Search className="mx-auto mb-4 text-dark-300" size={48} />
              <h3 className="text-xl font-semibold mb-2">Nenhum resultado encontrado</h3>
              <p className="text-dark-100 mb-4">
                Nenhum anime corresponde aos filtros selecionados.
              </p>
              <Button onClick={() => { setSearchTerm(""); setFilterGenre("all"); }}>
                Limpar filtros
              </Button>
            </div>
          ) : (
            <div className="bg-dark-600 rounded-lg p-8 text-center">
              <BookmarkCheck className="mx-auto mb-4 text-dark-300" size={48} />
              <h3 className="text-xl font-semibold mb-2">Nenhum favorito ainda</h3>
              <p className="text-dark-100 mb-4">
                Você ainda não adicionou nenhum anime aos seus favoritos.
              </p>
              <Button asChild>
                <a href="/animes">Explorar animes</a>
              </Button>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
