import { useQuery } from "@tanstack/react-query";
import { Calendar } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Clock, Calendar as CalendarIcon, Info } from "lucide-react";
import { Link } from "wouter";

// Nomes dos dias em português
const weekDays = [
  { key: 'seg', label: 'Segunda' },
  { key: 'ter', label: 'Terça' },
  { key: 'qua', label: 'Quarta' },
  { key: 'qui', label: 'Quinta' },
  { key: 'sex', label: 'Sexta' },
  { key: 'sab', label: 'Sábado' },
  { key: 'dom', label: 'Domingo' },
];

export default function CalendarioPage() {
  // Buscar dados do calendário
  const { data: calendarEntries = [], isLoading } = useQuery<Calendar[]>({
    queryKey: ["/api/calendar"],
  });
  
  // Adicionar dados extras para as entradas do calendário (em um cenário real, isso seria feito no backend)
  const entriesWithDetails = calendarEntries.map(entry => ({
    ...entry,
    animeTitle: "Título do Anime", // Isso seria buscado do backend
    animeCoverImage: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=60&h=60&fit=crop"
  }));
  
  // Organizar por dia da semana
  const entriesByDay = weekDays.reduce((acc, { key }) => {
    acc[key] = entriesWithDetails.filter(entry => entry.releaseDay === key);
    return acc;
  }, {} as Record<string, typeof entriesWithDetails>);
  
  // Determinar dia atual
  const today = new Date().getDay();
  // Converter para nosso formato (0=dom, 1=seg, etc)
  const mapToOurFormat = [6, 0, 1, 2, 3, 4, 5]; // converte 0=dom, 1=seg, etc. para nosso formato
  const todayKey = weekDays[mapToOurFormat[today]].key;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">Calendário de Lançamentos</h1>
          <p className="text-muted-foreground mb-8">
            Acompanhe os lançamentos semanais dos seus animes favoritos
          </p>
          
          <Tabs defaultValue={todayKey}>
            <TabsList className="grid grid-cols-7 mb-8">
              {weekDays.map(day => (
                <TabsTrigger 
                  key={day.key} 
                  value={day.key}
                  className={day.key === todayKey ? "text-primary" : ""}
                >
                  {day.label}
                  {day.key === todayKey && (
                    <Badge className="ml-1 bg-primary text-xs">Hoje</Badge>
                  )}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {weekDays.map(day => (
              <TabsContent key={day.key} value={day.key}>
                <div className="bg-dark-600 rounded-lg p-6">
                  <h2 className="text-xl font-semibold mb-4 flex items-center">
                    <CalendarIcon className="mr-2 text-primary" />
                    {day.label}
                  </h2>
                  
                  {isLoading ? (
                    <div className="flex justify-center py-10">
                      <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                    </div>
                  ) : entriesByDay[day.key]?.length > 0 ? (
                    <div className="space-y-4">
                      {entriesByDay[day.key].map((entry) => (
                        <Card key={entry.id} className="overflow-hidden">
                          <CardContent className="p-0">
                            <div className="flex items-center p-4">
                              <div className="flex-shrink-0 h-16 w-16 rounded overflow-hidden bg-dark-400 mr-4">
                                <img 
                                  src={entry.animeCoverImage} 
                                  alt="Anime Cover" 
                                  className="h-full w-full object-cover"
                                />
                              </div>
                              
                              <div className="flex-1">
                                <div className="flex justify-between items-start">
                                  <div>
                                    <Link href={`/anime/${entry.animeId}`}>
                                      <h3 className="font-semibold text-white hover:text-primary transition cursor-pointer">
                                        {entry.title}
                                      </h3>
                                    </Link>
                                    
                                    <div className="flex items-center mt-1 text-sm text-muted-foreground">
                                      <Clock className="mr-1" size={14} />
                                      <span>{entry.releaseTime}</span>
                                    </div>
                                  </div>
                                  
                                  {entry.episodeId && (
                                    <Link href={`/player/${entry.episodeId}`}>
                                      <Badge className="bg-primary hover:bg-primary/80 transition">
                                        Assistir
                                      </Badge>
                                    </Link>
                                  )}
                                </div>
                                
                                {entry.description && (
                                  <div className="mt-2 text-sm text-muted-foreground">
                                    <div className="flex items-start">
                                      <Info className="mr-1 flex-shrink-0 mt-0.5" size={14} />
                                      <p>{entry.description}</p>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-dark-500 rounded-lg p-8 text-center">
                      <p className="text-lg mb-2">Nenhum lançamento agendado</p>
                      <p className="text-sm text-muted-foreground">
                        Não há animes programados para lançamento neste dia.
                      </p>
                    </div>
                  )}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}