import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Anime } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { AnimeCard } from "@/components/anime/anime-card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Search, Filter } from "lucide-react";

// Lista de gêneros para filtro
const genres = [
  "Ação", "Aventura", "Comédia", "Drama", "Fantasia", 
  "Terror", "Magia", "Mistério", "Psicológico", "Romance", 
  "Sci-Fi", "Slice of Life", "Sobrenatural", "Esporte", "Escolar"
];

export default function AnimesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState<string>("todos");
  const [selectedAudioLanguage, setSelectedAudioLanguage] = useState<string>("todos");
  const [sortBy, setSortBy] = useState("title");
  
  // Buscar todos os animes
  const { data: animes = [], isLoading } = useQuery<Anime[]>({
    queryKey: ["/api/animes"],
  });
  
  // Filtrar animes com base nos filtros
  const filteredAnimes = animes.filter(anime => {
    // Filtro de busca
    const matchesSearch = searchQuery === "" || 
      anime.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      anime.synopsis.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Filtro de gênero
    const matchesGenre = selectedGenre === "todos" || selectedGenre === "" || 
      anime.genres.some(genre => genre.toLowerCase() === selectedGenre.toLowerCase());
    
    // Filtro de idioma de áudio
    const matchesAudioLanguage = selectedAudioLanguage === "todos" || 
      anime.audioLanguage === selectedAudioLanguage;
    
    return matchesSearch && matchesGenre && matchesAudioLanguage;
  });
  
  // Ordenar animes
  const sortedAnimes = [...filteredAnimes].sort((a, b) => {
    if (sortBy === "title") {
      return a.title.localeCompare(b.title);
    } else if (sortBy === "rating") {
      return b.rating - a.rating;
    } else if (sortBy === "newest") {
      return b.releaseYear - a.releaseYear;
    }
    return 0;
  });
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Animes</h1>
        
        {/* Filtros e busca */}
        <div className="bg-dark-600 rounded-lg p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="space-y-2">
              <Label htmlFor="search">Buscar</Label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Buscar por título ou descrição..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="genre">Filtrar por Gênero</Label>
              <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os gêneros" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os gêneros</SelectItem>
                  {genres.map(genre => (
                    <SelectItem key={genre} value={genre}>{genre}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="audioLanguage">Idioma do Áudio</Label>
              <Select value={selectedAudioLanguage} onValueChange={setSelectedAudioLanguage}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os idiomas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os idiomas</SelectItem>
                  <SelectItem value="dublado">Dublado</SelectItem>
                  <SelectItem value="legendado">Legendado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="sort">Ordenar por</Label>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue placeholder="Ordenar por..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="title">Título (A-Z)</SelectItem>
                  <SelectItem value="rating">Avaliação</SelectItem>
                  <SelectItem value="newest">Mais recentes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        {/* Removido o filtro de Tabs para tipo */}
        
        {/* Resultados encontrados */}
        <div className="flex items-center mb-4">
          <Filter className="mr-2 text-primary" size={18} />
          <span className="text-sm text-muted-foreground">
            {sortedAnimes.length} {sortedAnimes.length === 1 ? 'anime encontrado' : 'animes encontrados'}
          </span>
          
          {selectedGenre && selectedGenre !== "todos" && (
            <Badge variant="outline" className="ml-2">
              {selectedGenre}
            </Badge>
          )}
          
          {selectedAudioLanguage && selectedAudioLanguage !== "todos" && (
            <Badge variant="outline" className="ml-2 capitalize">
              {selectedAudioLanguage === "dublado" ? "Dublado" : "Legendado"}
            </Badge>
          )}
        </div>
        
        {/* Grid de animes */}
        {isLoading ? (
          <div className="flex justify-center items-center h-96">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : sortedAnimes.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {sortedAnimes.map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>
        ) : (
          <div className="bg-dark-500 rounded-lg p-8 text-center">
            <p className="text-lg font-medium mb-2">Nenhum anime encontrado</p>
            <p className="text-muted-foreground">
              Tente ajustar seus filtros de busca para encontrar o que procura.
            </p>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
}