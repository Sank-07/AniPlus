import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  History, 
  Film, 
  Clock, 
  Search, 
  Play, 
  X 
} from "lucide-react";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";

interface HistoryItem {
  id: number;
  animeId: number;
  episodeId: number;
  progress: number;
  duration: number;
  completed: boolean;
  watchedAt: string;
  animeTitle: string;
  episodeNumber: number;
  episodeTitle: string;
  thumbnail: string;
}

export default function HistoryPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  
  // Fetch watch history
  const { data: history = [], isLoading } = useQuery<HistoryItem[]>({
    queryKey: ["/api/user/history"],
  });

  // Clear history dialog
  const [clearConfirmOpen, setClearConfirmOpen] = useState(false);
  
  // Filter by search term and tab
  const filteredHistory = history
    .filter(item => {
      // Search filter
      const matchesSearch = item.animeTitle.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Tab filter
      const matchesTab = activeTab === "all" || 
        (activeTab === "completed" && item.completed) || 
        (activeTab === "in-progress" && !item.completed);
      
      return matchesSearch && matchesTab;
    })
    .sort((a, b) => new Date(b.watchedAt).getTime() - new Date(a.watchedAt).getTime());
  
  // Clear entire history
  const clearHistory = async () => {
    try {
      await apiRequest("DELETE", "/api/user/history");
      queryClient.invalidateQueries({ queryKey: ["/api/user/history"] });
      toast({
        title: "Histórico limpo",
        description: "Seu histórico de visualização foi apagado com sucesso."
      });
      setClearConfirmOpen(false);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível limpar seu histórico.",
        variant: "destructive"
      });
    }
  };
  
  // Remove single history item
  const removeHistoryItem = async (id: number) => {
    try {
      await apiRequest("DELETE", `/api/user/history/${id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/user/history"] });
      toast({
        title: "Item removido",
        description: "O item foi removido do seu histórico."
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível remover este item.",
        variant: "destructive"
      });
    }
  };
  
  // Format time for display
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 bg-dark-700">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div className="mb-4 md:mb-0">
              <h1 className="text-2xl font-bold">Histórico de Visualização</h1>
              <p className="text-dark-100">{history.length} {history.length === 1 ? 'item' : 'itens'} em seu histórico</p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
              <div className="relative flex-1 sm:flex-none">
                <Input
                  type="search"
                  placeholder="Pesquisar no histórico..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full md:w-64 pl-10"
                />
                <Search className="absolute left-3 top-2.5 text-muted-foreground" size={16} />
              </div>
              
              <Dialog open={clearConfirmOpen} onOpenChange={setClearConfirmOpen}>
                <DialogTrigger asChild>
                  <Button variant="destructive" className="whitespace-nowrap">
                    Limpar Histórico
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Limpar histórico de visualização</DialogTitle>
                  </DialogHeader>
                  <p className="py-4">
                    Tem certeza que deseja apagar todo o seu histórico de visualização? 
                    Esta ação não pode ser desfeita.
                  </p>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setClearConfirmOpen(false)}>
                      Cancelar
                    </Button>
                    <Button variant="destructive" onClick={clearHistory}>
                      Sim, limpar tudo
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList>
              <TabsTrigger value="all" className="flex items-center">
                <History className="mr-2" size={16} /> Tudo
              </TabsTrigger>
              <TabsTrigger value="completed" className="flex items-center">
                <Film className="mr-2" size={16} /> Completos
              </TabsTrigger>
              <TabsTrigger value="in-progress" className="flex items-center">
                <Clock className="mr-2" size={16} /> Em progresso
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          {isLoading ? (
            <div className="space-y-3 bg-dark-600 rounded-lg">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="p-4 flex items-center gap-4">
                  <Skeleton className="h-16 w-28 rounded" />
                  <div className="flex-1">
                    <Skeleton className="h-5 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                  <Skeleton className="h-9 w-24 rounded" />
                </div>
              ))}
            </div>
          ) : filteredHistory.length > 0 ? (
            <div className="bg-dark-600 rounded-lg">
              {filteredHistory.map((item) => (
                <div 
                  key={item.id} 
                  className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 border-b border-dark-500 last:border-0 hover:bg-dark-500 transition"
                >
                  <div className="relative group">
                    <img 
                      src={item.thumbnail} 
                      alt={item.animeTitle} 
                      className="w-28 h-16 object-cover rounded"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                      <Link href={`/player/${item.episodeId}`}>
                        <Button variant="ghost" size="icon" className="text-white hover:text-primary hover:bg-transparent">
                          <Play size={20} />
                        </Button>
                      </Link>
                    </div>
                    {!item.completed && (
                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-dark-400">
                        <div 
                          className="h-full bg-primary" 
                          style={{ width: `${(item.progress / item.duration) * 100}%` }}
                        ></div>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <Link href={`/anime/${item.animeId}`}>
                      <h3 className="font-bold text-white hover:text-primary transition">{item.animeTitle}</h3>
                    </Link>
                    <Link href={`/player/${item.episodeId}`}>
                      <p className="text-dark-100 text-sm hover:text-primary transition">
                        Episódio {item.episodeNumber}{item.episodeTitle ? `: ${item.episodeTitle}` : ''}
                      </p>
                    </Link>
                    <div className="flex items-center mt-1 text-xs text-dark-200">
                      <span className={`mr-2 ${item.completed ? 'text-green-500' : 'text-yellow-500'}`}>
                        {item.completed ? 'Completado' : 'Em progresso'} 
                      </span>
                      <span>•</span>
                      <span className="mx-2">
                        {formatTime(item.progress)} / {formatTime(item.duration)}
                      </span>
                      <span>•</span>
                      <span className="ml-2">
                        {formatDistanceToNow(new Date(item.watchedAt), { locale: ptBR, addSuffix: true })}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 sm:self-center">
                    <Link href={`/player/${item.episodeId}`}>
                      <Button>
                        {item.completed ? 'Reassistir' : 'Continuar'}
                      </Button>
                    </Link>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => removeHistoryItem(item.id)}
                      className="text-dark-100 hover:text-red-500 hover:bg-transparent"
                    >
                      <X size={18} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-dark-600 rounded-lg p-8 text-center">
              <History className="mx-auto mb-4 text-dark-300" size={48} />
              <h3 className="text-xl font-semibold mb-2">
                {searchTerm ? 'Nenhum resultado encontrado' : 'Seu histórico está vazio'}
              </h3>
              <p className="text-dark-100 mb-4">
                {searchTerm 
                  ? 'Tente pesquisar com outros termos ou limpe a pesquisa.' 
                  : 'Comece a assistir animes para construir seu histórico de visualização.'}
              </p>
              {searchTerm ? (
                <Button onClick={() => setSearchTerm("")}>
                  Limpar pesquisa
                </Button>
              ) : (
                <Button asChild>
                  <Link href="/">Explorar animes</Link>
                </Button>
              )}
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
