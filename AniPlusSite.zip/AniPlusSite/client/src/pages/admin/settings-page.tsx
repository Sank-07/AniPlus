import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { AlertTriangle, Database, Save, Server } from "lucide-react";

export default function SettingsPage() {
  const [generalSettings, setGeneralSettings] = useState({
    siteName: "AniPlus",
    siteDescription: "Plataforma de streaming de anime em Português",
    maintenanceMode: false,
    allowRegistrations: true,
    emailOnRegistration: true,
    maxUploadSize: 100
  });
  
  const [playerSettings, setPlayerSettings] = useState({
    autoplay: true,
    defaultQuality: "720p",
    showSkipIntro: true,
    showNextEpisode: true,
    skipIntroTime: 90,
    skipOutroTime: 120
  });
  
  const [storageSettings, setStorageSettings] = useState({
    storageType: "local",
    cdnUrl: "",
    s3BucketName: "",
    s3Region: "us-east-1"
  });

  const { toast } = useToast();
  
  // Simular um pedido para buscar as configurações (substituir por API real depois)
  const { isLoading } = useQuery({
    queryKey: ["/api/admin/settings"],
    onSuccess: (data) => {
      // Em uma implementação real, isso seria populado a partir dos dados da API
      console.log("Configurações carregadas:", data);
    },
    enabled: false // Desativado temporariamente
  });
  
  // Simular uma mutação para salvar as configurações
  const saveGeneralMutation = useMutation({
    mutationFn: async (data: any) => {
      // Em uma implementação real, isso seria um pedido para a API
      // const res = await apiRequest("PUT", "/api/admin/settings/general", data);
      // return await res.json();
      return new Promise(resolve => setTimeout(() => resolve(data), 1000));
    },
    onSuccess: () => {
      toast({
        title: "Configurações salvas",
        description: "As configurações gerais foram atualizadas com sucesso."
      });
    }
  });
  
  const savePlayerMutation = useMutation({
    mutationFn: async (data: any) => {
      return new Promise(resolve => setTimeout(() => resolve(data), 1000));
    },
    onSuccess: () => {
      toast({
        title: "Configurações salvas",
        description: "As configurações do player foram atualizadas com sucesso."
      });
    }
  });
  
  const saveStorageMutation = useMutation({
    mutationFn: async (data: any) => {
      return new Promise(resolve => setTimeout(() => resolve(data), 1000));
    },
    onSuccess: () => {
      toast({
        title: "Configurações salvas",
        description: "As configurações de armazenamento foram atualizadas com sucesso."
      });
    }
  });
  
  const handleSaveGeneral = () => {
    saveGeneralMutation.mutate(generalSettings);
  };
  
  const handleSavePlayer = () => {
    savePlayerMutation.mutate(playerSettings);
  };
  
  const handleSaveStorage = () => {
    saveStorageMutation.mutate(storageSettings);
  };

  return (
    <div className="min-h-screen flex">
      <AdminSidebar />
      
      <div className="flex-1 bg-dark-700 overflow-auto">
        <Header />
        
        <main className="p-6">
          <h1 className="text-2xl font-bold mb-6">Configurações</h1>
          
          <Tabs defaultValue="general">
            <TabsList className="mb-6">
              <TabsTrigger value="general">Geral</TabsTrigger>
              <TabsTrigger value="player">Player</TabsTrigger>
              <TabsTrigger value="storage">Armazenamento</TabsTrigger>
              <TabsTrigger value="about">Sobre</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general">
              <Card>
                <CardHeader>
                  <CardTitle>Configurações Gerais</CardTitle>
                  <CardDescription>
                    Configure os parâmetros básicos da plataforma
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="siteName">Nome do Site</Label>
                      <Input 
                        id="siteName" 
                        value={generalSettings.siteName}
                        onChange={(e) => setGeneralSettings({...generalSettings, siteName: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="maxUploadSize">Tamanho Máximo de Upload (MB)</Label>
                      <Input 
                        id="maxUploadSize" 
                        type="number"
                        value={generalSettings.maxUploadSize}
                        onChange={(e) => setGeneralSettings({...generalSettings, maxUploadSize: parseInt(e.target.value)})}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="siteDescription">Descrição do Site</Label>
                    <Textarea 
                      id="siteDescription" 
                      value={generalSettings.siteDescription}
                      onChange={(e) => setGeneralSettings({...generalSettings, siteDescription: e.target.value})}
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="maintenanceMode"
                      checked={generalSettings.maintenanceMode}
                      onCheckedChange={(checked) => setGeneralSettings({...generalSettings, maintenanceMode: checked})}
                    />
                    <Label htmlFor="maintenanceMode">Modo de Manutenção</Label>
                    {generalSettings.maintenanceMode && (
                      <Badge variant="outline" className="ml-2 bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        Ativo
                      </Badge>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="allowRegistrations"
                      checked={generalSettings.allowRegistrations}
                      onCheckedChange={(checked) => setGeneralSettings({...generalSettings, allowRegistrations: checked})}
                    />
                    <Label htmlFor="allowRegistrations">Permitir Novos Registros</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="emailOnRegistration"
                      checked={generalSettings.emailOnRegistration}
                      onCheckedChange={(checked) => setGeneralSettings({...generalSettings, emailOnRegistration: checked})}
                    />
                    <Label htmlFor="emailOnRegistration">Enviar Email ao Registrar</Label>
                  </div>
                </CardContent>
                <CardFooter className="justify-end">
                  <Button 
                    onClick={handleSaveGeneral}
                    disabled={saveGeneralMutation.isPending}
                  >
                    {saveGeneralMutation.isPending ? (
                      <>
                        <div className="w-4 h-4 mr-2 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                        Salvando...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Salvar Alterações
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="player">
              <Card>
                <CardHeader>
                  <CardTitle>Configurações do Player</CardTitle>
                  <CardDescription>
                    Ajuste as configurações do player de vídeo
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="autoplay"
                      checked={playerSettings.autoplay}
                      onCheckedChange={(checked) => setPlayerSettings({...playerSettings, autoplay: checked})}
                    />
                    <Label htmlFor="autoplay">Auto-reprodução</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="showSkipIntro"
                      checked={playerSettings.showSkipIntro}
                      onCheckedChange={(checked) => setPlayerSettings({...playerSettings, showSkipIntro: checked})}
                    />
                    <Label htmlFor="showSkipIntro">Exibir Botão "Pular Intro"</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="showNextEpisode"
                      checked={playerSettings.showNextEpisode}
                      onCheckedChange={(checked) => setPlayerSettings({...playerSettings, showNextEpisode: checked})}
                    />
                    <Label htmlFor="showNextEpisode">Exibir Botão "Próximo Episódio"</Label>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Qualidade Padrão</Label>
                    <RadioGroup 
                      value={playerSettings.defaultQuality}
                      onValueChange={(value) => setPlayerSettings({...playerSettings, defaultQuality: value})}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="480p" id="r1" />
                        <Label htmlFor="r1">480p</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="720p" id="r2" />
                        <Label htmlFor="r2">720p</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="1080p" id="r3" />
                        <Label htmlFor="r3">1080p</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="skipIntroTime">Tempo para Pular Intro (segundos)</Label>
                      <Input 
                        id="skipIntroTime" 
                        type="number"
                        value={playerSettings.skipIntroTime}
                        onChange={(e) => setPlayerSettings({...playerSettings, skipIntroTime: parseInt(e.target.value)})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="skipOutroTime">Tempo para Pular Créditos (segundos)</Label>
                      <Input 
                        id="skipOutroTime" 
                        type="number"
                        value={playerSettings.skipOutroTime}
                        onChange={(e) => setPlayerSettings({...playerSettings, skipOutroTime: parseInt(e.target.value)})}
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="justify-end">
                  <Button 
                    onClick={handleSavePlayer}
                    disabled={savePlayerMutation.isPending}
                  >
                    {savePlayerMutation.isPending ? (
                      <>
                        <div className="w-4 h-4 mr-2 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                        Salvando...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Salvar Alterações
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="storage">
              <Card>
                <CardHeader>
                  <CardTitle>Configurações de Armazenamento</CardTitle>
                  <CardDescription>
                    Configure onde e como os arquivos de mídia são armazenados
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Tipo de Armazenamento</Label>
                    <RadioGroup 
                      value={storageSettings.storageType}
                      onValueChange={(value) => setStorageSettings({...storageSettings, storageType: value})}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="local" id="st1" />
                        <Label htmlFor="st1" className="flex items-center">
                          <Server className="h-4 w-4 mr-2" />
                          Armazenamento Local
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="s3" id="st2" />
                        <Label htmlFor="st2" className="flex items-center">
                          <Database className="h-4 w-4 mr-2" />
                          Amazon S3
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="cdnUrl">URL do CDN (opcional)</Label>
                    <Input 
                      id="cdnUrl" 
                      placeholder="https://cdn.example.com"
                      value={storageSettings.cdnUrl}
                      onChange={(e) => setStorageSettings({...storageSettings, cdnUrl: e.target.value})}
                    />
                  </div>
                  
                  {storageSettings.storageType === "s3" && (
                    <div className="space-y-4 border rounded-md p-4 bg-dark-800">
                      <h3 className="text-md font-medium">Configurações do Amazon S3</h3>
                      <div className="space-y-2">
                        <Label htmlFor="s3BucketName">Nome do Bucket</Label>
                        <Input 
                          id="s3BucketName" 
                          placeholder="my-anime-bucket"
                          value={storageSettings.s3BucketName}
                          onChange={(e) => setStorageSettings({...storageSettings, s3BucketName: e.target.value})}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="s3Region">Região</Label>
                        <Input 
                          id="s3Region" 
                          placeholder="us-east-1"
                          value={storageSettings.s3Region}
                          onChange={(e) => setStorageSettings({...storageSettings, s3Region: e.target.value})}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="awsAccessKey">AWS Access Key</Label>
                        <Input id="awsAccessKey" type="password" placeholder="••••••••••••••••" />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="awsSecretKey">AWS Secret Key</Label>
                        <Input id="awsSecretKey" type="password" placeholder="••••••••••••••••" />
                      </div>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="justify-end">
                  <Button 
                    onClick={handleSaveStorage}
                    disabled={saveStorageMutation.isPending}
                  >
                    {saveStorageMutation.isPending ? (
                      <>
                        <div className="w-4 h-4 mr-2 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                        Salvando...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Salvar Alterações
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="about">
              <Card>
                <CardHeader>
                  <CardTitle>Sobre o AniPlus</CardTitle>
                  <CardDescription>
                    Informações sobre a plataforma
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Versão</h3>
                    <p className="text-muted-foreground">1.0.0</p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Desenvolvido por</h3>
                    <p className="text-muted-foreground">Equipe AniPlus</p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Licença</h3>
                    <p className="text-muted-foreground">MIT</p>
                  </div>
                  
                  <div className="pt-4">
                    <h3 className="text-lg font-semibold mb-2">Tecnologias Utilizadas</h3>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">React</Badge>
                      <Badge variant="secondary">Node.js</Badge>
                      <Badge variant="secondary">Express</Badge>
                      <Badge variant="secondary">TypeScript</Badge>
                      <Badge variant="secondary">Tailwind CSS</Badge>
                      <Badge variant="secondary">Drizzle ORM</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}