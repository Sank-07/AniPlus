import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Anime, Season } from "@shared/schema";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Header } from "@/components/layout/header";
import { SeasonForm } from "@/components/admin/season-form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  MoreHorizontal, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Filter,
  Calendar,
  Film
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SeasonsManagementPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [animeFilter, setAnimeFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [selectedSeason, setSelectedSeason] = useState<Season | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  // Fetch animes for filter
  const { data: animes = [] } = useQuery<Anime[]>({
    queryKey: ["/api/animes"],
  });
  
  // Fetch all seasons (for all animes)
  const { data: allSeasons = [], isLoading } = useQuery<Season[]>({
    queryKey: ["/api/seasons"],
    queryFn: async () => {
      const animesWithSeasons = await Promise.all(
        animes.map(async (anime) => {
          const response = await fetch(`/api/animes/${anime.id}/seasons`);
          const seasons = await response.json();
          return seasons;
        })
      );
      return animesWithSeasons.flat();
    },
    enabled: animes.length > 0,
  });
  
  // Filter and paginate seasons
  const filteredSeasons = allSeasons.filter(season => {
    // Como removemos o título, vamos filtrar pelo número ou anime
    const seasonTitle = `Temporada ${season.number}`;
    const matchesSearch = seasonTitle.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAnime = animeFilter === "all" || season.animeId.toString() === animeFilter;
    
    return matchesSearch && matchesAnime;
  });
  
  const ITEMS_PER_PAGE = 10;
  const pageCount = Math.ceil(filteredSeasons.length / ITEMS_PER_PAGE);
  const paginatedSeasons = filteredSeasons.slice(
    (page - 1) * ITEMS_PER_PAGE,
    page * ITEMS_PER_PAGE
  );
  
  // Handle edit season
  const handleEditSeason = (season: Season) => {
    setSelectedSeason(season);
    setIsEditDialogOpen(true);
  };
  
  // Handle delete season
  const handleDeleteSeason = async () => {
    if (!selectedSeason) return;
    
    try {
      await apiRequest("DELETE", `/api/admin/seasons/${selectedSeason.id}`);
      
      // Invalidar queries relevantes
      queryClient.invalidateQueries({ queryKey: ["/api/seasons"] });
      queryClient.invalidateQueries({ 
        queryKey: ["/api/animes", selectedSeason.animeId, "seasons"] 
      });
      
      toast({
        title: "Temporada excluída",
        description: `Temporada ${selectedSeason.number} foi excluída com sucesso.`,
      });
      setIsDeleteDialogOpen(false);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível excluir a temporada.",
        variant: "destructive",
      });
    }
  };
  
  // Helper to find anime name by ID
  const getAnimeName = (animeId: number) => {
    const anime = animes.find(a => a.id === animeId);
    return anime ? anime.title : "Desconhecido";
  };
  
  return (
    <div className="min-h-screen flex">
      <AdminSidebar />
      
      <div className="flex-1 overflow-auto bg-dark-700">
        <Header />
        
        <main className="p-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <h1 className="text-2xl font-bold mb-2 sm:mb-0">Gerenciamento de Temporadas</h1>
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center">
                  <Plus className="mr-2" size={16} /> Adicionar Temporada
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>Adicionar Nova Temporada</DialogTitle>
                </DialogHeader>
                <SeasonForm 
                  onSuccess={() => setIsAddDialogOpen(false)} 
                />
              </DialogContent>
            </Dialog>
          </div>
          
          <div className="bg-dark-600 rounded-lg p-4 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por título..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div>
                <Select value={animeFilter} onValueChange={setAnimeFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filtrar por Anime" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Animes</SelectItem>
                    {animes.map((anime) => (
                      <SelectItem key={anime.id} value={anime.id.toString()}>
                        {anime.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <div className="flex items-center mb-4">
            <Filter className="mr-2 text-primary" size={18} />
            <span className="text-sm text-muted-foreground">
              {filteredSeasons.length} {filteredSeasons.length === 1 ? 'temporada encontrada' : 'temporadas encontradas'}
            </span>
            
            {animeFilter !== "all" && (
              <Badge variant="outline" className="ml-2">
                {getAnimeName(parseInt(animeFilter))}
              </Badge>
            )}
          </div>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-96">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : filteredSeasons.length > 0 ? (
            <div className="bg-dark-800 rounded-lg overflow-hidden shadow">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">N°</TableHead>
                      <TableHead>Temporada</TableHead>
                      <TableHead>Anime</TableHead>
                      <TableHead>Ano</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedSeasons.map((season) => (
                      <TableRow key={season.id}>
                        <TableCell>{season.number}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div>
                              <div className="font-medium">Temporada {season.number}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {getAnimeName(season.animeId)}
                        </TableCell>
                        <TableCell>
                          {season.releaseYear}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Abrir menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Ações</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => handleEditSeason(season)}
                                className="cursor-pointer"
                              >
                                <Edit className="mr-2 h-4 w-4" /> Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => {
                                  setSelectedSeason(season);
                                  setIsDeleteDialogOpen(true);
                                }}
                                className="cursor-pointer text-destructive focus:text-destructive"
                              >
                                <Trash2 className="mr-2 h-4 w-4" /> Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination */}
              {pageCount > 1 && (
                <div className="p-4 flex justify-center">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          onClick={() => setPage(p => (p > 1 ? p - 1 : p))}
                          className={page <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                      
                      {Array.from({ length: pageCount }, (_, i) => i + 1).map((p) => (
                        <PaginationItem key={p}>
                          <PaginationLink
                            isActive={page === p}
                            onClick={() => setPage(p)}
                            className="cursor-pointer"
                          >
                            {p}
                          </PaginationLink>
                        </PaginationItem>
                      ))}
                      
                      <PaginationItem>
                        <PaginationNext 
                          onClick={() => setPage(p => (p < pageCount ? p + 1 : p))}
                          className={page >= pageCount ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-dark-500 rounded-lg p-8 text-center">
              <Film className="h-10 w-10 mx-auto mb-4 text-dark-100" />
              <p className="text-lg font-medium mb-2">Nenhuma temporada encontrada</p>
              <p className="text-muted-foreground max-w-md mx-auto">
                Não há temporadas correspondentes aos filtros aplicados. Tente ajustar seus critérios de busca ou adicione uma nova temporada.
              </p>
              <Button 
                className="mt-4" 
                variant="outline"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="mr-2 h-4 w-4" /> Adicionar Temporada
              </Button>
            </div>
          )}
        </main>
      </div>
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Editar Temporada</DialogTitle>
          </DialogHeader>
          {selectedSeason && (
            <SeasonForm 
              season={selectedSeason} 
              onSuccess={() => setIsEditDialogOpen(false)} 
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir a Temporada {selectedSeason?.number}? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="sm:justify-between">
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancelar
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteSeason}
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}