import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Header } from "@/components/layout/header";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  MoreHorizontal,
  Search, 
  Trash2, 
  Shield, 
  ShieldOff,
  UserCog,
  Star,
  Mail,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/use-auth";

export default function UsersManagementPage() {
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [page, setPage] = useState(1);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isChangeRoleDialogOpen, setIsChangeRoleDialogOpen] = useState(false);
  
  // Fetch users
  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });
  
  // Filter, sort and paginate users
  const filteredUsers = users
    .filter(user => {
      const matchesSearch = 
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesRole = roleFilter === "all" || user.role === roleFilter;
      
      return matchesSearch && matchesRole;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name);
        case "username":
          return a.username.localeCompare(b.username);
        case "role":
          return a.role.localeCompare(b.role);
        case "animeWatched":
          return b.animeWatched - a.animeWatched;
        case "createdAt":
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        default:
          return 0;
      }
    });
  
  const ITEMS_PER_PAGE = 10;
  const pageCount = Math.ceil(filteredUsers.length / ITEMS_PER_PAGE);
  const paginatedUsers = filteredUsers.slice(
    (page - 1) * ITEMS_PER_PAGE,
    page * ITEMS_PER_PAGE
  );
  
  // Delete user handler
  const handleDeleteUser = async () => {
    if (!selectedUser) return;
    
    try {
      await apiRequest("DELETE", `/api/admin/users/${selectedUser.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Usuário excluído",
        description: `${selectedUser.name} foi excluído com sucesso.`,
      });
      setIsDeleteDialogOpen(false);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível excluir o usuário.",
        variant: "destructive",
      });
    }
  };
  
  // Change user role handler
  const handleChangeRole = async (newRole: string) => {
    if (!selectedUser) return;
    
    try {
      await apiRequest("PATCH", `/api/admin/users/${selectedUser.id}/role`, { role: newRole });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Função alterada",
        description: `${selectedUser.name} agora é ${newRole === "admin" ? "um administrador" : "um usuário comum"}.`,
      });
      setIsChangeRoleDialogOpen(false);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível alterar a função do usuário.",
        variant: "destructive",
      });
    }
  };
  
  // Helper to get user rank badge
  const getUserRankBadge = (animeWatched: number) => {
    if (animeWatched >= 500) {
      return <Badge className="bg-gradient-to-r from-primary to-secondary">Lendário</Badge>;
    } else if (animeWatched >= 300) {
      return <Badge className="bg-secondary">Mestre</Badge>;
    } else if (animeWatched >= 100) {
      return <Badge className="bg-accent">Expert</Badge>;
    } else if (animeWatched >= 50) {
      return <Badge className="bg-amber-500">Pro</Badge>;
    } else {
      return <Badge variant="outline">Iniciante</Badge>;
    }
  };
  
  return (
    <div className="min-h-screen flex">
      <AdminSidebar />
      
      <div className="flex-1 overflow-auto bg-dark-700">
        <Header />
        
        <main className="p-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <h1 className="text-2xl font-bold mb-2 sm:mb-0">Gerenciamento de Usuários</h1>
          </div>
          
          {/* Search and filters */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
            <div className="sm:col-span-2 relative">
              <Input
                type="search"
                placeholder="Buscar usuários..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setPage(1); // Reset to first page on search
                }}
                className="pl-10"
              />
              <Search className="absolute left-3 top-2.5 text-muted-foreground" size={16} />
            </div>
            
            <div>
              <Select 
                value={roleFilter} 
                onValueChange={(value) => {
                  setRoleFilter(value);
                  setPage(1); // Reset to first page on filter change
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por função" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as funções</SelectItem>
                  <SelectItem value="admin">Administradores</SelectItem>
                  <SelectItem value="user">Usuários</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Select 
                value={sortBy} 
                onValueChange={(value) => {
                  setSortBy(value);
                  setPage(1); // Reset to first page on sort change
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Nome</SelectItem>
                  <SelectItem value="username">Nome de usuário</SelectItem>
                  <SelectItem value="role">Função</SelectItem>
                  <SelectItem value="animeWatched">Animes assistidos</SelectItem>
                  <SelectItem value="createdAt">Data de cadastro</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Users Table */}
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : paginatedUsers.length > 0 ? (
            <>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Usuário</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Função</TableHead>
                      <TableHead>Animes Assistidos</TableHead>
                      <TableHead>Cadastro</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center space-x-3">
                            <Avatar>
                              <AvatarImage src={user.avatar || ""} alt={user.name} />
                              <AvatarFallback className={user.role === "admin" ? "bg-primary" : "bg-secondary"}>
                                {user.name.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{user.name}</div>
                              <div className="text-sm text-muted-foreground">@{user.username}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center text-muted-foreground">
                            <Mail className="mr-1" size={14} />
                            <span>{user.email}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {user.role === "admin" ? (
                            <Badge className="bg-primary">Administrador</Badge>
                          ) : (
                            <Badge variant="outline">Usuário</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <div className="font-medium">{user.animeWatched}</div>
                            {getUserRankBadge(user.animeWatched)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center text-muted-foreground">
                            <Calendar className="mr-1" size={14} />
                            <span>
                              {format(new Date(user.createdAt), "dd/MM/yyyy", { locale: ptBR })}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Ações</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              
                              {user.id !== currentUser?.id && (
                                <>
                                  <DropdownMenuItem
                                    onClick={() => {
                                      setSelectedUser(user);
                                      setIsChangeRoleDialogOpen(true);
                                    }}
                                    className="cursor-pointer"
                                  >
                                    {user.role === "admin" ? (
                                      <>
                                        <ShieldOff className="mr-2 h-4 w-4" /> Remover administrador
                                      </>
                                    ) : (
                                      <>
                                        <Shield className="mr-2 h-4 w-4" /> Tornar administrador
                                      </>
                                    )}
                                  </DropdownMenuItem>
                                  
                                  <DropdownMenuItem
                                    onClick={() => {
                                      setSelectedUser(user);
                                      setIsDeleteDialogOpen(true);
                                    }}
                                    className="cursor-pointer text-destructive focus:text-destructive"
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" /> Excluir
                                  </DropdownMenuItem>
                                </>
                              )}
                              
                              {user.id === currentUser?.id && (
                                <DropdownMenuItem
                                  className="text-muted-foreground"
                                  disabled
                                >
                                  <UserCog className="mr-2 h-4 w-4" /> Você mesmo
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination */}
              {pageCount > 1 && (
                <div className="mt-4 flex justify-center">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          onClick={() => setPage(p => Math.max(1, p - 1))}
                          className={page === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                      
                      {Array.from({ length: Math.min(5, pageCount) }, (_, i) => {
                        // Display first page, last page, current page, and pages around current
                        let pageNum;
                        
                        if (pageCount <= 5) {
                          // If 5 or fewer pages, show all
                          pageNum = i + 1;
                        } else if (page <= 3) {
                          // Near the start
                          if (i < 4) {
                            pageNum = i + 1;
                          } else {
                            pageNum = pageCount;
                          }
                        } else if (page >= pageCount - 2) {
                          // Near the end
                          if (i === 0) {
                            pageNum = 1;
                          } else {
                            pageNum = pageCount - 4 + i;
                          }
                        } else {
                          // In the middle
                          if (i === 0) {
                            pageNum = 1;
                          } else if (i === 4) {
                            pageNum = pageCount;
                          } else {
                            pageNum = page + i - 2;
                          }
                        }
                        
                        // Show ellipsis instead of page number when needed
                        if ((i === 1 && pageNum !== 2) || (i === 3 && pageNum !== pageCount - 1)) {
                          return (
                            <PaginationItem key={`ellipsis-${i}`}>
                              <PaginationEllipsis />
                            </PaginationItem>
                          );
                        }
                        
                        return (
                          <PaginationItem key={pageNum}>
                            <PaginationLink
                              onClick={() => setPage(pageNum)}
                              isActive={page === pageNum}
                              className="cursor-pointer"
                            >
                              {pageNum}
                            </PaginationLink>
                          </PaginationItem>
                        );
                      })}
                      
                      <PaginationItem>
                        <PaginationNext 
                          onClick={() => setPage(p => Math.min(pageCount, p + 1))}
                          className={page === pageCount ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </>
          ) : (
            <div className="bg-dark-600 rounded-lg p-8 text-center">
              <Star className="mx-auto mb-4 text-dark-300" size={48} />
              <h3 className="text-xl font-semibold mb-2">
                {searchTerm || roleFilter !== "all" 
                  ? "Nenhum usuário encontrado" 
                  : "Nenhum usuário cadastrado"}
              </h3>
              <p className="text-dark-100 mb-4">
                {searchTerm || roleFilter !== "all"
                  ? "Tente buscar com outros termos ou limpar os filtros."
                  : "Ainda não há usuários cadastrados no sistema."}
              </p>
              {searchTerm || roleFilter !== "all" ? (
                <Button 
                  onClick={() => {
                    setSearchTerm("");
                    setRoleFilter("all");
                  }}
                >
                  Limpar filtros
                </Button>
              ) : null}
            </div>
          )}
        </main>
      </div>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
          </DialogHeader>
          <p className="py-4">
            Tem certeza que deseja excluir o usuário "{selectedUser?.name}"? 
            Esta ação não pode ser desfeita e excluirá todos os dados associados 
            a este usuário, incluindo histórico de visualização e favoritos.
          </p>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleDeleteUser}>
              Sim, excluir
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Change Role Confirmation Dialog */}
      <Dialog open={isChangeRoleDialogOpen} onOpenChange={setIsChangeRoleDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedUser?.role === "admin" 
                ? "Remover privilégios de administrador" 
                : "Conceder privilégios de administrador"}
            </DialogTitle>
          </DialogHeader>
          <p className="py-4">
            {selectedUser?.role === "admin" 
              ? `Tem certeza que deseja remover os privilégios de administrador de "${selectedUser?.name}"?`
              : `Tem certeza que deseja conceder privilégios de administrador a "${selectedUser?.name}"?`}
          </p>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsChangeRoleDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              variant={selectedUser?.role === "admin" ? "destructive" : "default"}
              onClick={() => handleChangeRole(selectedUser?.role === "admin" ? "user" : "admin")}
            >
              Sim, {selectedUser?.role === "admin" ? "remover" : "conceder"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
