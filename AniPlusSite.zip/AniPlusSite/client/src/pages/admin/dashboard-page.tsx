import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Header } from "@/components/layout/header";
import { 
  BarChart, 
  PieChart, 
  Bar, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs";
import { 
  UsersRound, 
  Film, 
  Clock, 
  TrendingUp, 
  Eye, 
  Star, 
  Calendar 
} from "lucide-react";

export default function DashboardPage() {
  const [timeRange, setTimeRange] = useState<"day" | "week" | "month" | "year">("week");
  
  // Fetch dashboard stats
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/admin/stats", timeRange],
  });
  
  const getStatistics = () => {
    if (isLoading || !stats) {
      return {
        totalUsers: 0,
        totalAnimes: 0,
        totalEpisodes: 0,
        activeUsers: 0,
        recentEpisodes: 0,
        popularAnimes: [],
        genreDistribution: [],
        watchTimeByDay: [],
        userRegistrations: []
      };
    }
    
    // Criar dados de exemplo enquanto as APIs reais não estão prontas
    const defaultStats = {
      ...stats,
      activeUsers: stats.totalUsers > 0 ? Math.floor(stats.totalUsers * 0.6) : 0,
      recentEpisodes: 5,
      popularAnimes: [
        { title: "Attack on Titan", views: 1250, rating: 4.8, percentage: 30 },
        { title: "One Piece", views: 1050, rating: 4.7, percentage: 25 },
        { title: "Demon Slayer", views: 940, rating: 4.6, percentage: 22 },
        { title: "Jujutsu Kaisen", views: 780, rating: 4.5, percentage: 19 },
        { title: "My Hero Academia", views: 650, rating: 4.3, percentage: 15 }
      ],
      genreDistribution: [
        { name: "Ação", value: 35 },
        { name: "Aventura", value: 25 },
        { name: "Comédia", value: 15 },
        { name: "Drama", value: 10 },
        { name: "Romance", value: 8 },
        { name: "Ficção Científica", value: 7 }
      ],
      watchTimeByDay: [
        { day: "Dom", hours: 120 },
        { day: "Seg", hours: 80 },
        { day: "Ter", hours: 85 },
        { day: "Qua", hours: 90 },
        { day: "Qui", hours: 95 },
        { day: "Sex", hours: 110 },
        { day: "Sáb", hours: 130 }
      ],
      userRegistrations: [
        { period: "Jan", count: 24 },
        { period: "Fev", count: 30 },
        { period: "Mar", count: 45 },
        { period: "Abr", count: 40 },
        { period: "Mai", count: 55 }
      ]
    };
    
    return defaultStats;
  };
  
  const {
    totalUsers,
    totalAnimes,
    totalEpisodes,
    activeUsers,
    recentEpisodes,
    popularAnimes,
    genreDistribution,
    watchTimeByDay,
    userRegistrations
  } = getStatistics();
  
  // Colors for charts
  const COLORS = ['#FF5A5F', '#6C63FF', '#00D1B2', '#FFB74D', '#9C27B0', '#3F51B5', '#009688'];
  
  return (
    <div className="min-h-screen flex">
      <AdminSidebar />
      
      <div className="flex-1 overflow-auto bg-dark-700">
        <Header />
        
        <main className="p-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <h1 className="text-2xl font-bold mb-2 sm:mb-0">Dashboard</h1>
            
            <Tabs 
              value={timeRange} 
              onValueChange={(value) => setTimeRange(value as "day" | "week" | "month" | "year")}
            >
              <TabsList>
                <TabsTrigger value="day">Hoje</TabsTrigger>
                <TabsTrigger value="week">Semana</TabsTrigger>
                <TabsTrigger value="month">Mês</TabsTrigger>
                <TabsTrigger value="year">Ano</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          {/* Stats overview */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Usuários Totais
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <UsersRound className="mr-2 h-4 w-4 text-primary" />
                  <div className="text-2xl font-bold">{totalUsers}</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Animes Cadastrados
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <Film className="mr-2 h-4 w-4 text-secondary" />
                  <div className="text-2xl font-bold">{totalAnimes}</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Episódios Totais
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <Clock className="mr-2 h-4 w-4 text-accent" />
                  <div className="text-2xl font-bold">{totalEpisodes}</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Usuários Ativos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <TrendingUp className="mr-2 h-4 w-4 text-green-500" />
                  <div className="text-2xl font-bold">{activeUsers}</div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Watch Time by Day */}
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Tempo de Visualização</CardTitle>
                <CardDescription>Horas assistidas por dia</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  {isLoading ? (
                    <div className="h-full flex items-center justify-center">
                      <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={watchTimeByDay}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <XAxis dataKey="day" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="hours" fill="#FF5A5F" name="Horas" />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Genre Distribution */}
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Distribuição de Gêneros</CardTitle>
                <CardDescription>Porcentagem de visualizações por gênero</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  {isLoading ? (
                    <div className="h-full flex items-center justify-center">
                      <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={genreDistribution}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {genreDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* New User Registrations */}
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Novos Usuários</CardTitle>
                <CardDescription>Registros por período</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  {isLoading ? (
                    <div className="h-full flex items-center justify-center">
                      <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={userRegistrations}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <XAxis dataKey="period" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="count" fill="#6C63FF" name="Usuários" />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Popular Animes */}
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Animes Populares</CardTitle>
                <CardDescription>Os mais assistidos no período</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {isLoading ? (
                    <div className="h-80 flex items-center justify-center">
                      <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                    </div>
                  ) : (
                    popularAnimes.map((anime, index) => (
                      <div key={index} className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-dark-500 flex items-center justify-center mr-3">
                          {index + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold truncate">{anime.title}</p>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Eye size={14} className="mr-1" />
                            <span className="mr-3">{anime.views} visualizações</span>
                            <Star size={14} className="mr-1 text-yellow-500" />
                            <span>{anime.rating}</span>
                          </div>
                        </div>
                        <div 
                          className="w-24 bg-dark-500 h-2 rounded-full overflow-hidden"
                          title={`${anime.percentage}% do total de visualizações`}
                        >
                          <div 
                            className="h-full bg-primary" 
                            style={{ width: `${anime.percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Atividade Recente</CardTitle>
              <CardDescription>Últimos eventos da plataforma</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="h-40 flex items-center justify-center">
                  <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex">
                    <div className="mr-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <Calendar className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Novo episódio adicionado</p>
                      <p className="text-sm text-muted-foreground">
                        Attack on Titan - Episódio Final foi adicionado
                      </p>
                      <p className="text-xs text-muted-foreground">
                        há 2 horas
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary/10">
                        <UsersRound className="h-5 w-5 text-secondary" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Novo usuário registrado</p>
                      <p className="text-sm text-muted-foreground">
                        Carlos Eduardo criou uma nova conta
                      </p>
                      <p className="text-xs text-muted-foreground">
                        há 5 horas
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10">
                        <Film className="h-5 w-5 text-accent" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Novo anime adicionado</p>
                      <p className="text-sm text-muted-foreground">
                        Jujutsu Kaisen foi adicionado ao catálogo
                      </p>
                      <p className="text-xs text-muted-foreground">
                        há 1 dia
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
