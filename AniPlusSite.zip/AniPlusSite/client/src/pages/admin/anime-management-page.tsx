import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Anime } from "@shared/schema";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Header } from "@/components/layout/header";
import { AnimeForm } from "@/components/admin/anime-form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  MoreHorizontal, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Film,
  ListFilter,
  Eye
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AnimeManagementPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [selectedAnime, setSelectedAnime] = useState<Anime | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  // Fetch animes
  const { data: animes = [], isLoading } = useQuery<Anime[]>({
    queryKey: ["/api/animes"],
  });
  
  // Filter and paginate animes
  const filteredAnimes = animes.filter(anime => {
    const matchesSearch = anime.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || anime.status === statusFilter;
    const matchesAudioLanguage = typeFilter === "all" || anime.audioLanguage === typeFilter;
    
    return matchesSearch && matchesStatus && matchesAudioLanguage;
  });
  
  const ITEMS_PER_PAGE = 10;
  const pageCount = Math.ceil(filteredAnimes.length / ITEMS_PER_PAGE);
  const paginatedAnimes = filteredAnimes.slice(
    (page - 1) * ITEMS_PER_PAGE,
    page * ITEMS_PER_PAGE
  );
  
  // Handle edit anime
  const handleEditAnime = (anime: Anime) => {
    setSelectedAnime(anime);
    setIsEditDialogOpen(true);
  };
  
  // Handle delete anime
  const handleDeleteAnime = async () => {
    if (!selectedAnime) return;
    
    try {
      await apiRequest("DELETE", `/api/admin/animes/${selectedAnime.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/animes"] });
      toast({
        title: "Anime excluído",
        description: `${selectedAnime.title} foi excluído com sucesso.`,
      });
      setIsDeleteDialogOpen(false);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível excluir o anime.",
        variant: "destructive",
      });
    }
  };
  
  // Get unique statuses and audio language options for filters
  const uniqueStatuses = Array.from(new Set(animes.map(anime => anime.status)));
  const uniqueAudioLanguages = Array.from(new Set(animes.map(anime => anime.audioLanguage)));
  
  return (
    <div className="min-h-screen flex">
      <AdminSidebar />
      
      <div className="flex-1 overflow-auto bg-dark-700">
        <Header />
        
        <main className="p-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <h1 className="text-2xl font-bold mb-2 sm:mb-0">Gerenciamento de Animes</h1>
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center">
                  <Plus className="mr-2" size={16} /> Adicionar Anime
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>Adicionar Novo Anime</DialogTitle>
                </DialogHeader>
                <AnimeForm onSuccess={() => setIsAddDialogOpen(false)} />
              </DialogContent>
            </Dialog>
          </div>
          
          {/* Search and filters */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
            <div className="sm:col-span-2 relative">
              <Input
                type="search"
                placeholder="Buscar animes..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setPage(1); // Reset to first page on search
                }}
                className="pl-10"
              />
              <Search className="absolute left-3 top-2.5 text-muted-foreground" size={16} />
            </div>
            
            <div className="flex items-center space-x-2">
              <ListFilter className="text-muted-foreground" size={16} />
              <Select 
                value={statusFilter} 
                onValueChange={(value) => {
                  setStatusFilter(value);
                  setPage(1); // Reset to first page on filter change
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  {uniqueStatuses.map((status) => (
                    <SelectItem key={status} value={status}>
                      {status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center space-x-2">
              <Film className="text-muted-foreground" size={16} />
              <Select 
                value={typeFilter} 
                onValueChange={(value) => {
                  setTypeFilter(value);
                  setPage(1); // Reset to first page on filter change
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Áudio" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {uniqueAudioLanguages.map((audioLanguage) => (
                    <SelectItem key={audioLanguage} value={audioLanguage}>
                      {audioLanguage === "dublado" ? "Dublado" : "Legendado"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Animes Table */}
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : paginatedAnimes.length > 0 ? (
            <>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Título</TableHead>
                      <TableHead>Áudio</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ano</TableHead>
                      <TableHead>Avaliação</TableHead>
                      <TableHead>Data de Criação</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedAnimes.map((anime) => (
                      <TableRow key={anime.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center space-x-3">
                            <img 
                              src={anime.coverImage} 
                              alt={anime.title} 
                              className="w-10 h-10 rounded object-cover"
                            />
                            <span className="truncate max-w-[200px]">{anime.title}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {anime.audioLanguage === "dublado" ? "Dublado" : "Legendado"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            className={
                              anime.status === "Em andamento" 
                                ? "bg-green-500" 
                                : anime.status === "Concluído" 
                                ? "bg-blue-500" 
                                : "bg-amber-500"
                            }
                          >
                            {anime.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{anime.releaseYear}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Eye className="mr-1 text-muted-foreground" size={14} />
                            <span>{anime.rating.toFixed(1)}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {format(new Date(anime.createdAt), "dd/MM/yyyy", { locale: ptBR })}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Ações</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => handleEditAnime(anime)}
                                className="cursor-pointer"
                              >
                                <Edit className="mr-2 h-4 w-4" /> Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => {
                                  setSelectedAnime(anime);
                                  setIsDeleteDialogOpen(true);
                                }}
                                className="cursor-pointer text-destructive focus:text-destructive"
                              >
                                <Trash2 className="mr-2 h-4 w-4" /> Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination */}
              {pageCount > 1 && (
                <div className="mt-4 flex justify-center">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          onClick={() => setPage(p => Math.max(1, p - 1))}
                          className={page === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                      
                      {Array.from({ length: Math.min(5, pageCount) }, (_, i) => {
                        // Display first page, last page, current page, and pages around current
                        let pageNum;
                        
                        if (pageCount <= 5) {
                          // If 5 or fewer pages, show all
                          pageNum = i + 1;
                        } else if (page <= 3) {
                          // Near the start
                          if (i < 4) {
                            pageNum = i + 1;
                          } else {
                            pageNum = pageCount;
                          }
                        } else if (page >= pageCount - 2) {
                          // Near the end
                          if (i === 0) {
                            pageNum = 1;
                          } else {
                            pageNum = pageCount - 4 + i;
                          }
                        } else {
                          // In the middle
                          if (i === 0) {
                            pageNum = 1;
                          } else if (i === 4) {
                            pageNum = pageCount;
                          } else {
                            pageNum = page + i - 2;
                          }
                        }
                        
                        // Show ellipsis instead of page number when needed
                        if ((i === 1 && pageNum !== 2) || (i === 3 && pageNum !== pageCount - 1)) {
                          return (
                            <PaginationItem key={`ellipsis-${i}`}>
                              <PaginationEllipsis />
                            </PaginationItem>
                          );
                        }
                        
                        return (
                          <PaginationItem key={pageNum}>
                            <PaginationLink
                              onClick={() => setPage(pageNum)}
                              isActive={page === pageNum}
                              className="cursor-pointer"
                            >
                              {pageNum}
                            </PaginationLink>
                          </PaginationItem>
                        );
                      })}
                      
                      <PaginationItem>
                        <PaginationNext 
                          onClick={() => setPage(p => Math.min(pageCount, p + 1))}
                          className={page === pageCount ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </>
          ) : (
            <div className="bg-dark-600 rounded-lg p-8 text-center">
              <Film className="mx-auto mb-4 text-dark-300" size={48} />
              <h3 className="text-xl font-semibold mb-2">
                {searchTerm || statusFilter !== "all" || typeFilter !== "all" 
                  ? "Nenhum anime encontrado" 
                  : "Nenhum anime cadastrado"}
              </h3>
              <p className="text-dark-100 mb-4">
                {searchTerm || statusFilter !== "all" || typeFilter !== "all"
                  ? "Tente buscar com outros termos ou limpar os filtros."
                  : "Comece adicionando um novo anime ao catálogo."}
              </p>
              {searchTerm || statusFilter !== "all" || typeFilter !== "all" ? (
                <Button 
                  onClick={() => {
                    setSearchTerm("");
                    setStatusFilter("all");
                    setTypeFilter("all");
                  }}
                >
                  Limpar filtros
                </Button>
              ) : (
                <Button onClick={() => setIsAddDialogOpen(true)}>
                  <Plus className="mr-2" size={16} /> Adicionar Anime
                </Button>
              )}
            </div>
          )}
        </main>
      </div>
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Editar Anime</DialogTitle>
          </DialogHeader>
          <AnimeForm 
            anime={selectedAnime || undefined} 
            onSuccess={() => setIsEditDialogOpen(false)} 
          />
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
          </DialogHeader>
          <p className="py-4">
            Tem certeza que deseja excluir o anime "{selectedAnime?.title}"? 
            Esta ação não pode ser desfeita e também excluirá todas as temporadas, 
            episódios e históricos de visualização relacionados.
          </p>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleDeleteAnime}>
              Sim, excluir
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
