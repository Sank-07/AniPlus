import { useQuery } from "@tanstack/react-query";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { 
  Clock, 
  Eye, 
  Film, 
  Heart, 
  Star, 
  TrendingUp, 
  Users 
} from "lucide-react";

export default function StatsPage() {
  // Buscar estatísticas da API
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  const defaultStats = {
    totalUsers: 0,
    totalAnimes: 0,
    totalEpisodes: 0,
    watchCount: 0,
    favoriteCount: 0,
    dailyReleases: {
      seg: 0,
      ter: 0,
      qua: 0,
      qui: 0,
      sex: 0,
      sab: 0,
      dom: 0
    }
  };

  const {
    totalUsers,
    totalAnimes,
    totalEpisodes,
    watchCount,
    favoriteCount,
    dailyReleases
  } = stats || defaultStats;

  // Dados para o gráfico de distribuição dos dias
  const releasesData = [
    { name: "Segunda", value: dailyReleases?.seg || 0 },
    { name: "Terça", value: dailyReleases?.ter || 0 },
    { name: "Quarta", value: dailyReleases?.qua || 0 },
    { name: "Quinta", value: dailyReleases?.qui || 0 },
    { name: "Sexta", value: dailyReleases?.sex || 0 },
    { name: "Sábado", value: dailyReleases?.sab || 0 },
    { name: "Domingo", value: dailyReleases?.dom || 0 }
  ];

  // Dados para o gráfico de crescimento do usuário (simulados)
  const userGrowthData = [
    { month: "Jan", users: 150 },
    { month: "Fev", users: 200 },
    { month: "Mar", users: 320 },
    { month: "Abr", users: 450 },
    { month: "Mai", users: 530 },
    { month: "Jun", users: 650 },
    { month: "Jul", users: 750 },
  ];

  // Dados para o gráfico de visualizações por gênero (simulados)
  const genreViewsData = [
    { name: "Ação", views: 3500 },
    { name: "Aventura", views: 2800 },
    { name: "Comédia", views: 2200 },
    { name: "Romance", views: 1800 },
    { name: "Drama", views: 1500 },
    { name: "Sci-Fi", views: 1200 },
  ];

  // Dados para visualizações por horário (simulados)
  const viewsByTimeData = [
    { hour: "00:00", views: 120 },
    { hour: "02:00", views: 70 },
    { hour: "04:00", views: 40 },
    { hour: "06:00", views: 90 },
    { hour: "08:00", views: 150 },
    { hour: "10:00", views: 230 },
    { hour: "12:00", views: 310 },
    { hour: "14:00", views: 280 },
    { hour: "16:00", views: 350 },
    { hour: "18:00", views: 420 },
    { hour: "20:00", views: 490 },
    { hour: "22:00", views: 380 },
  ];

  // Cores para os gráficos
  const COLORS = ['#FF5A5F', '#6C63FF', '#00D1B2', '#FFB74D', '#9C27B0', '#3F51B5', '#009688'];

  return (
    <div className="min-h-screen flex">
      <AdminSidebar />
      
      <div className="flex-1 bg-dark-700 overflow-auto">
        <Header />
        
        <main className="p-6">
          <h1 className="text-2xl font-bold mb-6">Estatísticas da Plataforma</h1>
          
          {/* Cards de resumo */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Usuários
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <Users className="mr-2 h-4 w-4 text-primary" />
                  <div className="text-2xl font-bold">{totalUsers}</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Animes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <Film className="mr-2 h-4 w-4 text-secondary" />
                  <div className="text-2xl font-bold">{totalAnimes}</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Episódios
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <Clock className="mr-2 h-4 w-4 text-accent" />
                  <div className="text-2xl font-bold">{totalEpisodes}</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Visualizações
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <Eye className="mr-2 h-4 w-4 text-green-500" />
                  <div className="text-2xl font-bold">{watchCount}</div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="overview">
            <TabsList className="mb-6">
              <TabsTrigger value="overview">Visão Geral</TabsTrigger>
              <TabsTrigger value="users">Usuários</TabsTrigger>
              <TabsTrigger value="content">Conteúdo</TabsTrigger>
              <TabsTrigger value="engagement">Engajamento</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-6">
              {/* Crescimento de usuários */}
              <Card>
                <CardHeader>
                  <CardTitle>Crescimento de Usuários</CardTitle>
                  <CardDescription>Novos usuários registrados ao longo do tempo</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    {isLoading ? (
                      <div className="h-full flex items-center justify-center">
                        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={userGrowthData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#2A2D3E" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip 
                            contentStyle={{ backgroundColor: "#1F2131", borderColor: "#2A2D3E" }}
                          />
                          <Legend />
                          <Line 
                            type="monotone" 
                            dataKey="users" 
                            stroke="#FF5A5F" 
                            activeDot={{ r: 8 }} 
                            name="Usuários"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              {/* Distribuição por dia da semana */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Programação Semanal</CardTitle>
                    <CardDescription>Distribuição dos lançamentos por dia da semana</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      {isLoading ? (
                        <div className="h-full flex items-center justify-center">
                          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                        </div>
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={releasesData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#2A2D3E" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip 
                              contentStyle={{ backgroundColor: "#1F2131", borderColor: "#2A2D3E" }}
                            />
                            <Bar dataKey="value" name="Lançamentos" fill="#6C63FF" />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </CardContent>
                </Card>
                
                {/* Visualizações por gênero */}
                <Card>
                  <CardHeader>
                    <CardTitle>Visualizações por Gênero</CardTitle>
                    <CardDescription>Preferências de conteúdo dos usuários</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      {isLoading ? (
                        <div className="h-full flex items-center justify-center">
                          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                        </div>
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={genreViewsData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="views"
                            >
                              {genreViewsData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip 
                              contentStyle={{ backgroundColor: "#1F2131", borderColor: "#2A2D3E" }}
                            />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="users" className="space-y-6">
              {/* Mais conteúdo sobre usuários poderia ser adicionado aqui */}
              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas de Usuários</CardTitle>
                  <CardDescription>Informações detalhadas sobre o comportamento dos usuários</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Esta seção está em desenvolvimento.</p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="content" className="space-y-6">
              {/* Mais conteúdo sobre dados de conteúdo poderia ser adicionado aqui */}
              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas de Conteúdo</CardTitle>
                  <CardDescription>Análise detalhada do conteúdo disponível na plataforma</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Esta seção está em desenvolvimento.</p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="engagement" className="space-y-6">
              {/* Mais conteúdo sobre engajamento poderia ser adicionado aqui */}
              <Card>
                <CardHeader>
                  <CardTitle>Horas de Pico</CardTitle>
                  <CardDescription>Visualizações distribuídas ao longo do dia</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    {isLoading ? (
                      <div className="h-full flex items-center justify-center">
                        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={viewsByTimeData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#2A2D3E" />
                          <XAxis dataKey="hour" />
                          <YAxis />
                          <Tooltip 
                            contentStyle={{ backgroundColor: "#1F2131", borderColor: "#2A2D3E" }}
                          />
                          <Bar dataKey="views" name="Visualizações" fill="#00D1B2" />
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}