import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Anime, Episode } from "@shared/schema";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Header } from "@/components/layout/header";
import { EpisodeForm } from "@/components/admin/episode-form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  MoreHorizontal, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Play,
  Filter,
  Clock,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function EpisodesManagementPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [animeFilter, setAnimeFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [selectedEpisode, setSelectedEpisode] = useState<Episode | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isPlayerDialogOpen, setIsPlayerDialogOpen] = useState(false);
  
  // Fetch episodes
  const { data: episodes = [], isLoading: isLoadingEpisodes } = useQuery<Episode[]>({
    queryKey: ["/api/episodes/all"],
  });
  
  // Fetch animes for filter
  const { data: animes = [], isLoading: isLoadingAnimes } = useQuery<Anime[]>({
    queryKey: ["/api/animes"],
  });
  
  // Get anime title map for quick lookup
  const animeTitleMap = animes.reduce((acc, anime) => {
    acc[anime.id] = anime.title;
    return acc;
  }, {} as Record<number, string>);
  
  // Filter and paginate episodes
  const filteredEpisodes = episodes.filter(episode => {
    const animeTitle = animeTitleMap[episode.animeId] || "";
    const matchesSearch = 
      animeTitle.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (episode.title && episode.title.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesAnime = animeFilter === "all" || episode.animeId.toString() === animeFilter;
    
    return matchesSearch && matchesAnime;
  });
  
  const ITEMS_PER_PAGE = 10;
  const pageCount = Math.ceil(filteredEpisodes.length / ITEMS_PER_PAGE);
  const paginatedEpisodes = filteredEpisodes.slice(
    (page - 1) * ITEMS_PER_PAGE,
    page * ITEMS_PER_PAGE
  );
  
  // Format duration to readable time
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  // Handle edit episode
  const handleEditEpisode = (episode: Episode) => {
    setSelectedEpisode(episode);
    setIsEditDialogOpen(true);
  };
  
  // Handle delete episode
  const handleDeleteEpisode = async () => {
    if (!selectedEpisode) return;
    
    try {
      await apiRequest("DELETE", `/api/admin/episodes/${selectedEpisode.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/episodes"] });
      toast({
        title: "Episódio excluído",
        description: `Episódio ${selectedEpisode.number} foi excluído com sucesso.`,
      });
      setIsDeleteDialogOpen(false);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível excluir o episódio.",
        variant: "destructive",
      });
    }
  };
  
  // Handle preview episode
  const handlePreviewEpisode = (episode: Episode) => {
    setSelectedEpisode(episode);
    setIsPlayerDialogOpen(true);
  };
  
  return (
    <div className="min-h-screen flex">
      <AdminSidebar />
      
      <div className="flex-1 overflow-auto bg-dark-700">
        <Header />
        
        <main className="p-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <h1 className="text-2xl font-bold mb-2 sm:mb-0">Gerenciamento de Episódios</h1>
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center">
                  <Plus className="mr-2" size={16} /> Adicionar Episódio
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>Adicionar Novo Episódio</DialogTitle>
                </DialogHeader>
                <EpisodeForm onSuccess={() => setIsAddDialogOpen(false)} />
              </DialogContent>
            </Dialog>
          </div>
          
          {/* Search and filters */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <div className="sm:col-span-2 relative">
              <Input
                type="search"
                placeholder="Buscar episódios..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setPage(1); // Reset to first page on search
                }}
                className="pl-10"
              />
              <Search className="absolute left-3 top-2.5 text-muted-foreground" size={16} />
            </div>
            
            <div className="flex items-center space-x-2">
              <Filter className="text-muted-foreground" size={16} />
              <Select 
                value={animeFilter} 
                onValueChange={(value) => {
                  setAnimeFilter(value);
                  setPage(1); // Reset to first page on filter change
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por anime" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os animes</SelectItem>
                  {animes.map((anime) => (
                    <SelectItem key={anime.id} value={anime.id.toString()}>
                      {anime.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Episodes Table */}
          {isLoadingEpisodes || isLoadingAnimes ? (
            <div className="flex justify-center py-12">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : paginatedEpisodes.length > 0 ? (
            <>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Anime</TableHead>
                      <TableHead>Episódio</TableHead>
                      <TableHead>Duração</TableHead>
                      <TableHead>Data de Lançamento</TableHead>
                      <TableHead>Visualizações</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedEpisodes.map((episode) => (
                      <TableRow key={episode.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center space-x-3">
                            <img 
                              src={episode.thumbnail} 
                              alt={animeTitleMap[episode.animeId] || "Anime"} 
                              className="w-16 h-10 rounded object-cover"
                            />
                            <span className="truncate max-w-[150px]">
                              {animeTitleMap[episode.animeId] || "Anime desconhecido"}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">Ep. {episode.number}</div>
                            {episode.title && (
                              <div className="text-sm text-muted-foreground truncate max-w-[150px]">
                                {episode.title}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex items-center text-muted-foreground">
                            <Clock className="mr-1" size={14} />
                            <span>{formatDuration(episode.duration)}</span>
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex items-center text-muted-foreground">
                            <Calendar className="mr-1" size={14} />
                            <span>
                              {format(new Date(episode.releaseDate), "dd/MM/yyyy", { locale: ptBR })}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-dark-500">
                            {Math.floor(Math.random() * 1000)} views
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handlePreviewEpisode(episode)}
                              className="text-muted-foreground hover:text-primary"
                            >
                              <Play className="h-4 w-4" />
                            </Button>
                            
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => handleEditEpisode(episode)}
                                  className="cursor-pointer"
                                >
                                  <Edit className="mr-2 h-4 w-4" /> Editar
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => {
                                    setSelectedEpisode(episode);
                                    setIsDeleteDialogOpen(true);
                                  }}
                                  className="cursor-pointer text-destructive focus:text-destructive"
                                >
                                  <Trash2 className="mr-2 h-4 w-4" /> Excluir
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination */}
              {pageCount > 1 && (
                <div className="mt-4 flex justify-center">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          onClick={() => setPage(p => Math.max(1, p - 1))}
                          className={page === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                      
                      {Array.from({ length: Math.min(5, pageCount) }, (_, i) => {
                        // Display first page, last page, current page, and pages around current
                        let pageNum;
                        
                        if (pageCount <= 5) {
                          // If 5 or fewer pages, show all
                          pageNum = i + 1;
                        } else if (page <= 3) {
                          // Near the start
                          if (i < 4) {
                            pageNum = i + 1;
                          } else {
                            pageNum = pageCount;
                          }
                        } else if (page >= pageCount - 2) {
                          // Near the end
                          if (i === 0) {
                            pageNum = 1;
                          } else {
                            pageNum = pageCount - 4 + i;
                          }
                        } else {
                          // In the middle
                          if (i === 0) {
                            pageNum = 1;
                          } else if (i === 4) {
                            pageNum = pageCount;
                          } else {
                            pageNum = page + i - 2;
                          }
                        }
                        
                        // Show ellipsis instead of page number when needed
                        if ((i === 1 && pageNum !== 2) || (i === 3 && pageNum !== pageCount - 1)) {
                          return (
                            <PaginationItem key={`ellipsis-${i}`}>
                              <PaginationEllipsis />
                            </PaginationItem>
                          );
                        }
                        
                        return (
                          <PaginationItem key={pageNum}>
                            <PaginationLink
                              onClick={() => setPage(pageNum)}
                              isActive={page === pageNum}
                              className="cursor-pointer"
                            >
                              {pageNum}
                            </PaginationLink>
                          </PaginationItem>
                        );
                      })}
                      
                      <PaginationItem>
                        <PaginationNext 
                          onClick={() => setPage(p => Math.min(pageCount, p + 1))}
                          className={page === pageCount ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </>
          ) : (
            <div className="bg-dark-600 rounded-lg p-8 text-center">
              <Play className="mx-auto mb-4 text-dark-300" size={48} />
              <h3 className="text-xl font-semibold mb-2">
                {searchTerm || animeFilter !== "all" 
                  ? "Nenhum episódio encontrado" 
                  : "Nenhum episódio cadastrado"}
              </h3>
              <p className="text-dark-100 mb-4">
                {searchTerm || animeFilter !== "all"
                  ? "Tente buscar com outros termos ou limpar os filtros."
                  : "Comece adicionando novos episódios ao catálogo."}
              </p>
              {searchTerm || animeFilter !== "all" ? (
                <Button 
                  onClick={() => {
                    setSearchTerm("");
                    setAnimeFilter("all");
                  }}
                >
                  Limpar filtros
                </Button>
              ) : (
                <Button onClick={() => setIsAddDialogOpen(true)}>
                  <Plus className="mr-2" size={16} /> Adicionar Episódio
                </Button>
              )}
            </div>
          )}
        </main>
      </div>
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Editar Episódio</DialogTitle>
          </DialogHeader>
          <EpisodeForm 
            episode={selectedEpisode || undefined} 
            animeId={selectedEpisode?.animeId}
            onSuccess={() => setIsEditDialogOpen(false)} 
          />
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
          </DialogHeader>
          <p className="py-4">
            Tem certeza que deseja excluir o episódio {selectedEpisode?.number} de 
            "{animeTitleMap[selectedEpisode?.animeId || 0]}"? 
            Esta ação não pode ser desfeita e também excluirá todos os históricos 
            de visualização relacionados.
          </p>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleDeleteEpisode}>
              Sim, excluir
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Video Player Preview Dialog */}
      <Dialog open={isPlayerDialogOpen} onOpenChange={setIsPlayerDialogOpen}>
        <DialogContent className="max-w-5xl">
          <DialogHeader>
            <DialogTitle>
              Pré-visualização: {animeTitleMap[selectedEpisode?.animeId || 0]} - 
              Episódio {selectedEpisode?.number} 
              {selectedEpisode?.title ? `: ${selectedEpisode.title}` : ''}
            </DialogTitle>
          </DialogHeader>
          <div className="aspect-video bg-black">
            {selectedEpisode && (
              <iframe
                src={selectedEpisode.videoUrl}
                allow="autoplay; fullscreen; picture-in-picture"
                className="w-full h-full"
              ></iframe>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
