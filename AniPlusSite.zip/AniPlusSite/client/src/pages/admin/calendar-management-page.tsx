import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Calendar as CalendarIcon, Plus, Edit, Trash2, Clock, Tv } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Anime } from "@shared/schema";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

type CalendarEntry = {
  id: number;
  animeId: number;
  episodeId: number | null;
  title: string;
  description: string | null;
  releaseDay: string;
  releaseTime: string;
  animeTitle?: string; // Adicionado para exibição
};

type FormData = {
  animeId: number;
  episodeId: number | null;
  title: string;
  description: string | null;
  releaseDay: string;
  releaseTime: string;
};

const weekDays = [
  { value: "seg", label: "Segunda-feira" },
  { value: "ter", label: "Terça-feira" },
  { value: "qua", label: "Quarta-feira" },
  { value: "qui", label: "Quinta-feira" },
  { value: "sex", label: "Sexta-feira" },
  { value: "sab", label: "Sábado" },
  { value: "dom", label: "Domingo" }
];

export default function CalendarManagementPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<CalendarEntry | null>(null);
  const [formData, setFormData] = useState<FormData>({
    animeId: 0,
    episodeId: null,
    title: "",
    description: null,
    releaseDay: "seg",
    releaseTime: "18:00"
  });
  
  const { toast } = useToast();
  
  const { data: calendarEntries = [], isLoading: isLoadingCalendar } = useQuery({
    queryKey: ["/api/calendar"],
  });
  
  const { data: animes = [], isLoading: isLoadingAnimes } = useQuery({
    queryKey: ["/api/animes"],
  });
  
  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest("POST", "/api/admin/calendar", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/calendar"] });
      toast({
        title: "Sucesso",
        description: "Entrada adicionada ao calendário"
      });
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: `Falha ao adicionar ao calendário: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const updateMutation = useMutation({
    mutationFn: async (data: { id: number; formData: FormData }) => {
      const res = await apiRequest("PUT", `/api/admin/calendar/${data.id}`, data.formData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/calendar"] });
      toast({
        title: "Sucesso",
        description: "Entrada do calendário atualizada"
      });
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: `Falha ao atualizar calendário: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/admin/calendar/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/calendar"] });
      toast({
        title: "Sucesso",
        description: "Entrada removida do calendário"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: `Falha ao remover do calendário: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleOpenDialog = (entry?: CalendarEntry) => {
    if (entry) {
      setEditingEntry(entry);
      setFormData({
        animeId: entry.animeId,
        episodeId: entry.episodeId,
        title: entry.title,
        description: entry.description,
        releaseDay: entry.releaseDay,
        releaseTime: entry.releaseTime
      });
    } else {
      setEditingEntry(null);
      resetForm();
    }
    setIsDialogOpen(true);
  };
  
  const resetForm = () => {
    setFormData({
      animeId: 0,
      episodeId: null,
      title: "",
      description: null,
      releaseDay: "seg",
      releaseTime: "18:00"
    });
    setEditingEntry(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.animeId === 0) {
      toast({
        title: "Erro",
        description: "Selecione um anime",
        variant: "destructive"
      });
      return;
    }
    
    if (!formData.title) {
      toast({
        title: "Erro",
        description: "Informe um título",
        variant: "destructive"
      });
      return;
    }
    
    if (editingEntry) {
      updateMutation.mutate({ id: editingEntry.id, formData });
    } else {
      createMutation.mutate(formData);
    }
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Tem certeza que deseja remover esta entrada do calendário?")) {
      deleteMutation.mutate(id);
    }
  };
  
  const handleAnimeChange = (animeId: string) => {
    const selectedAnime = animes.find((anime: Anime) => anime.id === parseInt(animeId));
    
    setFormData({
      ...formData,
      animeId: parseInt(animeId),
      title: selectedAnime ? selectedAnime.title : ""
    });
  };
  
  // Função para pegar o nome do anime a partir do ID
  const getAnimeName = (animeId: number) => {
    const anime = animes.find((a: Anime) => a.id === animeId);
    return anime ? anime.title : "Desconhecido";
  };
  
  const getDayName = (day: string) => {
    const weekDay = weekDays.find(d => d.value === day);
    return weekDay ? weekDay.label : day;
  };
  
  // Organizar entradas do calendário por dia da semana
  const organizeByWeekday = (entries: CalendarEntry[]) => {
    const weekdayOrder: { [key: string]: number } = {
      seg: 0, ter: 1, qua: 2, qui: 3, sex: 4, sab: 5, dom: 6
    };
    
    return [...entries].sort((a, b) => {
      const dayDiff = weekdayOrder[a.releaseDay] - weekdayOrder[b.releaseDay];
      if (dayDiff !== 0) return dayDiff;
      return a.releaseTime.localeCompare(b.releaseTime);
    });
  };
  
  const isLoading = isLoadingCalendar || isLoadingAnimes;
  
  return (
    <div className="min-h-screen flex">
      <AdminSidebar />
      
      <div className="flex-1 bg-dark-700 overflow-auto">
        <Header />
        
        <main className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Gerenciamento do Calendário</h1>
            
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="mr-2 h-4 w-4" />
              Adicionar
            </Button>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Calendário de Lançamentos</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center p-6">
                  <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Dia</TableHead>
                      <TableHead>Horário</TableHead>
                      <TableHead>Anime</TableHead>
                      <TableHead>Título</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {organizeByWeekday(calendarEntries).map((entry: CalendarEntry) => (
                      <TableRow key={entry.id}>
                        <TableCell className="font-medium">
                          {getDayName(entry.releaseDay)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Clock className="mr-2 h-4 w-4 text-primary" />
                            {entry.releaseTime}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Tv className="mr-2 h-4 w-4 text-secondary" />
                            {getAnimeName(entry.animeId)}
                          </div>
                        </TableCell>
                        <TableCell>{entry.title}</TableCell>
                        <TableCell>{entry.description || "—"}</TableCell>
                        <TableCell className="text-right space-x-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleOpenDialog(entry)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleDelete(entry.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    
                    {calendarEntries.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">
                          Nenhuma entrada de calendário encontrada
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingEntry ? "Editar entrada do calendário" : "Adicionar ao calendário"}
            </DialogTitle>
            <DialogDescription>
              Defina os detalhes do lançamento no calendário de programação.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="anime" className="text-right">
                  Anime
                </Label>
                <Select 
                  value={formData.animeId.toString()} 
                  onValueChange={handleAnimeChange}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Selecione um anime" />
                  </SelectTrigger>
                  <SelectContent>
                    {animes.map((anime: Anime) => (
                      <SelectItem key={anime.id} value={anime.id.toString()}>
                        {anime.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="title" className="text-right">
                  Título
                </Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  className="col-span-3"
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="description" className="text-right">
                  Descrição
                </Label>
                <Input
                  id="description"
                  value={formData.description || ""}
                  onChange={(e) => setFormData({...formData, description: e.target.value || null})}
                  className="col-span-3"
                  placeholder="Opcional"
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="day" className="text-right">
                  Dia
                </Label>
                <Select 
                  value={formData.releaseDay} 
                  onValueChange={(value) => setFormData({...formData, releaseDay: value})}
                >
                  <SelectTrigger id="day" className="col-span-3">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {weekDays.map((day) => (
                      <SelectItem key={day.value} value={day.value}>
                        {day.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="time" className="text-right">
                  Horário
                </Label>
                <Input
                  id="time"
                  type="time"
                  value={formData.releaseTime}
                  onChange={(e) => setFormData({...formData, releaseTime: e.target.value})}
                  className="col-span-3"
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {createMutation.isPending || updateMutation.isPending ? (
                  <div className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin mr-2"></div>
                ) : null}
                {editingEntry ? "Salvar" : "Adicionar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}