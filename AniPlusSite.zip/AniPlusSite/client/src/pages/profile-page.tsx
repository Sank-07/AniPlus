import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { User, Anime } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Edit, 
  User as UserIcon, 
  BookmarkCheck, 
  History, 
  Film, 
  Trophy, 
  Mail, 
  Calendar
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AnimeCard } from "@/components/anime/anime-card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

// Form Schema
const profileFormSchema = z.object({
  name: z.string().min(1, "O nome é obrigatório"),
  email: z.string().email("Email inválido"),
  avatar: z.string().url("A URL deve ser válida").optional().or(z.literal("")),
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;

export default function ProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  
  // Fetch user favorites
  const { data: favorites = [] } = useQuery<Anime[]>({
    queryKey: ["/api/user/favorites"],
  });
  
  // Fetch user watch history
  const { data: history = [] } = useQuery({
    queryKey: ["/api/user/history"],
  });
  
  // Fetch user rankings
  const { data: rankings = [] } = useQuery<User[]>({
    queryKey: ["/api/rankings"],
  });
  
  const userRank = rankings.findIndex(u => u.id === user?.id) + 1;
  const totalUsers = rankings.length;
  
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      avatar: user?.avatar || "",
    },
  });
  
  const onSubmit = async (data: ProfileFormValues) => {
    try {
      await apiRequest("PUT", "/api/user/profile", data);
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Perfil atualizado",
        description: "Suas informações foram atualizadas com sucesso.",
      });
      setIsEditing(false);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar seu perfil.",
        variant: "destructive",
      });
    }
  };
  
  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 bg-dark-700">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Profile Card */}
            <div className="md:col-span-1">
              <div className="bg-dark-600 rounded-lg shadow-lg overflow-hidden">
                <div className="bg-gradient-to-r from-primary to-secondary h-32"></div>
                <div className="p-6 -mt-16">
                  <div className="flex justify-between items-start">
                    <Avatar className="h-24 w-24 border-4 border-dark-600">
                      <AvatarImage src={user.avatar || ""} alt={user.name} />
                      <AvatarFallback className="bg-primary text-white text-lg">
                        {user.name.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    
                    {!isEditing && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setIsEditing(true)}
                        className="bg-dark-500 border-dark-400"
                      >
                        <Edit className="mr-1" size={14} /> Editar
                      </Button>
                    )}
                  </div>
                  
                  {isEditing ? (
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Nome</FormLabel>
                              <FormControl>
                                <Input placeholder="Seu nome" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input placeholder="seu@email.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="avatar"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>URL do Avatar</FormLabel>
                              <FormControl>
                                <Input placeholder="https://example.com/avatar.jpg" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex justify-end space-x-2">
                          <Button
                            type="button"
                            variant="ghost"
                            onClick={() => setIsEditing(false)}
                          >
                            Cancelar
                          </Button>
                          <Button type="submit">Salvar</Button>
                        </div>
                      </form>
                    </Form>
                  ) : (
                    <>
                      <h2 className="text-2xl font-bold mt-4">{user.name}</h2>
                      <div className="flex items-center mt-1 text-dark-100">
                        <UserIcon size={14} className="mr-1" />
                        <span>{user.username}</span>
                      </div>
                      
                      <div className="flex items-center mt-1 text-dark-100">
                        <Mail size={14} className="mr-1" />
                        <span>{user.email}</span>
                      </div>
                      
                      <div className="flex items-center mt-1 text-dark-100">
                        <Calendar size={14} className="mr-1" />
                        <span>Membro desde {formatDistanceToNow(new Date(user.createdAt), { 
                          addSuffix: true, 
                          locale: ptBR 
                        })}</span>
                      </div>
                      
                      <div className="mt-4 flex justify-between">
                        <div className="text-center">
                          <div className="text-xl font-bold">{user.animeWatched}</div>
                          <div className="text-dark-100 text-sm">Animes</div>
                        </div>
                        
                        <div className="text-center">
                          <div className="text-xl font-bold">{favorites.length}</div>
                          <div className="text-dark-100 text-sm">Favoritos</div>
                        </div>
                        
                        <div className="text-center">
                          <div className="text-xl font-bold">{history.length}</div>
                          <div className="text-dark-100 text-sm">Episódios</div>
                        </div>
                      </div>
                      
                      {user.role === "admin" && (
                        <div className="mt-4">
                          <Badge className="bg-primary text-white">Administrador</Badge>
                        </div>
                      )}
                      
                      {/* Ranking info */}
                      {userRank > 0 && (
                        <div className="mt-6 p-4 bg-dark-500 rounded-lg">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Trophy className="text-yellow-500 mr-2" size={20} />
                              <div>
                                <div className="text-sm text-dark-100">Seu ranking</div>
                                <div className="font-bold">#{userRank} de {totalUsers}</div>
                              </div>
                            </div>
                            <div className="flex items-center">
                              {userRank <= 3 ? (
                                <Badge className="bg-yellow-500 text-dark-700">Top 3</Badge>
                              ) : userRank <= 10 ? (
                                <Badge className="bg-secondary">Top 10</Badge>
                              ) : (
                                <Badge variant="outline">Otaku</Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>
            
            {/* Content Area */}
            <div className="md:col-span-2">
              <Tabs defaultValue="favorites">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="favorites" className="flex items-center justify-center">
                    <BookmarkCheck className="mr-2" size={16} /> Favoritos
                  </TabsTrigger>
                  <TabsTrigger value="history" className="flex items-center justify-center">
                    <History className="mr-2" size={16} /> Histórico
                  </TabsTrigger>
                  <TabsTrigger value="stats" className="flex items-center justify-center">
                    <Film className="mr-2" size={16} /> Estatísticas
                  </TabsTrigger>
                </TabsList>
                
                <div className="mt-6">
                  <TabsContent value="favorites">
                    {favorites.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                        {favorites.map((anime) => (
                          <AnimeCard key={anime.id} anime={anime} />
                        ))}
                      </div>
                    ) : (
                      <div className="bg-dark-600 rounded-lg p-8 text-center">
                        <BookmarkCheck className="mx-auto mb-4 text-dark-300" size={48} />
                        <h3 className="text-xl font-semibold mb-2">Nenhum favorito ainda</h3>
                        <p className="text-dark-100 mb-4">
                          Você ainda não adicionou nenhum anime aos seus favoritos.
                        </p>
                        <Button asChild>
                          <a href="/animes">Explorar animes</a>
                        </Button>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="history">
                    {history.length > 0 ? (
                      <div className="bg-dark-600 rounded-lg">
                        <div className="space-y-1">
                          {history.map((item: any) => (
                            <a 
                              key={item.id} 
                              href={`/player/${item.episodeId}`}
                              className="block p-4 hover:bg-dark-500 transition rounded-lg"
                            >
                              <div className="flex items-center gap-4">
                                <img 
                                  src={item.thumbnail || "https://images.unsplash.com/photo-1559981421-3e0c0d156372?w=60&h=60&fit=crop"} 
                                  alt={item.animeTitle || "Anime"} 
                                  className="w-12 h-12 rounded object-cover"
                                />
                                <div className="flex-1">
                                  <h3 className="font-medium">{item.animeTitle || "Anime"}</h3>
                                  <p className="text-sm text-dark-100">
                                    Episódio {item.episodeNumber || "?"} 
                                    {item.completed ? " (Completo)" : " (Em progresso)"}
                                  </p>
                                </div>
                                <div className="text-sm text-dark-100">
                                  {formatDistanceToNow(new Date(item.watchedAt), {
                                    addSuffix: true,
                                    locale: ptBR
                                  })}
                                </div>
                              </div>
                            </a>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="bg-dark-600 rounded-lg p-8 text-center">
                        <History className="mx-auto mb-4 text-dark-300" size={48} />
                        <h3 className="text-xl font-semibold mb-2">Nenhum histórico ainda</h3>
                        <p className="text-dark-100 mb-4">
                          Você ainda não assistiu nenhum episódio.
                        </p>
                        <Button asChild>
                          <a href="/animes">Começar a assistir</a>
                        </Button>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="stats">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-dark-600 rounded-lg p-6">
                        <h3 className="text-lg font-semibold mb-4">Gêneros Favoritos</h3>
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <span>Ação</span>
                              <span className="text-sm text-dark-100">70%</span>
                            </div>
                            <div className="h-2 bg-dark-500 rounded-full">
                              <div className="h-full bg-primary rounded-full" style={{ width: "70%" }}></div>
                            </div>
                          </div>
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <span>Aventura</span>
                              <span className="text-sm text-dark-100">60%</span>
                            </div>
                            <div className="h-2 bg-dark-500 rounded-full">
                              <div className="h-full bg-secondary rounded-full" style={{ width: "60%" }}></div>
                            </div>
                          </div>
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <span>Fantasia</span>
                              <span className="text-sm text-dark-100">45%</span>
                            </div>
                            <div className="h-2 bg-dark-500 rounded-full">
                              <div className="h-full bg-accent rounded-full" style={{ width: "45%" }}></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-dark-600 rounded-lg p-6">
                        <h3 className="text-lg font-semibold mb-4">Tempo Assistido</h3>
                        <div className="text-center py-4">
                          <div className="text-3xl font-bold">
                            {Math.floor((history.length * 24) / 60)} horas
                          </div>
                          <div className="text-dark-100">{history.length} episódios</div>
                        </div>
                      </div>
                      
                      <div className="md:col-span-2 bg-dark-600 rounded-lg p-6">
                        <h3 className="text-lg font-semibold mb-4">Progresso</h3>
                        <div className="flex justify-between items-center mb-1">
                          <span>{user.animeWatched} animes assistidos</span>
                          <span className="text-sm text-dark-100">
                            {(user.animeWatched / (rankings[0]?.animeWatched || 1) * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div className="h-2 bg-dark-500 rounded-full">
                          <div 
                            className="h-full bg-gradient-to-r from-primary to-secondary rounded-full" 
                            style={{ width: `${user.animeWatched / (rankings[0]?.animeWatched || 1) * 100}%` }}
                          ></div>
                        </div>
                        <div className="text-sm text-dark-100 mt-1">
                          Recorde: {rankings[0]?.animeWatched || 0} animes por {rankings[0]?.name || ""}
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </div>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
