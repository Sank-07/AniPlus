import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Redirect } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

export default function MakeAdminPage() {
  const { toast } = useToast();
  const { user, isLoading } = useAuth();
  const [isPromoting, setIsPromoting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const promoteToAdmin = async () => {
    setIsPromoting(true);
    setError(null);

    try {
      const response = await fetch("/api/make-sankss-admin");
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erro ao promover usuário");
      }

      const data = await response.json();
      toast({
        title: "Sucesso!",
        description: data.message,
      });
      
      setIsSuccess(true);
    } catch (err: any) {
      setError(err.message || "Ocorreu um erro ao promover o usuário para administrador");
      toast({
        title: "Erro",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setIsPromoting(false);
    }
  };

  // Se o usuário não estiver logado ou não for o SankSS, redirecione
  if (!isLoading && (!user || (user.username !== "SankSS" && user.role !== "admin"))) {
    return <Redirect to="/" />;
  }

  // Se a promoção foi bem-sucedida, redirecione para a página de administração
  if (isSuccess) {
    return <Redirect to="/admin" />;
  }

  return (
    <div className="container py-10 max-w-md mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Promoção de Usuário</CardTitle>
          <CardDescription>
            Promova o usuário SankSS para administrador
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Esta é uma página especial para promover o usuário SankSS para administrador.
            Após a promoção, você terá acesso ao painel administrativo completo.
          </p>
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={promoteToAdmin} disabled={isPromoting}>
            {isPromoting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Promovendo...
              </>
            ) : (
              "Promover para Administrador"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}