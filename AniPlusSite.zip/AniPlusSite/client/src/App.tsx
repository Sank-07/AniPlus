import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute, AdminRoute } from "@/lib/protected-route";

import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import AnimeDetailsPage from "@/pages/anime-details-page";
import PlayerPage from "@/pages/player-page";
import ProfilePage from "@/pages/profile-page";
import FavoritesPage from "@/pages/favorites-page";
import HistoryPage from "@/pages/history-page";
import MakeAdminPage from "@/pages/make-admin-page";
import AnimesPage from "@/pages/animes-page";
import CalendarioPage from "@/pages/calendario-page";
import RankingsPage from "@/pages/rankings-page";

// Admin pages
import DashboardPage from "@/pages/admin/dashboard-page";
import AnimeManagementPage from "@/pages/admin/anime-management-page";
import SeasonsManagementPage from "@/pages/admin/seasons-management-page";
import EpisodesManagementPage from "@/pages/admin/episodes-management-page";
import UsersManagementPage from "@/pages/admin/users-management-page";
import CalendarManagementPage from "@/pages/admin/calendar-management-page";
import StatsPage from "@/pages/admin/stats-page";
import SettingsPage from "@/pages/admin/settings-page";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/animes" component={AnimesPage} />
      <Route path="/calendario" component={CalendarioPage} />
      <Route path="/rankings" component={RankingsPage} />
      <Route path="/anime/:id" component={AnimeDetailsPage} />
      <Route path="/player/:id" component={PlayerPage} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <ProtectedRoute path="/favorites" component={FavoritesPage} />
      <ProtectedRoute path="/history" component={HistoryPage} />
      <ProtectedRoute path="/make-admin" component={MakeAdminPage} />
      
      {/* Admin routes */}
      <AdminRoute path="/admin" component={DashboardPage} />
      <AdminRoute path="/admin/animes" component={AnimeManagementPage} />
      <AdminRoute path="/admin/seasons" component={SeasonsManagementPage} />
      <AdminRoute path="/admin/episodes" component={EpisodesManagementPage} />
      <AdminRoute path="/admin/users" component={UsersManagementPage} />
      <AdminRoute path="/admin/calendar" component={CalendarManagementPage} />
      <AdminRoute path="/admin/stats" component={StatsPage} />
      <AdminRoute path="/admin/settings" component={SettingsPage} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
