import { Link } from "wouter";
import { User } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface UserRankingsSectionProps {
  users: User[];
  isLoading: boolean;
}

export function UserRankingsSection({ users, isLoading }: UserRankingsSectionProps) {
  if (isLoading) {
    return (
      <section className="py-8 bg-dark-700">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-6 font-poppins">Ranking de Usuários</h2>
          
          <div className="bg-dark-600 rounded-lg overflow-hidden shadow-lg">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6">
              <div className="bg-gradient-to-br from-dark-400 to-dark-500 rounded-lg p-6 text-center col-span-1 md:col-span-3">
                <Skeleton className="w-24 h-24 rounded-full mx-auto" />
                <Skeleton className="h-6 w-48 mx-auto mt-3" />
                <Skeleton className="h-4 w-32 mx-auto mt-2" />
                <Skeleton className="h-4 w-56 mx-auto mt-2" />
              </div>
              
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-dark-500 rounded-lg p-4 flex items-center">
                  <Skeleton className="w-16 h-16 rounded-full" />
                  <div className="ml-4 flex-1">
                    <Skeleton className="h-5 w-2/3 mb-1" />
                    <Skeleton className="h-4 w-1/2 mb-1" />
                    <Skeleton className="h-4 w-1/3" />
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-4 text-center border-t border-dark-500">
              <Skeleton className="h-4 w-40 mx-auto" />
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (users.length === 0) {
    return null;
  }

  const topUser = users[0];
  const otherTopUsers = users.slice(1, 4);

  return (
    <section className="py-8 bg-dark-700">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-6 font-poppins">Ranking de Usuários</h2>
        
        <div className="bg-dark-600 rounded-lg overflow-hidden shadow-lg">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6">
            {/* Top User */}
            <div className="bg-gradient-to-br from-primary to-secondary rounded-lg p-6 text-center col-span-1 md:col-span-3">
              <div className="relative inline-block">
                <Avatar className="w-24 h-24 mx-auto border-4 border-white">
                  <AvatarImage src={topUser.avatar || ''} alt={topUser.name} />
                  <AvatarFallback className="bg-secondary text-white text-lg">
                    {topUser.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -top-2 -right-2 bg-yellow-500 text-dark-700 rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm">
                  1
                </div>
              </div>
              <h3 className="text-xl font-bold mt-3 text-white">{topUser.name}</h3>
              <p className="text-white opacity-80">Otaku Lendário</p>
              <div className="flex justify-center items-center mt-2">
                <span className="text-white font-bold">{topUser.animeWatched}</span>
                <span className="text-white ml-1">animes assistidos</span>
              </div>
            </div>
            
            {/* Other Top Users */}
            {otherTopUsers.map((user, index) => {
              const rankColors = [
                { border: "border-secondary", bg: "bg-gray-300", textBg: "text-dark-700" },
                { border: "border-accent", bg: "bg-amber-700", textBg: "text-white" },
                { border: "border-primary", bg: "bg-dark-400", textBg: "text-white" }
              ];
              
              const textColors = [
                "text-secondary",
                "text-accent",
                "text-primary"
              ];
              
              return (
                <div key={user.id} className="bg-dark-500 rounded-lg p-4 flex items-center">
                  <div className="relative">
                    <Avatar className={`w-16 h-16 border-2 ${rankColors[index].border}`}>
                      <AvatarImage src={user.avatar || ''} alt={user.name} />
                      <AvatarFallback className="bg-dark-600 text-white">
                        {user.name.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`absolute -top-1 -right-1 ${rankColors[index].bg} ${rankColors[index].textBg} rounded-full w-6 h-6 flex items-center justify-center font-bold text-xs`}>
                      {index + 2}
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="font-bold">{user.name}</h3>
                    <p className="text-dark-100 text-sm">
                      {index === 0 ? "Otaku Master" : index === 1 ? "Otaku Expert" : "Otaku Pro"}
                    </p>
                    <div className="flex items-center mt-1 text-sm">
                      <span className={`${textColors[index]} font-bold`}>{user.animeWatched}</span>
                      <span className="text-dark-100 ml-1">animes</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="p-4 text-center border-t border-dark-500">
            <Link href="/rankings" className="text-primary hover:underline">
              Ver ranking completo
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
