import { Link } from "wouter";
import { Play } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Episode, Season } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { EpisodeCard } from "@/components/anime/episode-card";
import { useQuery } from "@tanstack/react-query";

interface EpisodeWithAnimeTitle extends Episode {
  animeTitle: string;
}

interface RecentEpisodesSectionProps {
  episodes: EpisodeWithAnimeTitle[];
  isLoading: boolean;
}

export function RecentEpisodesSection({ episodes, isLoading }: RecentEpisodesSectionProps) {
  // Pré-carregar informações de temporada para todos os episódios que têm seasonId
  const seasonIds = episodes
    .filter(episode => episode.seasonId !== null)
    .map(episode => episode.seasonId);
  
  // Batch fetch das temporadas
  const { data: seasons = [] } = useQuery<Season[]>({
    queryKey: ['/api/seasons'],
    enabled: seasonIds.length > 0,
  });
  return (
    <section className="py-8 bg-dark-700">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold font-poppins">Episódios Recentes</h2>
          <Link href="/recent" className="text-primary hover:underline text-sm">Ver Tudo</Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {[...Array(5)].map((_, index) => (
              <div key={index} className="bg-dark-600 rounded-lg overflow-hidden shadow-lg">
                <Skeleton className="w-full h-40" />
                <div className="p-3">
                  <Skeleton className="h-5 w-3/4 mb-1" />
                  <Skeleton className="h-4 w-1/2 mb-2" />
                  <Skeleton className="h-4 w-full" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {episodes.map((episode) => {
              // Localizar a temporada para este episódio
              const seasonData = episode.seasonId 
                ? seasons.find(season => season.id === episode.seasonId) 
                : undefined;
              
              return (
                <EpisodeCard
                  key={episode.id}
                  episode={episode}
                  animeTitle={episode.animeTitle}
                  seasonData={seasonData}
                  className="h-full"
                />
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
