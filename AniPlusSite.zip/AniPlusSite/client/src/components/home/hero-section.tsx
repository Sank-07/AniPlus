import { Link } from "wouter";
import { Play, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Anime } from "@shared/schema";

interface HeroSectionProps {
  anime: Anime | null;
  isLoading: boolean;
}

export function HeroSection({ anime, isLoading }: HeroSectionProps) {
  if (isLoading || !anime) {
    return (
      <section className="relative h-[500px] bg-dark-700">
        <div className="absolute inset-0 bg-gradient-to-r from-dark-700 via-dark-700/90 to-transparent z-10"></div>
        <div className="container mx-auto px-4 relative z-20 h-full flex items-center">
          <div className="max-w-lg animate-pulse">
            <div className="bg-dark-600 h-8 w-32 rounded-full mb-4"></div>
            <div className="bg-dark-600 h-12 w-3/4 rounded mb-3"></div>
            <div className="bg-dark-600 h-4 w-full rounded mb-2"></div>
            <div className="bg-dark-600 h-4 w-5/6 rounded mb-6"></div>
            <div className="flex space-x-4">
              <div className="bg-dark-600 h-12 w-36 rounded-lg"></div>
              <div className="bg-dark-600 h-12 w-36 rounded-lg"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="relative h-[500px] bg-dark-700">
      <div className="absolute inset-0 bg-gradient-to-r from-dark-700 via-dark-700/90 to-transparent z-10"></div>
      <img 
        src={anime.bannerImage} 
        alt={anime.title} 
        className="absolute inset-0 w-full h-full object-cover object-center"
      />
      
      <div className="container mx-auto px-4 relative z-20 h-full flex items-center">
        <div className="max-w-lg">
          <span className="bg-primary text-white text-sm font-bold py-1 px-3 rounded-full">
            NOVO EPISÓDIO
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mt-4 font-poppins">{anime.title}</h1>
          <p className="text-lg mt-3 text-gray-200">{anime.synopsis}</p>
          <div className="flex mt-6 space-x-4">
            <Button 
              asChild
              className="bg-primary hover:bg-opacity-90 transition text-white px-6 py-3 rounded-lg font-bold flex items-center gap-2"
            >
              <Link href={`/anime/${anime.id}`}>
                <Play size={18} /> Assistir Agora
              </Link>
            </Button>
            <Button
              variant="outline"
              className="bg-dark-500 hover:bg-dark-400 transition text-white px-6 py-3 rounded-lg font-bold flex items-center gap-2 border-dark-400"
            >
              <Plus size={18} /> Minha Lista
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
