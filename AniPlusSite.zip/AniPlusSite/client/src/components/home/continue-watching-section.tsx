import { Link } from "wouter";
import { WatchHistory } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface WatchHistoryWithDetails extends WatchHistory {
  animeTitle: string;
  episodeTitle: string;
  seasonTitle?: string;
  thumbnail: string;
  duration: number;
}

interface ContinueWatchingSectionProps {
  continueWatching: WatchHistoryWithDetails[];
  isLoading: boolean;
}

export function ContinueWatchingSection({ continueWatching, isLoading }: ContinueWatchingSectionProps) {
  return (
    <section className="py-8 bg-dark-700">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold font-poppins">Continue Assistindo</h2>
          <Link href="/history" className="text-primary hover:underline text-sm">Ver Tudo</Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {[...Array(5)].map((_, index) => (
              <div key={index} className="bg-dark-600 rounded-lg overflow-hidden shadow-lg">
                <Skeleton className="w-full h-32" />
                <div className="p-3">
                  <Skeleton className="h-5 w-3/4 mb-1" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : continueWatching.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {continueWatching.map((item) => (
              <div key={item.id} className="anime-card bg-dark-600 rounded-lg overflow-hidden shadow-lg">
                <div className="relative">
                  <img 
                    src={item.thumbnail} 
                    alt={item.animeTitle} 
                    className="w-full h-32 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-700 to-transparent"></div>
                  <div className="absolute bottom-2 left-2 right-2">
                    <div className="flex justify-between items-center">
                      <span className="bg-primary text-white text-xs px-2 py-1 rounded">EP {item.episodeTitle}</span>
                      <span className="text-xs text-white">
                        {Math.floor(item.progress / 60)}:{(item.progress % 60).toString().padStart(2, '0')} / 
                        {Math.floor(item.duration / 60)}:{(item.duration % 60).toString().padStart(2, '0')}
                      </span>
                    </div>
                    <div className="mt-1 bg-dark-400 h-1 w-full rounded-full overflow-hidden">
                      <div className="bg-primary h-full rounded-full" style={{ width: `${(item.progress / item.duration) * 100}%` }}></div>
                    </div>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-white truncate">{item.animeTitle}</h3>
                  <p className="text-dark-100 text-sm">{item.seasonTitle || 'Temporada 1'}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-dark-600 rounded-lg p-8 text-center">
            <p className="text-dark-100">Você ainda não começou a assistir nenhum anime.</p>
            <Link href="/" className="mt-4 inline-block bg-primary text-white px-4 py-2 rounded-md hover:bg-opacity-90 transition">
              Explorar animes
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}
