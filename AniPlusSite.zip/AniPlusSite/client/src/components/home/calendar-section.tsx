import { useState } from "react";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

interface CalendarEntry extends Calendar {
  animeCoverImage: string;
}

interface CalendarSectionProps {
  calendar: CalendarEntry[];
  isLoading: boolean;
}

type WeekDayKey = 'seg' | 'ter' | 'qua' | 'qui' | 'sex' | 'sab' | 'dom';
const weekDays: { key: WeekDayKey; label: string }[] = [
  { key: 'seg', label: 'Seg' },
  { key: 'ter', label: 'Ter' },
  { key: 'qua', label: 'Qua' },
  { key: 'qui', label: 'Qui' },
  { key: 'sex', label: 'Sex' },
  { key: 'sab', label: 'Sáb' },
  { key: 'dom', label: 'Dom' }
];

export function CalendarSection({ calendar, isLoading }: CalendarSectionProps) {
  const [activeTab, setActiveTab] = useState<WeekDayKey>('seg');
  const { toast } = useToast();

  const handleReminder = (title: string) => {
    toast({
      title: "Lembrete definido",
      description: `Você será notificado quando ${title} estiver disponível.`
    });
  };

  return (
    <section className="py-8 bg-dark-600">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-6 font-poppins">Calendário de Lançamentos</h2>
        
        <div className="grid grid-cols-7 gap-2 mb-4">
          {weekDays.map((day) => (
            <button
              key={day.key}
              onClick={() => setActiveTab(day.key)}
              className={`${
                activeTab === day.key
                  ? 'bg-primary text-white'
                  : 'bg-dark-500 text-dark-100'
              } p-2 rounded text-center font-medium transition-colors`}
            >
              {day.label}
            </button>
          ))}
        </div>
        
        <div className="bg-dark-500 rounded-lg p-4">
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex items-center space-x-4 p-3 bg-dark-600 rounded-lg">
                  <Skeleton className="w-16 h-6" />
                  <Skeleton className="w-12 h-12 rounded" />
                  <div className="flex-1">
                    <Skeleton className="h-5 w-2/3 mb-1" />
                    <Skeleton className="h-4 w-1/3" />
                  </div>
                  <Skeleton className="w-24 h-8 rounded" />
                </div>
              ))}
            </div>
          ) : (
            <>
              {weekDays.map((day) => {
                const dayEntries = calendar.filter(entry => entry.releaseDay === day.key);
                
                return (
                  <div
                    key={day.key}
                    data-tab-content={day.key}
                    className={`space-y-4 ${activeTab === day.key ? '' : 'hidden'}`}
                  >
                    {dayEntries.length > 0 ? (
                      dayEntries.map((entry) => (
                        <div key={entry.id} className="flex items-center space-x-4 p-3 bg-dark-600 rounded-lg hover:bg-dark-400 transition">
                          <p className="text-primary font-bold w-16 text-center">{entry.releaseTime}</p>
                          <img src={entry.animeCoverImage} alt={entry.title} className="w-12 h-12 rounded object-cover" />
                          <div className="flex-1">
                            <h3 className="font-bold">{entry.title}</h3>
                            <p className="text-sm text-dark-100">{entry.description}</p>
                          </div>
                          <Button
                            onClick={() => handleReminder(entry.title)}
                            className="bg-primary hover:bg-opacity-80 transition text-white px-3 py-1.5 rounded text-sm font-medium"
                          >
                            <Bell size={16} className="mr-1" /> Lembrar
                          </Button>
                        </div>
                      ))
                    ) : (
                      <div className="p-4 text-center text-dark-100">
                        Nenhum lançamento programado para hoje.
                      </div>
                    )}
                  </div>
                );
              })}
            </>
          )}
        </div>
      </div>
    </section>
  );
}
