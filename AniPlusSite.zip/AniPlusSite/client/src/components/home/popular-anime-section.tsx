import { Link } from "wouter";
import { Anime } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface PopularAnimeSectionProps {
  animes: Anime[];
  isLoading: boolean;
}

export function PopularAnimeSection({ animes, isLoading }: PopularAnimeSectionProps) {
  return (
    <section className="py-8 bg-dark-600">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold font-poppins">Animes Populares</h2>
          <Link href="/animes" className="text-primary hover:underline text-sm">Ver Tudo</Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="rounded-lg overflow-hidden shadow-lg">
                <Skeleton className="w-full h-64" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
            {animes.map((anime) => (
              <Link key={anime.id} href={`/anime/${anime.id}`}>
                <div className="anime-card rounded-lg overflow-hidden shadow-lg cursor-pointer">
                  <div className="relative">
                    <img 
                      src={anime.coverImage} 
                      alt={anime.title}
                      className="w-full h-64 object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-dark-700 via-transparent to-transparent"></div>
                    <div className="absolute bottom-0 left-0 right-0 p-3">
                      <h3 className="font-bold text-white text-center">{anime.title}</h3>
                    </div>
                    <div className="absolute top-2 right-2 flex gap-1">
                      <div className="bg-primary text-white text-xs font-bold px-2 py-1 rounded">
                        {anime.rating.toFixed(1)}
                      </div>
                      <div className="bg-dark-500 text-white text-xs capitalize px-2 py-1 rounded">
                        {anime.audioLanguage === "dublado" ? "Dub" : "Leg"}
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
