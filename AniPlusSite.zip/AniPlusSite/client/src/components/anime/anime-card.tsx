import { Link } from "wouter";
import { Anime, Season } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Layers } from "lucide-react";

interface AnimeCardProps {
  anime: Anime;
  className?: string;
}

export function AnimeCard({ anime, className }: AnimeCardProps) {
  // Buscar temporadas para este anime
  const { data: seasons = [] } = useQuery<Season[]>({
    queryKey: [`/api/animes/${anime.id}/seasons`],
    enabled: !!anime.id,
  });

  const seasonsCount = seasons.length;
  
  return (
    <Link href={`/anime/${anime.id}`}>
      <div className={`anime-card rounded-lg overflow-hidden shadow-lg cursor-pointer ${className}`}>
        <div className="relative">
          <img 
            src={anime.coverImage} 
            alt={anime.title}
            className="w-full h-64 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark-800 via-transparent to-dark-800/30"></div>
          
          <div className="absolute top-2 right-2 flex gap-1">
            <Badge className="bg-primary text-white text-xs font-bold">
              {anime.rating.toFixed(1)}
            </Badge>
            <Badge className="bg-dark-500 text-white text-xs capitalize">
              {anime.audioLanguage === "dublado" ? "Dub" : "Leg"}
            </Badge>
          </div>
          
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {anime.status === "Em andamento" && (
              <Badge variant="outline" className="bg-accent/80 text-white border-0">
                Em exibição
              </Badge>
            )}
            
            {/* Badge para número de temporadas */}
            <Badge 
              variant="outline" 
              className="bg-dark-800/90 text-white border-dark-500 flex items-center gap-1"
            >
              <Layers size={12} />
              {seasonsCount > 0 ? `${seasonsCount} temp.` : "Sem temp."}
            </Badge>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 p-3">
            <h3 className="font-bold text-white text-center truncate">{anime.title}</h3>
            <div className="flex justify-center flex-wrap gap-1 mt-1">
              {anime.genres.slice(0, 3).map((genre, index) => (
                <span key={index} className="text-xs bg-dark-500 text-dark-100 px-2 py-0.5 rounded">
                  {genre}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
