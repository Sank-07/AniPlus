import { Link } from "wouter";
import { Play, Layers } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Episode, Season } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";

interface EpisodeCardProps {
  episode: Episode;
  animeTitle: string;
  className?: string;
  seasonData?: Season; // Opcional: passe a temporada diretamente se já a tiver
}

export function EpisodeCard({ episode, animeTitle, className, seasonData }: EpisodeCardProps) {
  const isNew = new Date(episode.releaseDate).getTime() > Date.now() - 24 * 60 * 60 * 1000;
  
  // Buscar temporada se não foi fornecida diretamente
  const { data: season } = useQuery<Season>({
    queryKey: [`/api/seasons/${episode.seasonId}`],
    enabled: !!episode.seasonId && !seasonData,
  });
  
  // Usar a temporada fornecida ou a buscada via query
  const activeSeason = seasonData || season;
  
  return (
    <div className={`anime-card bg-dark-600 rounded-lg overflow-hidden shadow-lg ${className}`}>
      <div className="relative">
        <img 
          src={episode.thumbnail}
          alt={`${animeTitle} - Episódio ${episode.number}`}
          className="w-full h-40 object-cover"
        />
        {/* Sobreposição gradiente para melhorar legibilidade das badges */}
        <div className="absolute inset-0 bg-gradient-to-t from-dark-800 via-transparent to-dark-800/30"></div>
        
        {/* Container para badges no topo */}
        <div className="absolute top-2 right-2 flex gap-1">
          {isNew && (
            <Badge className="bg-primary text-white text-xs font-bold">
              NOVO
            </Badge>
          )}
        </div>
        
        {/* Badge de temporada - agora no canto superior esquerdo */}
        {episode.seasonId && (
          <div className="absolute top-2 left-2 z-10">
            <Badge 
              className="bg-dark-800/90 text-white flex items-center gap-1 border-dark-500"
              variant="outline"
            >
              <Layers size={12} />
              {activeSeason ? `Temp. ${activeSeason.number}` : "Temporada"}
            </Badge>
          </div>
        )}
        
        {/* Badge de número do episódio - agora no canto inferior esquerdo */}
        <div className="absolute bottom-2 left-2 z-10">
          <Badge className="bg-dark-800/90 text-white">
            EP {episode.number}
          </Badge>
        </div>
        
        {/* Badge de duração - canto inferior direito */}
        <div className="absolute bottom-2 right-2 z-10">
          <Badge className="bg-dark-800/90 text-white text-xs">
            {Math.floor(episode.duration / 60)} min
          </Badge>
        </div>
        
        <Link href={`/player/${episode.id}`}>
          <button className="absolute inset-0 m-auto w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white hover:bg-opacity-80 transition transform hover:scale-110 z-10">
            <Play size={22} className="ml-1" />
          </button>
        </Link>
      </div>
      <div className="p-3">
        <h3 className="font-bold text-white truncate">{animeTitle}</h3>
        <p className="text-dark-100 text-sm truncate">{episode.title || `Episódio ${episode.number}`}</p>
        <div className="flex items-center mt-2 text-xs text-dark-100">
          <span className="bg-dark-500 px-2 py-0.5 rounded">HD</span>
          <span className="ml-2 truncate">
            {formatDistanceToNow(new Date(episode.releaseDate), { locale: ptBR, addSuffix: true })}
          </span>
        </div>
      </div>
    </div>
  );
}
