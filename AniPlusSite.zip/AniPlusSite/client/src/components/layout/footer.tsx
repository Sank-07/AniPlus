import { Link } from "wouter";
import { FacebookIcon, TwitterIcon, InstagramIcon, MessageCircleIcon } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-dark-600 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div>
            <Link href="/" className="flex items-center">
              <span className="text-primary text-3xl font-bold font-montserrat">Ani<span className="text-accent">Plus</span></span>
            </Link>
            <p className="mt-4 text-dark-100">Seu portal de animes completo com os melhores títulos e episódios mais recentes do mundo dos animes.</p>
            <div className="flex mt-6 space-x-4">
              <a href="#" className="text-dark-100 hover:text-primary transition">
                <FacebookIcon size={20} />
              </a>
              <a href="#" className="text-dark-100 hover:text-primary transition">
                <TwitterIcon size={20} />
              </a>
              <a href="#" className="text-dark-100 hover:text-primary transition">
                <InstagramIcon size={20} />
              </a>
              <a href="#" className="text-dark-100 hover:text-primary transition">
                <MessageCircleIcon size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4 text-lg">Navegação</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-dark-100 hover:text-primary transition">Início</Link></li>
              <li><Link href="/animes" className="text-dark-100 hover:text-primary transition">Animes</Link></li>
              <li><Link href="/calendario" className="text-dark-100 hover:text-primary transition">Calendário</Link></li>
              <li><Link href="/rankings" className="text-dark-100 hover:text-primary transition">Ranking</Link></li>
              <li><Link href="/novidades" className="text-dark-100 hover:text-primary transition">Novidades</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4 text-lg">Gêneros</h3>
            <ul className="space-y-2">
              <li><Link href="/generos/acao" className="text-dark-100 hover:text-primary transition">Ação</Link></li>
              <li><Link href="/generos/aventura" className="text-dark-100 hover:text-primary transition">Aventura</Link></li>
              <li><Link href="/generos/comedia" className="text-dark-100 hover:text-primary transition">Comédia</Link></li>
              <li><Link href="/generos/drama" className="text-dark-100 hover:text-primary transition">Drama</Link></li>
              <li><Link href="/generos/romance" className="text-dark-100 hover:text-primary transition">Romance</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4 text-lg">Suporte</h3>
            <ul className="space-y-2">
              <li><Link href="/faq" className="text-dark-100 hover:text-primary transition">FAQ</Link></li>
              <li><Link href="/contato" className="text-dark-100 hover:text-primary transition">Contato</Link></li>
              <li><Link href="/termos" className="text-dark-100 hover:text-primary transition">Termos de Uso</Link></li>
              <li><Link href="/privacidade" className="text-dark-100 hover:text-primary transition">Política de Privacidade</Link></li>
              <li><Link href="/dmca" className="text-dark-100 hover:text-primary transition">DMCA</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-dark-500 pt-6 text-center text-dark-100 text-sm">
          <p>&copy; {new Date().getFullYear()} AniPlus. Todos os direitos reservados.</p>
          <p className="mt-2">AniPlus não armazena nenhum vídeo em seus servidores. Todo o conteúdo é fornecido por terceiros não afiliados.</p>
        </div>
      </div>
    </footer>
  );
}
