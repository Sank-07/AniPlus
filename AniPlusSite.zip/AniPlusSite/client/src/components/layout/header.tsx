import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  User, Search, Menu, ChevronDown, 
  LogOut, History, BookmarkCheck, User2
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Header() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const menuItems = [
    { label: "Início", path: "/" },
    { label: "Animes", path: "/animes" },
    { label: "Calendário", path: "/calendario" },
    { label: "Ranking", path: "/rankings" }
  ];

  return (
    <header className="bg-dark-600 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-3">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-primary text-3xl font-bold font-montserrat">Ani<span className="text-accent">Plus</span></span>
            </Link>
          </div>

          {/* Search Bar */}
          <div className="hidden md:flex flex-1 px-8 max-w-xl">
            <div className="relative w-full">
              <Input
                type="search"
                placeholder="Pesquisar anime..."
                className="w-full bg-dark-500 border border-dark-400 rounded-full py-2 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button className="absolute right-3 top-2 text-dark-100">
                <Search size={18} />
              </button>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {menuItems.map((item) => (
              <Link 
                key={item.path} 
                href={item.path}
                className={`text-white hover:text-primary transition duration-200 font-medium ${location === item.path ? 'text-primary' : ''}`}>
                {item.label}
              </Link>
            ))}
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center space-x-2 text-white hover:text-primary transition">
                    <Avatar className="w-8 h-8 border-2 border-primary">
                      <AvatarImage src={user.avatar || ''} alt={user.name} />
                      <AvatarFallback className="bg-primary text-white">
                        {user.name.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{user.name.split(' ')[0]}</span>
                    <ChevronDown size={16} />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-dark-600 border-dark-500 text-white">
                  <DropdownMenuItem className="hover:bg-dark-500 cursor-pointer" asChild>
                    <Link href="/profile" className="flex items-center gap-2">
                      <User2 size={16} />
                      <span>Meu Perfil</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="hover:bg-dark-500 cursor-pointer" asChild>
                    <Link href="/favorites" className="flex items-center gap-2">
                      <BookmarkCheck size={16} />
                      <span>Favoritos</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="hover:bg-dark-500 cursor-pointer" asChild>
                    <Link href="/history" className="flex items-center gap-2">
                      <History size={16} />
                      <span>Histórico</span>
                    </Link>
                  </DropdownMenuItem>
                  {user.role === 'admin' && (
                    <>
                      <DropdownMenuSeparator className="bg-dark-400" />
                      <DropdownMenuItem className="hover:bg-dark-500 cursor-pointer" asChild>
                        <Link href="/admin" className="flex items-center gap-2">
                          <User size={16} />
                          <span>Painel Admin</span>
                        </Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator className="bg-dark-400" />
                  <DropdownMenuItem 
                    onClick={handleLogout}
                    className="text-red-400 hover:bg-dark-500 cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <LogOut size={16} />
                      <span>Sair</span>
                    </div>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth">
                <Button className="bg-primary text-white hover:bg-opacity-90 transition">
                  Entrar
                </Button>
              </Link>
            )}
          </nav>

          {/* Mobile menu button */}
          <button 
            className="md:hidden text-white text-2xl"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu />
          </button>
        </div>
      </div>

      {/* Mobile Search (Shows on smaller screens) */}
      <div className="px-4 pb-3 md:hidden">
        <div className="relative">
          <Input
            type="search"
            placeholder="Pesquisar anime..."
            className="w-full bg-dark-500 border border-dark-400 rounded-full py-2 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <button className="absolute right-3 top-2 text-dark-100">
            <Search size={18} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-dark-600 pb-4 px-4">
          <nav className="flex flex-col space-y-3">
            {menuItems.map((item) => (
              <Link 
                key={item.path} 
                href={item.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`text-white py-2 hover:text-primary ${location === item.path ? 'text-primary' : ''}`}>
                {item.label}
              </Link>
            ))}
            {user && (
              <>
                <Link 
                  href="/profile" 
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-white py-2 hover:text-primary">
                  Meu Perfil
                </Link>
                <Link 
                  href="/favorites" 
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-white py-2 hover:text-primary">
                  Favoritos
                </Link>
                <Link 
                  href="/history" 
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-white py-2 hover:text-primary">
                  Histórico
                </Link>
                {user.role === 'admin' && (
                  <Link 
                    href="/admin" 
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-white py-2 hover:text-primary">
                    Painel Admin
                  </Link>
                )}
                <button 
                  onClick={() => {
                    handleLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="text-red-400 py-2 text-left hover:text-red-500"
                >
                  Sair
                </button>
              </>
            )}
            {!user && (
              <Link 
                href="/auth"
                onClick={() => setMobileMenuOpen(false)}
                className="bg-primary text-white py-2 px-4 rounded-md text-center font-medium hover:bg-opacity-90">
                Entrar
              </Link>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
