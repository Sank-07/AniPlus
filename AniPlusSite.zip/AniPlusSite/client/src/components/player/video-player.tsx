import { useState, useRef, useEffect } from "react";
import { 
  Play, Pause, Volume2, VolumeX, Settings, 
  Maximize, Minimize, SkipForward, SkipBack, X, Check
} from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface VideoQualityOptions {
  [key: string]: string; // mapeamento de qualidade para URL, ex: { "720p": "url720p", "480p": "url480p" }
}

interface VideoPlayerProps {
  episodeId: number;
  animeId: number;
  videoUrl: string;
  title: string;
  savedProgress?: number;
  duration: number;
  onClose?: () => void;
  // URLs opcionais para diferentes qualidades
  qualityOptions?: VideoQualityOptions;
}

export function VideoPlayer({ 
  episodeId, 
  animeId, 
  videoUrl, 
  title, 
  savedProgress = 0, 
  duration,
  onClose,
  qualityOptions = {}
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(savedProgress);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [showQualitySelector, setShowQualitySelector] = useState(false);
  const [currentQuality, setCurrentQuality] = useState("720p");
  const [videoSource, setVideoSource] = useState(videoUrl);

  const videoRef = useRef<HTMLVideoElement>(null);
  const playerRef = useRef<HTMLDivElement>(null);
  const controlsTimerRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT') return;
      
      switch(e.key) {
        case ' ':
        case 'k':
          togglePlay();
          e.preventDefault();
          break;
        case 'f':
          toggleFullscreen();
          e.preventDefault();
          break;
        case 'm':
          toggleMute();
          e.preventDefault();
          break;
        case 'ArrowRight':
          seek(10);
          e.preventDefault();
          break;
        case 'ArrowLeft':
          seek(-10);
          e.preventDefault();
          break;
        case 'ArrowUp':
          changeVolume(0.1);
          e.preventDefault();
          break;
        case 'ArrowDown':
          changeVolume(-0.1);
          e.preventDefault();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    // Save progress every 5 seconds
    const saveInterval = setInterval(() => {
      if (isPlaying && currentTime > 0) {
        saveProgress();
      }
    }, 5000);

    return () => clearInterval(saveInterval);
  }, [isPlaying, currentTime]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = volume;
      videoRef.current.muted = isMuted;
    }
  }, [volume, isMuted]);

  useEffect(() => {
    if (videoRef.current && savedProgress > 0 && !isPlaying) {
      videoRef.current.currentTime = savedProgress;
      setCurrentTime(savedProgress);
    }
  }, [savedProgress]);
  
  // Inicializar a qualidade padrão com base nas opções disponíveis
  useEffect(() => {
    if (Object.keys(qualityOptions).length > 0) {
      // Define a qualidade padrão como 720p se disponível, ou usa a primeira disponível
      const defaultQuality = qualityOptions["720p"] ? "720p" : Object.keys(qualityOptions)[0];
      setCurrentQuality(defaultQuality);
      setVideoSource(qualityOptions[defaultQuality] || videoUrl);
    }
  }, [qualityOptions, videoUrl]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const seek = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime += seconds;
    }
  };

  const changeVolume = (delta: number) => {
    setVolume(prev => {
      const newVolume = Math.max(0, Math.min(1, prev + delta));
      if (newVolume === 0) {
        setIsMuted(true);
      } else if (isMuted) {
        setIsMuted(false);
      }
      return newVolume;
    });
  };

  const toggleMute = () => {
    setIsMuted(prev => !prev);
  };

  const toggleFullscreen = () => {
    if (!playerRef.current) return;

    if (!document.fullscreenElement) {
      playerRef.current.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(err => {
        toast({
          title: "Erro no modo tela cheia",
          description: `${err.message}. Tente outro navegador.`,
          variant: "destructive"
        });
      });
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleProgress = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleTimeUpdate = (value: number[]) => {
    if (videoRef.current) {
      videoRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const saveProgress = async () => {
    try {
      await apiRequest("POST", "/api/user/history", {
        animeId,
        episodeId,
        progress: Math.floor(currentTime),
        completed: currentTime >= duration * 0.9
      });
    } catch (error) {
      console.error("Failed to save progress:", error);
    }
  };

  const handleMouseMove = () => {
    setShowControls(true);
    
    if (controlsTimerRef.current) {
      clearTimeout(controlsTimerRef.current);
    }
    
    controlsTimerRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 3000);
  };
  
  const handleVideoEnd = () => {
    setIsPlaying(false);
    saveProgress();
    toast({
      title: "Episódio concluído",
      description: "Este episódio foi marcado como assistido."
    });
  };

  const handleLoadStart = () => {
    setIsLoading(true);
  };

  const handleCanPlay = () => {
    setIsLoading(false);
  };

  const handleQualityChange = (quality: string) => {
    // Guarda a posição atual do vídeo
    const currentPosition = videoRef.current?.currentTime || 0;
    const wasPlaying = isPlaying;
    
    setCurrentQuality(quality);
    setShowQualitySelector(false);
    
    // Seleciona a URL da qualidade escolhida ou mantém a URL original
    const newUrl = qualityOptions[quality] || videoUrl;
    setVideoSource(newUrl);
    
    // Adiciona um callback para quando o vídeo estiver pronto após a troca de URL
    const handleVideoReady = () => {
      // Restaura a posição do vídeo
      if (videoRef.current) {
        videoRef.current.currentTime = currentPosition;
        
        // Retoma a reprodução se estava tocando antes
        if (wasPlaying) {
          videoRef.current.play()
            .catch(error => console.error("Erro ao retomar reprodução:", error));
        }
      }
      
      // Remove o listener após uso
      videoRef.current?.removeEventListener('canplay', handleVideoReady);
    };
    
    // Adiciona o listener para quando o vídeo puder ser reproduzido
    videoRef.current?.addEventListener('canplay', handleVideoReady);
    
    toast({
      title: `Qualidade alterada para ${quality}`,
      description: "A reprodução continuará na nova qualidade."
    });
  };

  return (
    <div 
      ref={playerRef}
      className="relative bg-black w-full h-full min-h-[300px] flex items-center justify-center overflow-hidden"
      onMouseMove={handleMouseMove}
    >
      {showQualitySelector ? (
        <div className="bg-dark-600 p-6 rounded-lg max-w-xs w-full z-10">
          <h3 className="text-xl font-bold mb-4 text-white">Qualidade do Vídeo</h3>
          <div className="space-y-2">
            {/* Mostra apenas qualidades que têm URLs configuradas,
                ordenadas da mais alta para a mais baixa */}
            {Object.keys(qualityOptions).sort((a, b) => {
                // Extrair o número da qualidade (1080 de "1080p")
                const getNumber = (q: string) => parseInt(q.replace(/[^0-9]/g, ''));
                // Ordenar do maior para o menor
                return getNumber(b) - getNumber(a);
              }).map(quality => (
              <div 
                key={quality}
                onClick={() => handleQualityChange(quality)}
                className={`flex items-center justify-between p-3 rounded-md cursor-pointer ${
                  currentQuality === quality 
                    ? 'bg-primary text-white' 
                    : 'bg-dark-500 text-white hover:bg-dark-400'
                }`}
              >
                <span>{quality}</span>
                {currentQuality === quality && <Check size={16} />}
              </div>
            ))}
            <div className="flex justify-end pt-2">
              <button 
                onClick={() => setShowQualitySelector(false)}
                className="px-4 py-2 bg-dark-500 text-white rounded-md hover:bg-dark-400"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      ) : (
        <>
          <video
            ref={videoRef}
            src={videoSource}
            className="w-full h-full"
            onClick={togglePlay}
            onTimeUpdate={handleProgress}
            onEnded={handleVideoEnd}
            onLoadStart={handleLoadStart}
            onCanPlay={handleCanPlay}
          />

          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-60">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          )}

          {showControls && (
            <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col justify-between p-4">
              {/* Top bar */}
              <div className="flex justify-between items-center">
                <h3 className="text-white font-medium">{title}</h3>
                {onClose && (
                  <button 
                    onClick={onClose}
                    className="text-white hover:text-primary"
                  >
                    <X size={24} />
                  </button>
                )}
              </div>
              
              {/* Center play button */}
              <div className="flex-1 flex items-center justify-center">
                <button 
                  onClick={togglePlay}
                  className="bg-primary bg-opacity-80 rounded-full p-5 hover:bg-opacity-100 transition transform hover:scale-110"
                >
                  {isPlaying ? (
                    <Pause size={32} className="text-white" />
                  ) : (
                    <Play size={32} className="text-white ml-1" />
                  )}
                </button>
              </div>
              
              {/* Controls bar */}
              <div className="space-y-2">
                <Slider
                  value={[currentTime]}
                  min={0}
                  max={duration || 1}
                  step={1}
                  onValueChange={handleTimeUpdate}
                  className="cursor-pointer"
                />
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <button onClick={togglePlay} className="text-white hover:text-primary">
                      {isPlaying ? <Pause size={20} /> : <Play size={20} />}
                    </button>
                    
                    <button onClick={() => seek(-10)} className="text-white hover:text-primary">
                      <SkipBack size={20} />
                    </button>
                    
                    <button onClick={() => seek(10)} className="text-white hover:text-primary">
                      <SkipForward size={20} />
                    </button>
                    
                    <div className="flex items-center space-x-2 group relative">
                      <button onClick={toggleMute} className="text-white hover:text-primary">
                        {isMuted || volume === 0 ? <VolumeX size={20} /> : <Volume2 size={20} />}
                      </button>
                      
                      <div className="hidden group-hover:block absolute bottom-full left-0 mb-2 w-24 bg-dark-600 p-2 rounded">
                        <Slider
                          value={[isMuted ? 0 : volume * 100]}
                          min={0}
                          max={100}
                          step={1}
                          onValueChange={(value) => {
                            const newVolume = value[0] / 100;
                            setVolume(newVolume);
                            if (newVolume > 0) setIsMuted(false);
                            else setIsMuted(true);
                          }}
                          className="cursor-pointer"
                        />
                      </div>
                      
                      <span className="text-white text-sm">
                        {formatTime(currentTime)} / {formatTime(duration)}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <button 
                      onClick={() => setShowQualitySelector(true)}
                      className="text-white hover:text-primary"
                    >
                      <Settings size={20} />
                    </button>
                    
                    <button onClick={toggleFullscreen} className="text-white hover:text-primary">
                      {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
