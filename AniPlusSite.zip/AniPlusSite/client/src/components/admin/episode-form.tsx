import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Episode, InsertEpisode, insertEpisodeSchema, Anime, Season } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

// Extend the schema to include validation
const extendedEpisodeSchema = insertEpisodeSchema.extend({
  title: z.string().min(1, "O título é obrigatório"),
  number: z.number().min(1, "O número do episódio deve ser maior que 0"),
  thumbnail: z.string().url("A URL da thumbnail deve ser válida"),
  videoUrl: z.string().min(1, "A URL do vídeo é obrigatória").url("A URL do vídeo deve ser válida"),
  videoUrl1080p: z.union([z.string().url("A URL do vídeo 1080p deve ser válida"), z.string().length(0)]).optional(),
  videoUrl480p: z.union([z.string().url("A URL do vídeo 480p deve ser válida"), z.string().length(0)]).optional(),
  videoUrl360p: z.union([z.string().url("A URL do vídeo 360p deve ser válida"), z.string().length(0)]).optional(),
  duration: z.number().min(1, "A duração deve ser maior que 0"),
  // Aceitamos string para releaseDate no formulário, convertemos para ISO string antes de enviar
  releaseDate: z.string().refine((date) => !isNaN(Date.parse(date)), {
    message: "Data de lançamento inválida",
  }),
});

type EpisodeFormValues = z.infer<typeof extendedEpisodeSchema>;

interface EpisodeFormProps {
  episode?: Episode;
  animeId?: number;
  onSuccess?: () => void;
}

export function EpisodeForm({ episode, animeId, onSuccess }: EpisodeFormProps) {
  const { toast } = useToast();
  const [localSelectedAnimeId, setLocalSelectedAnimeId] = useState<number | undefined>(episode?.animeId || animeId);
  const [localSeasons, setLocalSeasons] = useState<Season[]>([]);

  // Fetch animes for the dropdown
  const { data: animes } = useQuery<Anime[]>({ 
    queryKey: ["/api/animes"]
  });

  // Conditionally fetch seasons based on the selected anime
  const selectedAnimeId = localSelectedAnimeId;
  const { data: seasons } = useQuery<Season[]>({
    queryKey: ["/api/animes", selectedAnimeId, "seasons"],
    enabled: !!selectedAnimeId,
  });
  
  // Buscar temporadas manualmente também ao inicializar (isso garante que funcione em modo de edição)
  useEffect(() => {
    if (selectedAnimeId) {
      console.log(`Buscando temporadas para o anime ${selectedAnimeId} (${episode ? 'modo edição' : 'modo criação'})`);
      apiRequest("GET", `/api/animes/${selectedAnimeId}/seasons`)
        .then(res => res.json())
        .then(data => {
          console.log(`Temporadas carregadas para anime ${selectedAnimeId}:`, data);
          console.log(`Total de temporadas encontradas: ${data.length}`);
          setLocalSeasons(data);
          
          // Se estamos editando um episódio, vamos verificar se a temporada dele está na lista
          if (episode && episode.seasonId) {
            const seasonFound = data.find((s: Season) => s.id === episode.seasonId);
            console.log(`Temporada do episódio (ID: ${episode.seasonId}) ${seasonFound ? 'encontrada' : 'NÃO encontrada'} na lista de temporadas`);
          }
        })
        .catch(error => {
          console.error("Erro ao carregar temporadas:", error);
        });
    }
  }, [selectedAnimeId, episode]);
  
  // Atualizar localSeasons quando seasons mudar através do React Query
  useEffect(() => {
    if (seasons) {
      setLocalSeasons(seasons);
    }
  }, [seasons]);

  const defaultReleaseDate = episode?.releaseDate
    ? format(new Date(episode.releaseDate), "yyyy-MM-dd'T'HH:mm")
    : format(new Date(), "yyyy-MM-dd'T'HH:mm");

  const defaultValues: Partial<EpisodeFormValues> = {
    animeId: selectedAnimeId || 0,
    seasonId: episode?.seasonId || 0,
    title: "",
    number: 1,
    thumbnail: "",
    videoUrl: "",
    videoUrl1080p: "",
    videoUrl480p: "",
    videoUrl360p: "",
    duration: 1440, // 24 minutes in seconds
    releaseDate: defaultReleaseDate,
  };
  
  // Para debugging
  console.log("Episode data from server:", episode);
  console.log(`Modo: ${episode ? 'Editando episódio existente' : 'Criando novo episódio'}`);
  console.log(`AnimeId selecionado: ${selectedAnimeId}`);
  
  const form = useForm<EpisodeFormValues>({
    resolver: zodResolver(extendedEpisodeSchema),
    defaultValues: episode 
      ? { 
          ...episode, 
          seasonId: episode.seasonId || 0, // Garantir que seasonId seja 0 quando null
          releaseDate: episode.releaseDate
            ? format(new Date(episode.releaseDate), "yyyy-MM-dd'T'HH:mm")
            : defaultReleaseDate,
          // Garantir que videoUrl seja definido corretamente
          videoUrl: episode.videoUrl || "" 
        } 
      : defaultValues,
  });
  
  // Para debugging
  console.log("Form default values:", form.getValues());
  

  useEffect(() => {
    if (episode) {
      form.reset({ 
        ...episode, 
        seasonId: episode.seasonId || 0, // Garantir que seasonId seja 0 quando null
        videoUrl: episode.videoUrl || "", // Garantir que videoUrl esteja preenchido
        videoUrl1080p: episode.videoUrl1080p || "",
        videoUrl480p: episode.videoUrl480p || "",
        videoUrl360p: episode.videoUrl360p || "",
        releaseDate: format(new Date(episode.releaseDate), "yyyy-MM-dd'T'HH:mm")
      });
      console.log("Reset form with episode data:", form.getValues());
    } else if (selectedAnimeId) {
      form.setValue("animeId", selectedAnimeId);
    }
  }, [episode, form, selectedAnimeId]);

  // Handle anime selection change
  const onAnimeChange = (animeId: number) => {
    form.setValue("animeId", animeId);
    form.setValue("seasonId", 0); // Reset season when anime changes
    
    // Carregar temporadas para o anime selecionado
    if (animeId) {
      setLocalSelectedAnimeId(animeId);
      apiRequest("GET", `/api/animes/${animeId}/seasons`)
        .then(res => res.json())
        .then(data => {
          console.log("Temporadas carregadas:", data);
          setLocalSeasons(data);
        })
        .catch(error => {
          console.error("Erro ao carregar temporadas:", error);
          toast({
            title: "Erro",
            description: "Não foi possível carregar as temporadas deste anime.",
            variant: "destructive",
          });
        });
    } else {
      setLocalSeasons([]);
    }
  };

  // Get the next episode number for the selected anime
  useEffect(() => {
    const currentAnimeId = form.getValues("animeId");
    if (currentAnimeId && !episode) {
      // Only auto-set episode number for new episodes
      apiRequest("GET", `/api/animes/${currentAnimeId}/episodes`)
        .then(res => res.json())
        .then(episodes => {
          const maxEpisodeNumber = episodes.length > 0
            ? Math.max(...episodes.map((ep: Episode) => ep.number))
            : 0;
          form.setValue("number", maxEpisodeNumber + 1);
        })
        .catch(error => console.error("Failed to fetch episodes:", error));
    }
  }, [form.watch("animeId"), episode, form]);

  const { mutate, isPending } = useMutation({
    mutationFn: async (data: any) => {  // Usando any para evitar problemas de tipagem
      // Formatando campos para garantir compatibilidade
      const formattedDate = data.releaseDate
        ? new Date(data.releaseDate).toISOString().split('.')[0]
        : new Date().toISOString().split('.')[0];
      
      // Criar payload manualmente para evitar problemas com schamas
      const payload = {
        animeId: parseInt(data.animeId),
        seasonId: data.seasonId ? parseInt(data.seasonId) : null,
        title: data.title,
        number: parseInt(data.number),
        thumbnail: data.thumbnail,
        videoUrl: data.videoUrl,
        videoUrl1080p: data.videoUrl1080p || null,
        videoUrl480p: data.videoUrl480p || null,
        videoUrl360p: data.videoUrl360p || null,
        duration: parseInt(data.duration),
        releaseDate: formattedDate,
      };
      
      console.log("Enviando para o servidor:", payload);
      
      if (episode) {
        // Update
        const res = await apiRequest("PUT", `/api/admin/episodes/${episode.id}`, payload);
        return res.json();
      } else {
        // Create
        const res = await apiRequest("POST", "/api/admin/episodes", payload);
        return res.json();
      }
    },
    onSuccess: () => {
      toast({
        title: episode ? "Episódio atualizado" : "Episódio criado",
        description: episode ? "Episódio foi atualizado com sucesso." : "Novo episódio foi criado com sucesso.",
      });
      // Invalidate all related queries
      queryClient.invalidateQueries({ queryKey: ["/api/episodes"] });
      if (selectedAnimeId) {
        queryClient.invalidateQueries({ queryKey: ["/api/animes", selectedAnimeId, "episodes"] });
      }
      form.reset(defaultValues);
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message || "Ocorreu um erro ao salvar o episódio.",
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: any) {
    // Simples reenvio de dados, deixamos a mutationFn lidar com as conversões
    console.log("Dados do formulário:", data);
    
    // Apenas passa os dados diretos, sem conversão ou tipagem
    mutate(data);
  }

  // Format duration to human-readable time
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="animeId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Anime</FormLabel>
                <Select
                  onValueChange={(value) => onAnimeChange(Number(value))}
                  value={field.value.toString()}
                  disabled={!!animeId} // Disable if animeId prop is provided
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o anime" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {animes?.map((anime) => (
                      <SelectItem key={anime.id} value={anime.id.toString()}>
                        {anime.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="seasonId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Temporada (Opcional)</FormLabel>
                <Select
                  onValueChange={(value) => field.onChange(Number(value))}
                  value={field.value ? field.value.toString() : "0"}
                  disabled={!selectedAnimeId}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a temporada" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="0">Sem temporada</SelectItem>
                    {localSeasons.map((season) => (
                      <SelectItem key={season.id} value={season.id.toString()}>
                        Temporada {season.number}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Título</FormLabel>
                <FormControl>
                  <Input placeholder="Título do episódio" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="number"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Número do Episódio</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    min={1}
                    placeholder="Número do episódio"
                    {...field}
                    onChange={(e) => field.onChange(Number(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="thumbnail"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL da Thumbnail</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/thumbnail.jpg" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="videoUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL do Vídeo (720p - Padrão)</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/video-720p.mp4" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <FormField
            control={form.control}
            name="videoUrl1080p"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL do Vídeo (1080p - Opcional)</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/video-1080p.mp4" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="videoUrl480p"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL do Vídeo (480p - Opcional)</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/video-480p.mp4" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="videoUrl360p"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL do Vídeo (360p - Opcional)</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/video-360p.mp4" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="duration"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Duração (em segundos)</FormLabel>
                <div className="flex items-center space-x-2">
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      placeholder="Duração em segundos"
                      {...field}
                      onChange={(e) => field.onChange(Number(e.target.value))}
                    />
                  </FormControl>
                  <span className="text-sm text-muted-foreground">
                    {formatDuration(field.value)} min
                  </span>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="releaseDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Data de Lançamento</FormLabel>
                <FormControl>
                  <Input
                    type="datetime-local"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => form.reset(defaultValues)}
          >
            Limpar
          </Button>
          <Button type="submit" disabled={isPending}>
            {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {episode ? "Atualizar" : "Criar"} Episódio
          </Button>
        </div>
      </form>
    </Form>
  );
}
