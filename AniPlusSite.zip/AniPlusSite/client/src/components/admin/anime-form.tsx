import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Anime, InsertAnime, insertAnimeSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { X, Plus, Loader2 } from "lucide-react";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

// Extend the schema to include validation
const extendedAnimeSchema = insertAnimeSchema.extend({
  synopsis: z.string().min(10, "A sinopse deve ter no mínimo 10 caracteres"),
  coverImage: z.string().url("A URL da imagem de capa deve ser válida"),
  bannerImage: z.string().url("A URL da imagem de banner deve ser válida").optional().nullable(),
  audioLanguage: z.enum(["dublado", "legendado"], {
    required_error: "Selecione o idioma do áudio",
  }),
  releaseYear: z.number().min(1900, "O ano de lançamento deve ser após 1900").max(new Date().getFullYear() + 1, `O ano não pode ser maior que ${new Date().getFullYear() + 1}`),
  genres: z.array(z.string()).min(1, "Selecione pelo menos um gênero"),
});

type AnimeFormValues = z.infer<typeof extendedAnimeSchema>;

interface AnimeFormProps {
  anime?: Anime;
  onSuccess?: () => void;
}

export function AnimeForm({ anime, onSuccess }: AnimeFormProps) {
  const { toast } = useToast();
  const [newGenre, setNewGenre] = useState("");

  const defaultValues: Partial<AnimeFormValues> = {
    title: "",
    synopsis: "",
    coverImage: "",
    bannerImage: "",
    audioLanguage: "legendado",
    releaseYear: new Date().getFullYear(),
    status: "Em andamento",
    genres: [],
  };

  const form = useForm<AnimeFormValues>({
    resolver: zodResolver(extendedAnimeSchema),
    defaultValues: anime ? { ...anime } : defaultValues,
  });

  useEffect(() => {
    if (anime) {
      form.reset({ ...anime });
    }
  }, [anime, form]);

  const { mutate, isPending } = useMutation({
    mutationFn: async (data: InsertAnime) => {
      if (anime) {
        // Update
        const res = await apiRequest("PUT", `/api/admin/animes/${anime.id}`, data);
        return res.json();
      } else {
        // Create
        const res = await apiRequest("POST", "/api/admin/animes", data);
        return res.json();
      }
    },
    onSuccess: () => {
      toast({
        title: anime ? "Anime atualizado" : "Anime criado",
        description: anime ? "Anime foi atualizado com sucesso." : "Novo anime foi criado com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/animes"] });
      form.reset(defaultValues);
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message || "Ocorreu um erro ao salvar o anime.",
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: AnimeFormValues) {
    mutate(data);
  }

  const audioOptions = ["dublado", "legendado"];
  const animeStatus = ["Em andamento", "Concluído", "Anunciado", "Cancelado"];
  const commonGenres = [
    "Ação", "Aventura", "Comédia", "Drama", "Ecchi", "Fantasia", "Horror",
    "Magia", "Mistério", "Psicológico", "Romance", "Sci-Fi", "Slice of Life",
    "Sobrenatural", "Esportes", "Super-heróis", "Thriller"
  ];

  const addGenre = () => {
    if (!newGenre.trim()) return;
    
    const currentGenres = form.getValues("genres") || [];
    if (!currentGenres.includes(newGenre)) {
      form.setValue("genres", [...currentGenres, newGenre]);
      setNewGenre("");
    }
  };

  const removeGenre = (genre: string) => {
    const currentGenres = form.getValues("genres") || [];
    form.setValue("genres", currentGenres.filter(g => g !== genre));
  };

  const handleSelectGenre = (genre: string) => {
    const currentGenres = form.getValues("genres") || [];
    if (!currentGenres.includes(genre)) {
      form.setValue("genres", [...currentGenres, genre]);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Título</FormLabel>
                <FormControl>
                  <Input placeholder="Título do anime" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="releaseYear"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Ano de Lançamento</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    min={1900}
                    max={new Date().getFullYear() + 1}
                    placeholder="Ano de lançamento"
                    {...field}
                    onChange={(e) => field.onChange(Number(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="synopsis"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Sinopse</FormLabel>
              <FormControl>
                <Textarea placeholder="Descreva do que se trata o anime..." className="min-h-[120px]" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="coverImage"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL da Imagem de Capa</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/cover.jpg" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="bannerImage"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL da Imagem de Banner (Opcional)</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/banner.jpg" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="audioLanguage"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Idioma do Áudio</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o idioma" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {audioOptions.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option === "dublado" ? "Dublado" : "Legendado"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {animeStatus.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="genres"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Gêneros</FormLabel>
              
              <div className="flex flex-wrap gap-2 mb-2">
                {field.value?.map((genre) => (
                  <Badge key={genre} className="bg-primary text-white">
                    {genre}
                    <button
                      type="button"
                      onClick={() => removeGenre(genre)}
                      className="ml-1 hover:text-red-300"
                    >
                      <X size={14} />
                    </button>
                  </Badge>
                ))}
              </div>
              
              <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
                <div className="flex">
                  <Input
                    value={newGenre}
                    onChange={(e) => setNewGenre(e.target.value)}
                    placeholder="Adicionar gênero"
                    className="rounded-r-none"
                  />
                  <Button
                    type="button"
                    onClick={addGenre}
                    className="rounded-l-none"
                  >
                    <Plus size={16} />
                  </Button>
                </div>
                
                <Select
                  onValueChange={(value) => {
                    handleSelectGenre(value);
                    form.trigger("genres");
                  }}
                  value=""
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecionar gênero" />
                  </SelectTrigger>
                  <SelectContent>
                    {commonGenres.map((genre) => (
                      <SelectItem key={genre} value={genre}>
                        {genre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => form.reset(defaultValues)}
          >
            Limpar
          </Button>
          <Button type="submit" disabled={isPending}>
            {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {anime ? "Atualizar" : "Criar"} Anime
          </Button>
        </div>
      </form>
    </Form>
  );
}
