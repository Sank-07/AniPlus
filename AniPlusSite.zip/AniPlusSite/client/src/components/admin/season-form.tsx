import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertSeasonSchema, Season, InsertSeason, Anime } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Extend the insert schema with validation
const extendedSeasonSchema = insertSeasonSchema.extend({
  animeId: z.number().min(1, "Por favor selecione um anime"),
  number: z.number().min(1, "Número deve ser pelo menos 1"),
  releaseYear: z.number().min(1900, "Ano de lançamento inválido"),
});

type SeasonFormValues = z.infer<typeof extendedSeasonSchema>;

interface SeasonFormProps {
  season?: Season;
  animeId?: number;
  onSuccess?: () => void;
}

export function SeasonForm({ season, animeId, onSuccess }: SeasonFormProps) {
  const { toast } = useToast();

  // Fetch animes for dropdown
  const { data: animes } = useQuery<Anime[]>({ 
    queryKey: ["/api/animes"]
  });

  const selectedAnimeId = season?.animeId || animeId;

  const defaultValues: Partial<SeasonFormValues> = {
    animeId: selectedAnimeId || 0,
    number: 1,
    releaseYear: new Date().getFullYear(),
  };

  const form = useForm<SeasonFormValues>({
    resolver: zodResolver(extendedSeasonSchema),
    defaultValues: season || defaultValues,
  });

  // Create/Update mutation
  const mutation = useMutation({
    mutationFn: async (data: InsertSeason) => {
      if (season) {
        const response = await apiRequest(
          "PUT",
          `/api/admin/seasons/${season.id}`,
          data
        );
        return response.json();
      } else {
        const response = await apiRequest("POST", "/api/admin/seasons", data);
        return response.json();
      }
    },
    onSuccess: () => {
      toast({
        title: season ? "Temporada atualizada" : "Temporada criada",
        description: season
          ? "Temporada foi atualizada com sucesso."
          : "Temporada foi criada com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/animes"] });
      // Invalidar a query específica para temporadas do anime
      if (selectedAnimeId) {
        queryClient.invalidateQueries({ 
          queryKey: ["/api/animes", selectedAnimeId, "seasons"] 
        });
      }
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: "Não foi possível salvar a temporada. Por favor, tente novamente.",
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: SeasonFormValues) {
    mutation.mutate(data);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <FormField
          control={form.control}
          name="animeId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Anime</FormLabel>
              <Select
                onValueChange={(value) => field.onChange(Number(value))}
                defaultValue={field.value.toString()}
                value={field.value.toString()}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um anime" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {animes?.map((anime) => (
                    <SelectItem key={anime.id} value={anime.id.toString()}>
                      {anime.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormDescription>
                Escolha o anime ao qual esta temporada pertence.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="number"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Número da Temporada</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  placeholder="1"
                  {...field}
                  onChange={(e) => field.onChange(Number(e.target.value))}
                />
              </FormControl>
              <FormDescription>
                Informe o número da temporada.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="releaseYear"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Ano de Lançamento</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  placeholder={new Date().getFullYear().toString()}
                  {...field}
                  onChange={(e) => field.onChange(Number(e.target.value))}
                />
              </FormControl>
              <FormDescription>
                Informe o ano de lançamento da temporada.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" disabled={mutation.isPending}>
          {mutation.isPending ? "Salvando..." : season ? "Atualizar Temporada" : "Criar Temporada"}
        </Button>
      </form>
    </Form>
  );
}