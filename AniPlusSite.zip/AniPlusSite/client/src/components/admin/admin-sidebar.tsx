import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Home, 
  Film, 
  Users, 
  Play, 
  Calendar, 
  Settings, 
  LogOut,
  ChevronLeft,
  ChevronRight,
  BarChart,
  Layers
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function AdminSidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  if (!user || user.role !== "admin") return null;

  const menuItems = [
    { icon: <Home size={20} />, label: "Dashboard", href: "/admin" },
    { icon: <Film size={20} />, label: "Animes", href: "/admin/animes" },
    { icon: <Layers size={20} />, label: "Temporadas", href: "/admin/seasons" },
    { icon: <Play size={20} />, label: "Episódios", href: "/admin/episodes" },
    { icon: <Users size={20} />, label: "Usuários", href: "/admin/users" },
    { icon: <Calendar size={20} />, label: "Calendário", href: "/admin/calendar" },
    { icon: <BarChart size={20} />, label: "Estatísticas", href: "/admin/stats" },
    { icon: <Settings size={20} />, label: "Configurações", href: "/admin/settings" },
  ];

  return (
    <div 
      className={cn(
        "bg-sidebar h-screen flex flex-col border-r border-sidebar-border transition-all duration-300 relative",
        collapsed ? "w-16" : "w-64"
      )}
    >
      <div className="p-4 flex items-center mb-6">
        {!collapsed && (
          <Link href="/" className="flex items-center">
            <span className="text-primary text-xl font-bold font-montserrat">Ani<span className="text-accent">Plus</span></span>
          </Link>
        )}
        {collapsed && (
          <Link href="/" className="flex items-center">
            <span className="text-primary text-xl font-bold font-montserrat">A<span className="text-accent">+</span></span>
          </Link>
        )}
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="absolute -right-3 top-6 p-0 w-6 h-6 rounded-full border border-sidebar-border bg-sidebar-background text-sidebar-foreground"
        onClick={() => setCollapsed(!collapsed)}
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </Button>

      <div className="px-2 flex-1">
        <div className="space-y-1">
          {menuItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
            >
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:bg-opacity-10",
                  location === item.href && "bg-sidebar-accent bg-opacity-10 text-sidebar-accent-foreground",
                  collapsed ? "px-2" : "px-3"
                )}
              >
                {item.icon}
                {!collapsed && <span className="ml-2">{item.label}</span>}
              </Button>
            </Link>
          ))}
        </div>
      </div>

      <div className="p-4 border-t border-sidebar-border mt-auto">
        {collapsed ? (
          <Avatar className="h-8 w-8">
            <AvatarImage src={user.avatar || ""} alt={user.name} />
            <AvatarFallback className="bg-primary text-white text-xs">
              {user.name.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        ) : (
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user.avatar || ""} alt={user.name} />
                <AvatarFallback className="bg-primary text-white text-xs">
                  {user.name.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="ml-2">
                <p className="text-sm font-medium text-sidebar-foreground">{user.name}</p>
                <p className="text-xs text-sidebar-foreground opacity-60">Administrador</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="text-sidebar-foreground hover:text-primary"
              onClick={() => logoutMutation.mutate()}
            >
              <LogOut size={18} />
            </Button>
          </div>
        )}
      </div>

      {collapsed && (
        <Button
          variant="ghost"
          size="icon"
          className="mb-4 mx-auto text-sidebar-foreground hover:text-primary"
          onClick={() => logoutMutation.mutate()}
        >
          <LogOut size={18} />
        </Button>
      )}
    </div>
  );
}
